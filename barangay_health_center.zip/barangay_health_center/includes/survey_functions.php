<?php
/**
 * Survey module helpers: visibility, counting, and result aggregation.
 */

/** Is a survey currently open for residents? (active + within date range) */
function surveyIsLive(array $survey) {
    if (($survey['status'] ?? '') !== 'active') return false;
    $today = date('Y-m-d');
    if (!empty($survey['starts_at']) && $survey['starts_at'] > $today) return false;
    if (!empty($survey['ends_at']) && $survey['ends_at'] < $today) return false;
    return true;
}

/** Total number of submissions for a survey */
function surveyResponseCount(PDO $pdo, $surveyId) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM survey_responses WHERE survey_id = ?");
    $stmt->execute([$surveyId]);
    return (int)$stmt->fetchColumn();
}

/** Number of questions for a survey */
function surveyQuestionCount(PDO $pdo, $surveyId) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM survey_questions WHERE survey_id = ?");
    $stmt->execute([$surveyId]);
    return (int)$stmt->fetchColumn();
}

/** Has a member already answered a survey? */
function surveyHasResponse(PDO $pdo, $surveyId, $memberId) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM survey_responses WHERE survey_id = ? AND member_id = ?");
    $stmt->execute([$surveyId, $memberId]);
    return (int)$stmt->fetchColumn() > 0;
}

/**
 * Rebuild the aggregated survey_results table for a survey from raw answers.
 * Safe to call inside a transaction (does not manage its own transaction).
 */
function rebuildSurveyResults(PDO $pdo, $surveyId) {
    $pdo->prepare("DELETE FROM survey_results WHERE survey_id = ?")->execute([$surveyId]);

    $stmt = $pdo->prepare(
        "SELECT a.question_id, a.choice_id, a.rating_value, COUNT(*) AS cnt
         FROM survey_answers a
         JOIN survey_responses r ON r.response_id = a.response_id
         WHERE r.survey_id = ?
         GROUP BY a.question_id, a.choice_id, a.rating_value"
    );
    $stmt->execute([$surveyId]);
    $rows = $stmt->fetchAll();

    $ins = $pdo->prepare(
        "INSERT INTO survey_results (survey_id, question_id, choice_id, rating_value, response_count)
         VALUES (?, ?, ?, ?, ?)"
    );
    foreach ($rows as $r) {
        $ins->execute([$surveyId, $r['question_id'], $r['choice_id'], $r['rating_value'], (int)$r['cnt']]);
    }
}

/** Fetch a single survey by id, or null */
function getSurvey(PDO $pdo, $surveyId) {
    $stmt = $pdo->prepare("SELECT * FROM survey_surveys WHERE survey_id = ?");
    $stmt->execute([$surveyId]);
    $survey = $stmt->fetch();
    return $survey ?: null;
}

/** Fetch questions (with their choices) for a survey, grouped by question in PHP */
function getSurveyQuestions(PDO $pdo, $surveyId) {
    $stmt = $pdo->prepare(
        "SELECT q.question_id, q.question_text, q.question_type, q.is_required, q.sort_order,
                c.choice_id, c.choice_text, c.sort_order AS choice_sort
         FROM survey_questions q
         LEFT JOIN survey_choices c ON c.question_id = q.question_id
         WHERE q.survey_id = ?
         ORDER BY q.sort_order, q.question_id, c.sort_order, c.choice_id"
    );
    $stmt->execute([$surveyId]);
    $rows = $stmt->fetchAll();

    $questions = [];
    $order = [];
    foreach ($rows as $r) {
        $qid = (int)$r['question_id'];
        if (!isset($questions[$qid])) {
            $questions[$qid] = [
                'question_id'   => $qid,
                'question_text' => $r['question_text'],
                'question_type' => $r['question_type'],
                'is_required'   => (int)$r['is_required'],
                'sort_order'    => (int)$r['sort_order'],
                'choices'       => [],
            ];
            $order[] = $qid;
        }
        if ($r['choice_id'] !== null) {
            $questions[$qid]['choices'][] = [
                'choice_id'   => (int)$r['choice_id'],
                'choice_text' => $r['choice_text'],
                'sort_order'  => (int)$r['choice_sort'],
            ];
        }
    }

    $result = [];
    foreach ($order as $qid) {
        $result[] = $questions[$qid];
    }
    return $result;
}

/** Fetch aggregated results for a survey keyed by question_id */
function getSurveyResults(PDO $pdo, $surveyId) {
    $stmt = $pdo->prepare("SELECT question_id, choice_id, rating_value, response_count FROM survey_results WHERE survey_id = ?");
    $stmt->execute([$surveyId]);
    $rows = $stmt->fetchAll();

    $results = [];
    foreach ($rows as $r) {
        $qid = (int)$r['question_id'];
        if (!isset($results[$qid])) $results[$qid] = [];
        if ($r['choice_id'] !== null) {
            $results[$qid][(int)$r['choice_id']] = (int)$r['response_count'];
        } elseif ($r['rating_value'] !== null) {
            $results[$qid]['rating'][(int)$r['rating_value']] = (int)$r['response_count'];
        }
    }
    return $results;
}

/** Short-answer replies for a survey's short-answer questions (all at once) */
function getSurveyShortAnswers(PDO $pdo, $surveyId) {
    $stmt = $pdo->prepare(
        "SELECT a.question_id, a.answer_text, m.first_name, m.last_name, m.account_number, r.submitted_at
         FROM survey_answers a
         JOIN survey_responses r ON r.response_id = a.response_id
         JOIN members m ON m.member_id = r.member_id
         WHERE r.survey_id = ? AND a.question_id IN (
             SELECT question_id FROM survey_questions WHERE survey_id = ? AND question_type = 'short_answer'
         )
         ORDER BY a.question_id, r.submitted_at DESC"
    );
    $stmt->execute([$surveyId, $surveyId]);
    $rows = $stmt->fetchAll();

    $grouped = [];
    foreach ($rows as $r) {
        $grouped[(int)$r['question_id']][] = $r;
    }
    return $grouped;
}

/**
 * Auto-close surveys whose closing date has passed (cron-like check on load).
 * Called from survey pages so expired surveys no longer show as Active.
 */
function autoCloseExpiredSurveys(PDO $pdo) {
    $pdo->exec(
        "UPDATE survey_surveys SET status = 'closed'
         WHERE status = 'active' AND ends_at IS NOT NULL AND ends_at < CURDATE()"
    );
}
