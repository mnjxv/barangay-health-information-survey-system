<?php $current = basename($_SERVER['PHP_SELF']); ?>
<div class="sidebar no-print">
  <div class="sidebar-brand">
    <img src="../resify.png" alt="Resify logo" style="width:38px;height:38px;border-radius:8px;">
    <div>
      <div class="brand-name">Resify</div>
      <span class="brand-sub">Resident Portal</span>
    </div>
  </div>

  <div class="nav-section-label">Main menu</div>
  <a href="dashboard.php" class="<?= $current === 'dashboard.php' ? 'active' : '' ?>">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
    Dashboard
  </a>
  <a href="update_info.php" class="<?= $current === 'update_info.php' ? 'active' : '' ?>">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"/><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"/></svg>
    Update Information
  </a>
  <a href="surveys.php" class="<?= in_array($current, ['surveys.php','survey_take.php']) ? 'active' : '' ?>">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
    Surveys
  </a>

  <div class="nav-section-label">Preferences</div>
  <a href="change_password.php" class="<?= $current === 'change_password.php' ? 'active' : '' ?>">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
    Change Password
  </a>
  <a href="notifications.php" class="<?= $current === 'notifications.php' ? 'active' : '' ?>">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
    Notifications
  </a>

  <div class="sidebar-divider"></div>

</div>