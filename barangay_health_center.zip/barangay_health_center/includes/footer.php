<footer class="no-print" style="text-align:center;color:var(--text-dim);font-size:0.75rem;padding:24px;margin-left:var(--sidebar-w);">
  &copy; <?= date('Y') ?> Resify Information Management System
</footer>
</body>
</html>