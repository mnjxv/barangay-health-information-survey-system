<?php
/**
 * Shared helper functions: session guards, sanitization, logging.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/** Escape output for safe HTML display */
function e($value) {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/** Generate and store a CSRF token in the session */
function generateCsrfToken() {
    if (empty($_SESSION['_csrf_token'])) {
        $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf_token'];
}

/** Validate a CSRF token from the request */
function validateCsrfToken($token) {
    if (empty($_SESSION['_csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['_csrf_token'], $token);
}

/** Check CSRF token from POST, redirect with error on failure */
function requireCsrfToken() {
    $token = $_POST['_csrf_token'] ?? '';
    if (!validateCsrfToken($token)) {
        setFlash('danger', 'Invalid or expired form token. Please try again.');
        redirect(safeRedirectTarget());
    }
}

/** Return a safe redirect target: a same-origin referer if present, else the current page. */
function safeRedirectTarget() {
    $ref = $_SERVER['HTTP_REFERER'] ?? '';
    $host = $_SERVER['HTTP_HOST'] ?? '';
    if ($ref !== '' && $host !== '') {
        $parts = parse_url($ref);
        if (!empty($parts['host']) && strcasecmp($parts['host'], $host) === 0) {
            return $ref;
        }
    }
    return $_SERVER['PHP_SELF'] ?? 'index.php';
}

/** Attempt authentication against staff then members. Returns redirect URL on success, null on failure. */
function authenticateUser(PDO $pdo, $input, $password, &$error) {
    $stmt = $pdo->prepare("SELECT * FROM staff WHERE username = ? OR email = ?");
    $stmt->execute([$input, $input]);
    $staff = $stmt->fetch();

    if ($staff) {
        if ((int)$staff['is_active'] !== 1) {
            $error = 'This account has been deactivated. Please contact the administrator.';
            return null;
        }
        if (password_verify($password, $staff['password'])) {
            session_regenerate_id(true);
            $_SESSION['staff_id'] = $staff['staff_id'];
            $_SESSION['staff_name'] = $staff['full_name'];
            logLogin($pdo, 'staff', $staff['staff_id'], $input);
            return 'staff/dashboard.php';
        }
    }

    $stmt = $pdo->prepare("SELECT * FROM members WHERE account_number = ? OR email = ?");
    $stmt->execute([$input, $input]);
    $member = $stmt->fetch();

    if ($member) {
        if ((int)$member['is_active'] !== 1) {
            $error = 'This account has been deactivated. Please contact the administrator.';
            return null;
        }
        if (password_verify($password, $member['password'])) {
            session_regenerate_id(true);
            $_SESSION['member_id'] = $member['member_id'];
            $_SESSION['account_number'] = $member['account_number'];
            $_SESSION['member_name'] = $member['first_name'] . ' ' . $member['last_name'];
            logLogin($pdo, 'member', $member['member_id'], $input);

            if ((int)$member['must_change_password'] === 1) {
                addNotification($pdo, 'warning', 'Password Change Required', 'Please change your default password for security.', $member['member_id']);
                return 'member/change_password.php?first_login=1';
            }
            return 'member/dashboard.php';
        }
    }

    $error = 'Invalid credentials. Please try again.';
    return null;
}

/** Redirect helper */
function redirect($url) {
    header("Location: $url");
    exit;
}

/** Record a successful login in login_history (best-effort, never blocks auth) */
function logLogin(PDO $pdo, $role, $userId, $username = null) {
    try {
        $stmt = $pdo->prepare(
            "INSERT INTO login_history (role, user_id, username, ip_address) VALUES (?, ?, ?, ?)"
        );
        $stmt->execute([$role, (int)$userId, $username, $_SERVER['REMOTE_ADDR'] ?? null]);
    } catch (Exception $e) {
        // login_history table may not exist yet on older deployments - ignore
    }
}

/** Require an active member session, else redirect to login */
function requireMemberLogin() {
    if (empty($_SESSION['member_id'])) {
        redirect('../index.php#login-section');
    }
}

/** Require an active staff session, else redirect to login */
function requireStaffLogin() {
    if (empty($_SESSION['staff_id'])) {
        redirect('../index.php#login-section');
    }
}

/** Redirect member to change-password if must_change_password is set */
function requireForcePasswordChange(PDO $pdo) {
    if (empty($_SESSION['member_id'])) return;
    $stmt = $pdo->prepare("SELECT must_change_password FROM members WHERE member_id = ?");
    $stmt->execute([$_SESSION['member_id']]);
    $row = $stmt->fetch();
    if ($row && (int)$row['must_change_password'] === 1) {
        $current = basename($_SERVER['PHP_SELF']);
        if (!in_array($current, ['change_password.php', 'logout.php'])) {
            setFlash('warning', 'You must change your default password before continuing.');
            redirect('change_password.php?first_login=1');
        }
    }
}

/** Record an entry in update_logs for audit / "View Updated Records" */
function logUpdate(PDO $pdo, $memberId, $updatedBy, $updatedByName, $section, $remarks = null) {
    $stmt = $pdo->prepare(
        "INSERT INTO update_logs (member_id, updated_by, updated_by_name, section, remarks)
         VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->execute([$memberId, $updatedBy, $updatedByName, $section, $remarks]);
}

/** Basic flash message system */
function setFlash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash() {
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/** Add a notification */
function addNotification(PDO $pdo, $type, $title, $message = null, $memberId = null, $staffId = null) {
    $stmt = $pdo->prepare(
        "INSERT INTO notifications (member_id, staff_id, type, title, message)
         VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->execute([$memberId, $staffId, $type, $title, $message]);
}

/** Get recent notifications for a member or staff (regardless of read status) */
function getRecentNotifications(PDO $pdo, $memberId = null, $staffId = null, $limit = 10) {
    $conditions = [];
    $params = [];
    if ($memberId) {
        $conditions[] = '(member_id = ? AND staff_id IS NULL)';
        $params[] = $memberId;
    }
    if ($staffId) {
        $conditions[] = '(staff_id = ? OR (staff_id IS NULL AND member_id IS NULL))';
        $params[] = $staffId;
    }
    $where = implode(' OR ', $conditions);
    if (!$where) return [];
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE ($where) ORDER BY created_at DESC LIMIT " . (int)$limit);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

/** Get unread notification count */
function getUnreadCount(PDO $pdo, $memberId = null, $staffId = null) {
    $conditions = [];
    $params = [];
    if ($memberId) {
        $conditions[] = '(member_id = ? AND staff_id IS NULL)';
        $params[] = $memberId;
    }
    if ($staffId) {
        $conditions[] = '(staff_id = ? OR (staff_id IS NULL AND member_id IS NULL))';
        $params[] = $staffId;
    }
    $where = implode(' OR ', $conditions);
    if (!$where) return 0;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE ($where) AND is_read = 0");
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

/** Mark a notification as read */
function markNotificationRead(PDO $pdo, $notificationId) {
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE notification_id = ?");
    $stmt->execute([$notificationId]);
}

/** Validate uploaded image file: checks extension, size, and MIME type */
function validateImageUpload($file, &$error, $maxSize = 2097152) {
    $allowedExts = ['jpg', 'jpeg', 'png'];
    $allowedMimes = ['image/jpeg', 'image/png'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = 'Upload failed (error code ' . $file['error'] . ').';
        return false;
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExts)) {
        $error = 'File must be a JPG or PNG image.';
        return false;
    }

    if ($file['size'] > $maxSize) {
        $error = 'File must be smaller than ' . ($maxSize / 1048576) . 'MB.';
        return false;
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime, $allowedMimes)) {
        $error = 'File type not allowed (detected: ' . $mime . '). Only JPEG and PNG are accepted.';
        return false;
    }

    $imgInfo = getimagesize($file['tmp_name']);
    if ($imgInfo === false) {
        $error = 'File is not a valid image.';
        return false;
    }

    return true;
}

/** Calculate age from a birthdate string (Y-m-d) */
function calculateAge($birthday) {
    if (empty($birthday)) return null;
    try {
        $bday = new DateTime($birthday);
        $today = new DateTime('today');
        return $bday->diff($today)->y;
    } catch (Exception $e) {
        return null;
    }
}

/** Display helper: show 'N/A' for empty values instead of blank cells */
function na($value) {
    return trim((string)$value) !== '' ? (string)$value : 'N/A';
}

/** Build a single combined address string from structured address parts */
function buildAddress($household, $purok, $barangay, $municipality, $province, $postal, $country) {
    $parts = array_filter([
        trim($household), trim($purok), trim($barangay),
        trim($municipality), trim($province), trim($postal), trim($country)
    ], function ($v) { return $v !== ''; });
    return implode(', ', $parts);
}

/** Format a member's address for display, falling back to legacy address column */
function formatAddress($m) {
    $structured = buildAddress(
        $m['address_household'] ?? '', $m['purok'] ?? '', $m['address_barangay'] ?? '',
        $m['address_municipality'] ?? '', $m['address_province'] ?? '',
        $m['address_postal'] ?? '', $m['address_country'] ?? ''
    );
    if ($structured !== '') return $structured;
    return $m['address'] ?? '';
}

/** Validate a date (Y-m-d) exists in the real calendar (rejects e.g. 2006-02-31) */
function isValidDateString($date) {
    if (empty($date)) return true;
    $parts = explode('-', $date);
    if (count($parts) !== 3) return false;
    return checkdate((int)$parts[1], (int)$parts[2], (int)$parts[0]);
}
