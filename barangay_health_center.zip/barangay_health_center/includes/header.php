<?php
$assetsPath = $assetsPath ?? '../';
$pageTitle  = $pageTitle ?? 'Resify Information Management System';
$hasTopbar = !empty($userLabel);

// Notification data for header
$notifCount = 0;
$notifList = [];
if ($hasTopbar) {
    require_once $assetsPath . 'config/db.php';
    if (!empty($_SESSION['staff_id'])) {
        $notifCount = getUnreadCount($pdo, null, $_SESSION['staff_id']);
        $notifList = getRecentNotifications($pdo, null, $_SESSION['staff_id'], 10);
        $notifTarget = $assetsPath . 'staff/notifications.php';
    } elseif (!empty($_SESSION['member_id'])) {
        $notifCount = getUnreadCount($pdo, $_SESSION['member_id']);
        $notifList = getRecentNotifications($pdo, $_SESSION['member_id'], null, 10);
        $notifTarget = $assetsPath . 'member/notifications.php';
    }
}

// Fetch photo for the member topbar avatar
$headerPhotoUrl = '';
if (!empty($_SESSION['member_id'])) {
    $stmt = $pdo->prepare("SELECT photo_path FROM members WHERE member_id = ?");
    $stmt->execute([$_SESSION['member_id']]);
    $row = $stmt->fetch();
    if ($row && !empty($row['photo_path']) && file_exists(__DIR__ . '/../' . $row['photo_path'])) {
        $headerPhotoUrl = $assetsPath . $row['photo_path'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> | Resify Management System</title>
<link rel="stylesheet" href="<?= e($assetsPath) ?>assets/css/style.css?v=6">
<script src="<?= e($assetsPath) ?>assets/js/validation.js?v=2"></script>
<script src="<?= e($assetsPath) ?>assets/js/components.js?v=2"></script>
</head>
<body>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php if ($hasTopbar && empty($hideTopbar)): ?>
<div class="topbar no-print">
  <div class="topbar-left">
    <button class="hamburger" id="sidebarToggle" title="Toggle Sidebar">
      <span></span><span></span><span></span>
    </button>
    <div class="page-title"><?= e($pageTitle) ?></div>
  </div>
  <div class="topbar-right">
    <span class="topbar-date">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
      <?= date('F d, Y') ?>
    </span>
    <div class="topbar-notif" id="notifToggle">
      <button class="topbar-btn notif-btn" title="Notifications">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
        <?php if ($notifCount > 0): ?><span class="notif-badge"><?= $notifCount > 9 ? '9+' : $notifCount ?></span><?php endif; ?>
      </button>
      <div class="notif-dropdown" id="notifDropdown">
        <div class="notif-header">
          <span>Notifications</span>
          <?php if ($notifCount > 0): ?><span class="notif-header-count"><?= $notifCount ?> new</span><?php endif; ?>
        </div>
        <div class="notif-list">
          <?php if (count($notifList) === 0): ?>
            <div class="notif-empty">No notifications</div>
          <?php else: ?>
            <?php foreach ($notifList as $n): ?>
              <div class="notif-item <?= $n['is_read'] ? '' : 'unread' ?>" data-id="<?= (int)$n['notification_id'] ?>" onclick="markNotifRead(this)">
                <?php if (!$n['is_read']): ?><span class="notif-dot"></span><?php endif; ?>
                <div class="notif-title"><?= e($n['title']) ?></div>
                <?php if ($n['message']): ?><div class="notif-msg"><?= e($n['message']) ?></div><?php endif; ?>
                <div class="notif-time"><?= e(date('M d, h:i A', strtotime($n['created_at']))) ?></div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
        <a href="<?= e($notifTarget) ?>" class="notif-footer">View All Notifications</a>
      </div>
    </div>
    <button class="topbar-btn" id="themeToggle" title="Toggle Dark Mode">
      <svg class="theme-icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
      <svg class="theme-icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
    </button>
    <div class="topbar-user" id="profileToggle">
      <div class="avatar">
        <?php if ($headerPhotoUrl): ?>
          <img src="<?= e($headerPhotoUrl) ?>" alt="<?= e($userLabel) ?>" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">
        <?php else: ?>
          <?= e(strtoupper(substr($userLabel, 0, 2))) ?>
        <?php endif; ?>
      </div>
      <div class="user-info">
        <span class="user-name"><?= e($userLabel) ?></span>
        <span class="user-role"><?= !empty($_SESSION['account_number']) ? 'Resident #' . e($_SESSION['account_number']) : e($userRole ?? 'Staff') ?></span>
      </div>
      <svg class="user-caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><polyline points="6 9 12 15 18 9"/></svg>
      <div class="profile-dropdown" id="profileDropdown">
        <div class="dropdown-header">
          <div class="dropdown-avatar">
            <?php if ($headerPhotoUrl): ?>
              <img src="<?= e($headerPhotoUrl) ?>" alt="<?= e($userLabel) ?>" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">
            <?php else: ?>
              <?= e(strtoupper(substr($userLabel, 0, 2))) ?>
            <?php endif; ?>
          </div>
          <div>
            <div class="dropdown-name"><?= e($userLabel) ?></div>
            <div class="dropdown-role"><?= !empty($_SESSION['account_number']) ? 'Resident #' . e($_SESSION['account_number']) : e($userRole ?? 'Staff') ?></div>
          </div>
        </div>
        <?php if (isset($_SESSION['account_number'])): ?>
          <div class="dropdown-row"><span>Resident No.</span><span><?= e($_SESSION['account_number']) ?></span></div>
        <?php endif; ?>
        <div class="dropdown-divider"></div>
        <a href="<?= e($logoutUrl ?? '#') ?>" class="dropdown-link">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
          Logout
        </a>
      </div>
    </div>

  </div>
</div>
<?php endif; ?>
<?php if ($hasTopbar && !empty($breadcrumbs)): ?>
<div class="breadcrumbs no-print" style="margin-left:var(--sidebar-w);padding:12px 32px 0;">
  <?php $bcCount = count($breadcrumbs); $bcI = 0; ?>
  <?php foreach ($breadcrumbs as $crumb): ?>
    <?php if (isset($crumb['url'])): ?>
      <a href="<?= e($crumb['url']) ?>">
        <?php if ($bcI === 0): ?>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
        <?php endif; ?>
        <?= e($crumb['label']) ?>
      </a>
    <?php else: ?>
      <span class="crumb-current"><?= e($crumb['label']) ?></span>
    <?php endif; ?>
    <?php if ($bcI < $bcCount - 1): ?>
      <span class="crumb-sep">›</span>
    <?php endif; ?>
    <?php $bcI++; ?>
  <?php endforeach; ?>
</div>
<?php endif; ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
  var toggle = document.getElementById('profileToggle');
  var dropdown = document.getElementById('profileDropdown');
  if (toggle && dropdown) {
    toggle.addEventListener('click', function(e) { e.stopPropagation(); dropdown.classList.toggle('open'); });
    document.addEventListener('click', function() { dropdown.classList.remove('open'); });
    dropdown.addEventListener('click', function(e) { e.stopPropagation(); });
  }
  var notifToggle = document.getElementById('notifToggle');
  var notifDropdown = document.getElementById('notifDropdown');
  if (notifToggle && notifDropdown) {
    notifToggle.addEventListener('click', function(e) { e.stopPropagation(); notifDropdown.classList.toggle('open'); });
    document.addEventListener('click', function() { notifDropdown.classList.remove('open'); });
    notifDropdown.addEventListener('click', function(e) { e.stopPropagation(); });
  }
  var themeBtn = document.getElementById('themeToggle');
  if (themeBtn) {
    var saved = localStorage.getItem('theme') || 'light';
    if (saved === 'dark') document.documentElement.setAttribute('data-theme', 'dark');
    themeBtn.addEventListener('click', function() {
      var isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      document.documentElement.setAttribute('data-theme', isDark ? '' : 'dark');
      localStorage.setItem('theme', isDark ? 'light' : 'dark');
    });
  }
  var ham = document.getElementById('sidebarToggle');
  var sidebar = document.querySelector('.sidebar');
  var overlay = document.querySelector('.sidebar-overlay');
  if (ham && sidebar) {
    ham.addEventListener('click', function() {
      sidebar.classList.toggle('open');
      ham.classList.toggle('open');
      if (overlay) overlay.classList.toggle('open');
    });
    if (overlay) overlay.addEventListener('click', function() {
      sidebar.classList.remove('open');
      ham.classList.remove('open');
      overlay.classList.remove('open');
    });
  }
});
function markNotifRead(el) {
  var id = el.getAttribute('data-id');
  if (id && el.classList.contains('unread')) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '<?= e($assetsPath) ?>ajax/notifications.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
      el.classList.remove('unread');
      var dot = el.querySelector('.notif-dot');
      if (dot) dot.remove();
      var badge = document.querySelector('.notif-badge');
      if (badge) {
        var c = parseInt(badge.textContent);
        if (c > 1) badge.textContent = c - 1;
        else badge.remove();
      }
    };
    xhr.send('action=read&id=' + id);
  }
}
</script>
<?php $flash = getFlash(); ?>
<?php if ($flash): ?>
<?php if ($flash['type'] === 'success'): ?>
<script>document.addEventListener('DOMContentLoaded',function(){ showToast('success','Success',<?= json_encode($flash['message']) ?>); });</script>
<?php else: ?>
<div class="flash-container no-print"<?= $hasTopbar ? ' style="margin-left:var(--sidebar-w);"' : '' ?>>
  <div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
</div>
<?php endif; ?>
<?php endif; ?>
