<?php
require_once 'includes/functions.php';
require_once 'config/db.php';

if (!empty($_SESSION['staff_id'])) {
    redirect('staff/dashboard.php');
}
if (!empty($_SESSION['member_id'])) {
    redirect('member/dashboard.php');
}

$errors = [];
$sent = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrfToken();
    $accountNumber = trim($_POST['account_number'] ?? '');
    $email = trim($_POST['email'] ?? '');

    if ($accountNumber === '' || $email === '') {
        $errors[] = 'Please enter both your Resident No. and the email on file.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM members WHERE account_number = ? AND email = ?");
        $stmt->execute([$accountNumber, $email]);
        $member = $stmt->fetch();

        if (!$member) {
            $errors[] = 'No resident record matches that Resident No. and email combination.';
        } else {
            // Invalidate any previous unused tokens for this member
            $pdo->prepare("UPDATE password_resets SET used = 1 WHERE member_id = ? AND used = 0")->execute([$member['member_id']]);

            $token = bin2hex(random_bytes(32));
            $tokenHash = hash('sha256', $token);
            $expiresAt = date('Y-m-d H:i:s', time() + 1800);

            $ins = $pdo->prepare("INSERT INTO password_resets (member_id, token_hash, expires_at) VALUES (?, ?, ?)");
            $ins->execute([$member['member_id'], $tokenHash, $expiresAt]);

            $resetUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/reset_password_token.php?token=' . $token;

            $subject = 'Resify — Password Reset';
            $message = "Hi " . $member['first_name'] . ",\r\n\r\n"
                     . "We received a request to reset the password for your Resify account (Resident #" . $accountNumber . ").\r\n\r\n"
                     . "Use the link below to set a new password. It expires in 30 minutes.\r\n\r\n"
                     . $resetUrl . "\r\n\r\n"
                     . "If you did not request this, you can safely ignore this email.\r\n\r\n"
                     . "— Resify Information Management System";
            $headers = "From: no-reply@resify.local\r\nReply-To: no-reply@resify.local\r\n";

            $mailed = @mail($email, $subject, $message, $headers);
            $sent = true;
            // Dev fallback: show the link on screen when no mail server is configured.
            $devResetUrl = $resetUrl;
        }
    }
}

$pageTitle = 'Forgot Password';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> — Resify</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="page-center">
  <div class="auth-card" style="max-width:440px;width:100%;padding:36px 32px;">
    <div class="logo-area">
      <div class="login-icon"><img src="resify.png" alt="Resify logo"></div>
      <h1>Resify Information<br>Management System</h1>
    </div>

    <?php if ($sent): ?>
      <div class="alert alert-success">
        <strong>Reset link sent.</strong> If the Resident No. and email you entered are on file, a password
        reset link has been sent to that email. It expires in 30 minutes.
      </div>
      <?php if (isset($devResetUrl)): ?>
        <div class="alert alert-info" style="word-break:break-all;">
          <strong>Demo / no-mail fallback:</strong> open this link to reset your password.
          <br><a href="<?= e($devResetUrl) ?>" style="color:#2E5A9C;"><?= e($devResetUrl) ?></a>
        </div>
      <?php endif; ?>
      <a href="index.php#login-section" class="btn btn-primary btn-block" style="text-align:center;">Back to Sign In</a>
    <?php else: ?>
      <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:20px;">
        Enter your Resident No. and the email registered on your record. We will send you a link to reset your password.
      </p>

      <?php foreach ($errors as $err): ?>
        <div class="alert alert-danger"><?= e($err) ?></div>
      <?php endforeach; ?>

      <form method="POST" data-validate novalidate>
        <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
        <div class="form-group">
          <label>Resident No. <span class="required">*</span></label>
          <input type="text" name="account_number" data-required placeholder="e.g. 2026-0001">
        </div>
        <div class="form-group">
          <label>Email on File <span class="required">*</span></label>
          <input type="email" name="email" data-required placeholder="resident@email.com">
        </div>
        <button type="submit" class="btn btn-primary btn-block">Send Reset Link</button>
        <div style="text-align:center;margin-top:14px;">
          <a href="index.php#login-section" style="font-size:0.82rem;color:#2E5A9C;font-weight:500;text-decoration:none;">Back to Sign In</a>
        </div>
      </form>
    <?php endif; ?>
  </div>
</div>
<script src="assets/js/validation.js"></script>
</body>
</html>