<?php
require_once 'includes/functions.php';
require_once 'config/db.php';

if (!empty($_SESSION['staff_id'])) {
    redirect('staff/dashboard.php');
}
if (!empty($_SESSION['member_id'])) {
    redirect('member/dashboard.php');
}

$errors = [];
$input = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrfToken();
    $input = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($input === '' || $password === '') {
        $errors[] = 'Please enter your username/account number and password.';
    } else {
        $error = '';
        $redirect = authenticateUser($pdo, $input, $password, $error);
        if ($redirect) {
            redirect($redirect);
        } else {
            setFlash('danger', $error);
            redirect('index.php#login-section');
        }
    }
}

// Show any auth flash message (from failed login redirect) at the login section
$authFlash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Resify — Resident Information Platform</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Sora:wght@600;700;800&family=Prata&display=swap" rel="stylesheet">
<style>
*,*::before,*::after { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior:smooth; }
body {
  font-family:'Inter',-apple-system,'Segoe UI',sans-serif;
  background:#fff; color:#1A2333; overflow-x:hidden; line-height:1.6; }

/* ---- ambient background ---- */
.ambient { position:fixed; inset:0; pointer-events:none; z-index:0; overflow:hidden; }
.ambient-gradient { position:absolute; inset:0;
  background:
    radial-gradient(ellipse 85% 60% at -5% -5%, rgba(46,90,156,0.08) 0%, transparent 65%),
    radial-gradient(ellipse 75% 55% at 105% 10%, rgba(74,118,184,0.06) 0%, transparent 60%),
    radial-gradient(ellipse 60% 50% at 50% 100%, rgba(46,90,156,0.04) 0%, transparent 55%),
    radial-gradient(ellipse 50% 40% at 30% 50%, rgba(27,58,104,0.03) 0%, transparent 55%); }
.ambient-pattern { position:absolute; inset:0;
  background-image:
    repeating-linear-gradient(0deg, transparent, transparent 71px, rgba(46,90,156,0.015) 71px, rgba(46,90,156,0.015) 72px),
    repeating-linear-gradient(90deg, transparent, transparent 71px, rgba(46,90,156,0.015) 71px, rgba(46,90,156,0.015) 72px); }
.ambient-orbs { position:absolute; inset:0; }
.ambient-orb {
  position:absolute; border-radius:50%; filter:blur(120px);
  animation:orbFloat 22s ease-in-out infinite alternate; }
.ambient-orb:nth-child(1) { width:520px; height:520px; background:rgba(46,90,156,0.08); top:-200px; right:-100px; animation-duration:24s; }
.ambient-orb:nth-child(2) { width:420px; height:420px; background:rgba(74,118,184,0.05); bottom:-180px; left:-120px; animation-duration:20s; animation-delay:-5s; }
.ambient-orb:nth-child(3) { width:300px; height:300px; background:rgba(46,90,156,0.04); top:30%; left:45%; animation-duration:28s; animation-delay:-10s; }
@keyframes orbFloat {
  0%   { transform:translate(0,0) scale(1); }
  33%  { transform:translate(40px,-25px) scale(1.06); }
  66%  { transform:translate(-30px,30px) scale(0.94); }
  100% { transform:translate(20px,-15px) scale(1.02); } }

/* ---- home silhouettes ---- */
.bg-silhouette { position:fixed; pointer-events:none; z-index:0; opacity:0.04; }
.bg-silhouette svg { width:100%; height:auto; display:block; }
.sil-1 { bottom:0; left:0; right:0; }
.sil-2 { bottom:0; left:0; right:0; opacity:0.025; }

/* ---- paper plane + flight path ---- */
.paper-plane {
  position:fixed; top:0; left:0; z-index:3; pointer-events:none;
  will-change:transform; }
.paper-plane svg { width:200px; height:200px; display:block; overflow:visible;
  filter:drop-shadow(0 20px 60px rgba(46,90,156,0.2)); }
.paper-plane svg .plane-body { fill:url(#planeGrad); }
.paper-plane svg .plane-wing { fill:url(#wingGrad); opacity:0.7; }
.paper-plane svg .plane-tail { fill:#1B3A68; opacity:0.4; }

.flight-path {
  position:fixed; top:0; left:0; z-index:1; pointer-events:none;
  width:100vw; height:100vh; overflow:visible; }
.flight-path svg { width:100%; height:100%; display:block; }
.flight-path line { stroke:#2E5A9C; stroke-width:1.5; stroke-dasharray:6 8; opacity:0.2; }

@media (max-width:1024px) {
  .paper-plane svg { width:130px; height:130px; } }
@media (max-width:640px) {
  .paper-plane svg { width:90px; height:90px; } }

/* ---- floating blue blobs ---- */
.float-blob { position:fixed; pointer-events:none; z-index:0; }
.float-blob-1 {
  top:12%; left:3%; width:80px; height:80px;
  border:2px solid rgba(46,90,156,0.08); border-radius:50%;
  animation:fd1 20s ease-in-out infinite; }
.float-blob-2 {
  bottom:20%; right:2%; width:60px; height:60px;
  background:rgba(74,118,184,0.03); border-radius:50%;
  animation:fd2 16s ease-in-out infinite; }
.float-blob-3 {
  top:45%; left:1%; width:44px; height:44px;
  border:2px solid rgba(27,58,104,0.05); border-radius:12px; transform:rotate(20deg);
  animation:fd1 22s ease-in-out infinite reverse; }
.float-blob-4 {
  top:6%; right:15%; width:34px; height:34px;
  background:rgba(46,90,156,0.03); border-radius:50%;
  animation:fd3 14s ease-in-out infinite; }
.float-blob-5 {
  bottom:35%; right:5%; width:50px; height:50px;
  border:2px solid rgba(74,118,184,0.06); border-radius:50%;
  animation:fd2 18s ease-in-out infinite; }

@keyframes fd1 {
  0%,100% { transform:translate(0,0) rotate(0deg); }
  33% { transform:translate(18px,-14px) rotate(15deg); }
  66% { transform:translate(-12px,12px) rotate(-8deg); } }
@keyframes fd2 {
  0%,100% { transform:translate(0,0) scale(1); }
  40% { transform:translate(-12px,18px) scale(1.08); }
  80% { transform:translate(10px,-8px) scale(0.95); } }
@keyframes fd3 {
  0%,100% { transform:translate(0,0) rotate(0deg); }
  50% { transform:translate(12px,12px) rotate(25deg); } }

/* ---- floating icons (health + barangay) ---- */
.doc-float { position:fixed; pointer-events:none; z-index:0; }
.doc-float svg { width:100%; height:100%; display:block;
  filter:drop-shadow(0 6px 20px rgba(46,90,156,0.08)); }
/* randomly placed across viewport */
.df-doc { top:8%; left:8%; width:48px; height:48px; opacity:0.2; animation:dfSpin 24s ease-in-out infinite; }
.df-folder { top:22%; left:72%; width:56px; height:56px; opacity:0.18; animation:dfBob 18s ease-in-out infinite; }
.df-pen { top:45%; left:88%; width:40px; height:40px; opacity:0.2; animation:dfFloat 22s ease-in-out infinite; }
.df-building { top:82%; left:12%; width:54px; height:54px; opacity:0.18; animation:dfDrift 20s ease-in-out infinite reverse; }
.df-stamp { top:65%; right:6%; width:48px; height:48px; opacity:0.2; animation:dfBob 16s ease-in-out infinite; }
.df-clipboard { top:75%; left:55%; width:44px; height:44px; opacity:0.18; animation:dfFloat 26s ease-in-out infinite; }
.df-id { top:35%; left:4%; width:46px; height:46px; opacity:0.18; animation:dfSpin 20s ease-in-out infinite reverse; }
.df-calendar { top:18%; left:48%; width:38px; height:38px; opacity:0.2; animation:dfDrift 28s ease-in-out infinite; }
.df-laptop { top:90%; left:40%; width:48px; height:48px; opacity:0.18; animation:dfBob 22s ease-in-out infinite; }
.df-sign { top:30%; left:30%; width:42px; height:42px; opacity:0.16; animation:dfSpin 30s ease-in-out infinite; }
.df-check { top:55%; left:60%; width:34px; height:34px; opacity:0.18; animation:dfFloat 20s ease-in-out infinite reverse; }
.df-mail { top:70%; left:82%; width:38px; height:38px; opacity:0.16; animation:dfDrift 26s ease-in-out infinite; }
.df-search { top:48%; left:20%; width:32px; height:32px; opacity:0.18; animation:dfBob 24s ease-in-out infinite; }
.df-cross { top:12%; left:85%; width:36px; height:36px; opacity:0.2; animation:dfSpin 28s ease-in-out infinite; }
.df-heartbeat { top:40%; right:18%; width:44px; height:44px; opacity:0.16; animation:dfFloat 20s ease-in-out infinite; }
.df-pulse { top:60%; left:35%; width:34px; height:34px; opacity:0.18; animation:dfDrift 24s ease-in-out infinite reverse; }
.df-stethoscope { top:5%; left:35%; width:38px; height:38px; opacity:0.18; animation:dfBob 26s ease-in-out infinite; }
.df-shield { top:85%; right:22%; width:42px; height:42px; opacity:0.16; animation:dfSpin 22s ease-in-out infinite reverse; }
.df-heart { top:25%; left:58%; width:28px; height:28px; opacity:0.2; animation:dfPulse 2.5s ease-in-out infinite; }
.df-plus { top:78%; left:28%; width:26px; height:26px; opacity:0.2; animation:dfFloat 30s ease-in-out infinite; }

@keyframes dfSpin {
  0%,100% { transform:translate(0,0) rotate(0deg); }
  25% { transform:translate(22px,-12px) rotate(6deg); }
  50% { transform:translate(-18px,15px) rotate(-4deg); }
  75% { transform:translate(14px,20px) rotate(5deg); } }
@keyframes dfBob {
  0%,100% { transform:translate(0,0) scale(1); }
  30% { transform:translate(-16px,14px) scale(1.06); }
  60% { transform:translate(18px,-10px) scale(0.96); }
  90% { transform:translate(-10px,16px) scale(1.02); } }
@keyframes dfFloat {
  0%,100% { transform:translate(0,0) rotate(0deg); }
  40% { transform:translate(18px,-18px) rotate(8deg); }
  80% { transform:translate(-18px,14px) rotate(-6deg); } }
@keyframes dfDrift {
  0%,100% { transform:translate(0,0) rotate(0deg); }
  50% { transform:translate(-22px,20px) rotate(-10deg); } }
@keyframes dfPulse {
  0%,100% { transform:translate(0,0) scale(1); opacity:0.18; }
  50% { transform:translate(6px,-6px) scale(1.1); opacity:0.28; } }
@media (max-width:1024px) {
  .doc-float { display:none; } }

/* ---- wave dividers ---- */
.wave-divider { position:relative; z-index:1; line-height:0; overflow:hidden; pointer-events:none; }
.wave-divider svg { display:block; width:100%; height:48px; }
.wave-divider--top svg { transform:rotate(180deg); }
@media (max-width:640px) { .wave-divider svg { height:28px; } }

/* ---- navbar ---- */
.nav {
  position:fixed; top:0; left:0; right:0; z-index:100;
  display:flex; align-items:center; justify-content:space-between;
  padding:16px 52px;
  background:rgba(255,255,255,0.7); backdrop-filter:blur(24px);
  -webkit-backdrop-filter:blur(24px);
  border-bottom:1px solid rgba(216,228,245,0.25);
  transition:box-shadow .5s, padding .3s; }
.nav.scrolled { box-shadow:0 2px 24px rgba(46,90,156,0.04); padding:12px 52px; }
.nav-left { display:flex; align-items:center; gap:12px; }
.nav-logo { display:flex; align-items:center; gap:10px; text-decoration:none; }
.nav-logo img { height:34px; width:auto; border-radius:9px; }
.nav-wordmark { font-size:1.1rem; font-weight:700; color:#1A2333; letter-spacing:-0.01em; }
.nav-center { display:flex; align-items:center; gap:40px; }
.nav-center a {
  text-decoration:none; color:rgba(26,35,51,0.5); font-size:0.85rem; font-weight:500;
  transition:color .35s; position:relative; padding:4px 0; letter-spacing:0.01em; }
.nav-center a::after {
  content:''; position:absolute; bottom:-2px; left:0; width:0; height:2px;
  background:#2E5A9C; transition:width .4s cubic-bezier(.25,.1,.25,1); border-radius:2px; }
.nav-center a:hover { color:#1A2333; }
.nav-center a:hover::after { width:100%; }
.nav-right { display:flex; align-items:center; gap:10px; }
.btn-nav-cta {
  display:inline-flex; align-items:center; gap:8px;
  font-family:inherit; font-size:0.85rem; font-weight:600; color:#fff;
  background:linear-gradient(135deg,#2E5A9C,#1B3A68); border:none; border-radius:100px;
  padding:10px 24px; cursor:pointer; transition:all .4s; text-decoration:none;
  box-shadow:0 4px 18px rgba(46,90,156,0.2); }
.btn-nav-cta:hover { transform:translateY(-2px); box-shadow:0 8px 28px rgba(46,90,156,0.3); }

/* ---- hero ---- */
.hero-wrap {
  position:relative; z-index:1; min-height:100vh;
  display:flex; align-items:flex-start;
  padding:120px 52px 100px; max-width:1200px; margin:0 auto; gap:100px; }
.hero-left { flex:1; max-width:560px; }
.hero-badge {
  display:inline-flex; align-items:center; gap:8px;
  font-size:0.78rem; font-weight:600; color:#2E5A9C;
  background:rgba(46,90,156,0.07); padding:8px 20px; border-radius:100px; margin-bottom:30px;
  border:1px solid rgba(46,90,156,0.1); }
.hero-badge-dot { width:7px; height:7px; border-radius:50%; background:#2E5A9C; animation:heroPulse 3s ease-in-out infinite; }
@keyframes heroPulse {
  0%,100% { opacity:1; transform:scale(1); box-shadow:0 0 0 0 rgba(46,90,156,0.3); }
  50% { opacity:0.5; transform:scale(1.15); box-shadow:0 0 0 8px rgba(46,90,156,0); } }
.hero h1 {
  font-family:'Prata',serif;
  font-size:clamp(2.2rem,4.5vw,3.5rem); font-weight:400; letter-spacing:-0.01em;
  line-height:1.25; margin-bottom:22px;
  color:#1A2333; }
.hero h1 span { color:#1A4B8C; }
.hero p {
  font-size:1.05rem; font-weight:400; line-height:1.7;
  color:rgba(26,35,51,0.5); margin-bottom:36px; max-width:520px; }
.hero-actions { display:flex; align-items:center; gap:18px; flex-wrap:wrap; }
.btn-primary {
  display:inline-flex; align-items:center; gap:10px;
  font-family:inherit; font-size:0.95rem; font-weight:600; color:#fff;
  background:linear-gradient(135deg,#2E5A9C,#1B3A68); border:none; border-radius:100px;
  padding:16px 38px; cursor:pointer; transition:all .5s; text-decoration:none;
  box-shadow:0 6px 24px rgba(46,90,156,0.3); position:relative; overflow:hidden; }
.btn-primary::before {
  content:''; position:absolute; inset:0;
  background:linear-gradient(135deg,#244A82,#152D52); opacity:0;
  transition:opacity .5s; border-radius:100px; }
.btn-primary:hover { transform:translateY(-2px); box-shadow:0 12px 40px rgba(46,90,156,0.35); }
.btn-primary:hover::before { opacity:1; }
.btn-primary span { position:relative; z-index:1; }
.btn-ghost {
  display:inline-flex; align-items:center; gap:8px;
  font-family:inherit; font-size:0.92rem; font-weight:500; color:#2E5A9C;
  background:rgba(46,90,156,0.04); border:1px solid rgba(46,90,156,0.1);
  cursor:pointer; transition:all .4s; text-decoration:none;
  padding:10px 22px; border-radius:100px; }
.btn-ghost:hover { background:rgba(46,90,156,0.08); border-color:rgba(46,90,156,0.2); transform:translateY(-1px); }
.hero-trust {
  display:flex; align-items:center; gap:20px; margin-top:44px;
  font-size:0.78rem; color:rgba(26,35,51,0.35); font-weight:500; flex-wrap:wrap; }
.hero-trust-pill {
  display:inline-flex; align-items:center; gap:6px;
  padding:5px 13px; border-radius:100px;
  border:1px solid rgba(46,90,156,0.12);
  background:rgba(46,90,156,0.03); }
.hero-trust-pill svg { width:13px; height:13px; color:#2E5A9C; flex-shrink:0; opacity:0.7; }

/* ---- hero card ---- */
.hero-right { flex:1; display:flex; align-items:center; justify-content:center; position:relative; min-height:500px; }
.hero-right::before {
  content:''; position:absolute; width:340px; height:340px; border-radius:50%;
  background:radial-gradient(circle,rgba(46,90,156,0.05),transparent 70%);
  top:50%; left:50%; transform:translate(-50%,-50%);
  pointer-events:none; }
.card-stack { position:relative; width:100%; max-width:380px; height:500px; }
.card-floating {
  position:absolute; width:100%; border-radius:20px;
  box-shadow:0 20px 60px rgba(46,90,156,0.06), 0 4px 12px rgba(46,90,156,0.02);
  background:#fff; overflow:hidden;
  border:1px solid rgba(216,228,245,0.4);
  transition:transform .6s cubic-bezier(.25,.1,.25,1),box-shadow .6s; }
.card-main {
  z-index:3; top:10px; animation:cardBob 8s ease-in-out infinite; }
.card-main:hover {
  animation-play-state:paused; transform:scale(1.02) translateY(-4px) !important;
  box-shadow:0 28px 72px rgba(46,90,156,0.1); }
@keyframes cardBob {
  0%,100% { transform:translateY(0) rotate(0deg); }
  33% { transform:translateY(-8px) rotate(.5deg); }
  66% { transform:translateY(3px) rotate(-.3deg); } }
.card-back {
  z-index:2; top:28px; left:12px; width:94%; filter:saturate(0.4) brightness(0.98);
  animation:cardBack 10s ease-in-out infinite; }
@keyframes cardBack {
  0%,100% { transform:translateY(0) rotate(0deg); }
  40% { transform:translateY(5px) rotate(-.6deg); }
  80% { transform:translateY(-3px) rotate(.4deg); } }
.card-inner { padding:24px 26px; }
.card-head { display:flex; align-items:center; gap:12px; margin-bottom:16px; }
.card-avatar {
  width:44px; height:44px; border-radius:13px;
  background:linear-gradient(135deg,#2E5A9C,#1B3A68);
  display:flex; align-items:center; justify-content:center;
  font-size:.9rem; font-weight:700; color:#fff; flex-shrink:0; }
.card-head-text { flex:1; }
.card-name { font-size:0.95rem; font-weight:700; color:#1A2333; }
.card-id { font-size:0.73rem; color:rgba(26,35,51,0.35); font-weight:500; margin-top:1px; }
.card-badge {
  display:inline-flex; align-items:center; gap:4px;
  font-size:0.66rem; font-weight:600; color:#2F855A;
  background:rgba(47,133,90,0.07); padding:4px 11px; border-radius:100px;
  border:1px solid rgba(47,133,90,0.1); }
.card-divider { height:1px; background:linear-gradient(90deg,transparent,#E8EFF8,transparent); margin:16px 0; }
.card-grid { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
.card-label { font-size:0.68rem; color:rgba(26,35,51,0.35); font-weight:500; margin-bottom:2px; text-transform:uppercase; letter-spacing:0.04em; }
.card-value { font-size:0.86rem; font-weight:600; color:#1A2333; }
.card-value.highlight { color:#2E5A9C; }
.card-back-inner { padding:20px 22px; }
.card-back-head { font-size:0.8rem; font-weight:700; color:#1A2333; margin-bottom:12px; display:flex; align-items:center; justify-content:space-between; }
.card-back-head span { font-size:0.68rem; font-weight:500; color:rgba(26,35,51,0.35); background:rgba(46,90,156,0.05); padding:3px 10px; border-radius:100px; }
.back-row { display:flex; align-items:center; gap:12px; margin-bottom:10px; }
.back-row:last-child { margin-bottom:0; }
.back-dot { width:8px; height:8px; border-radius:50%; flex-shrink:0; }
.back-dot.primary { background:#2E5A9C; box-shadow:0 0 6px rgba(46,90,156,0.3); }
.back-dot.primary-light { background:#A0B8D8; }
.back-dot.green { background:#2F855A; box-shadow:0 0 6px rgba(47,133,90,0.3); }
.back-info { flex:1; }
.back-title { font-size:0.78rem; font-weight:600; color:#1A2333; }
.back-date { font-size:0.68rem; color:rgba(26,35,51,0.35); margin-top:1px; }

/* ---- trust bar ---- */
.trust-bar {
  position:relative; z-index:1; padding:60px 48px;
  background:linear-gradient(180deg,#F5F8FC 0%,#fff 100%);
  border-top:1px solid rgba(216,228,245,0.3);
  border-bottom:1px solid rgba(216,228,245,0.3); }
.trust-inner { max-width:1040px; margin:0 auto; display:flex; align-items:center; justify-content:center; gap:60px; flex-wrap:wrap; }
.trust-label { font-size:0.8rem; font-weight:600; color:rgba(26,35,51,0.35); letter-spacing:0.04em; text-transform:uppercase; }
.trust-stats { display:flex; gap:44px; }
.trust-stat { text-align:center; position:relative; }
.trust-stat-value {
  font-size:1.8rem; font-weight:800;
  background:linear-gradient(135deg,#2E5A9C,#1B3A68);
  -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
.trust-stat-label { font-size:0.74rem; color:rgba(26,35,51,0.35); font-weight:500; margin-top:4px; }
.trust-divider { width:1px; height:38px; background:rgba(216,228,245,0.6); align-self:center; }

/* ---- sections ---- */
section.section { position:relative; z-index:1; padding:120px 48px; }
.section-inner { max-width:1080px; margin:0 auto; position:relative; }
.section-label {
  font-size:0.75rem; font-weight:700; letter-spacing:0.1em; text-transform:uppercase; margin-bottom:14px;
  background:linear-gradient(135deg,#2E5A9C,#4A76B8);
  -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
.section-title {
  font-family:'Sora',sans-serif;
  font-size:clamp(1.8rem,3.4vw,2.6rem); font-weight:700; color:#1A2333;
  letter-spacing:-0.03em;   margin-bottom:52px; line-height:1.15; }
.features { display:grid; grid-template-columns:repeat(3,1fr); gap:32px; }
.f-card {
  background:#fff; border-radius:24px; padding:40px 34px;
  box-shadow:0 2px 20px rgba(46,90,156,0.02);
  transition:all .5s cubic-bezier(.25,.1,.25,1); position:relative; overflow:hidden;
  border:1px solid rgba(216,228,245,0.35); }
.f-card::before {
  content:''; position:absolute; top:0; left:0; right:0; height:3px;
  background:linear-gradient(90deg,#2E5A9C,#1B3A68);
  opacity:0; transition:opacity .5s; }
.f-card:hover::before { opacity:1; }
.f-card:hover {
  transform:translateY(-4px);
  box-shadow:0 20px 56px rgba(46,90,156,0.06);
  border-color:rgba(46,90,156,0.08); }
.f-icon {
  width:50px; height:50px; border-radius:14px;
  background:linear-gradient(135deg,rgba(46,90,156,0.07),rgba(27,58,104,0.07));
  display:flex; align-items:center; justify-content:center;
  margin-bottom:24px; color:#2E5A9C;
  transition:all .5s; }
.f-card:hover .f-icon {
  background:linear-gradient(135deg,#2E5A9C,#1B3A68);
  color:#fff; transform:scale(1.04) rotate(-3deg);
  box-shadow:0 10px 28px rgba(46,90,156,0.12); }
.f-card h3 { font-size:1.02rem; font-weight:700; color:#1A2333; margin-bottom:7px; }
.f-card p { font-size:0.86rem; line-height:1.7; color:rgba(26,35,51,0.5); }

/* ---- how it works ---- */
.how-section { background:linear-gradient(180deg,#fff 0%,#F5F8FC 100%); position:relative; }
.steps { display:flex; gap:0; max-width:860px; margin:0 auto; position:relative; }
.step { flex:1; text-align:center; position:relative; padding:0 20px; }
.step-num {
  width:52px; height:52px; border-radius:50%;
  background:linear-gradient(135deg,#2E5A9C,#1B3A68); color:#fff;
  display:flex; align-items:center; justify-content:center;
  font-size:1.1rem; font-weight:700; margin:0 auto 20px; position:relative; z-index:2;
  box-shadow:0 6px 24px rgba(46,90,156,0.12); }
.step-line {
  position:absolute; top:26px; left:calc(50% + 26px); right:calc(50% - 26px);
  height:2px; background:linear-gradient(90deg,#2E5A9C,rgba(46,90,156,0.1)); z-index:1; }
.step:last-child .step-line { display:none; }
.step h4 { font-size:1.05rem; font-weight:700; color:#1A2333; margin-bottom:8px; }
.step p { font-size:0.85rem; color:rgba(26,35,51,0.5); max-width:240px; margin:0 auto; line-height:1.7; }

/* ---- testimonial ---- */
.testimonial {
  position:relative; z-index:1; padding:120px 48px;
  background:linear-gradient(135deg,#EEF3FB 0%,#F5F8FC 100%); }
.test-inner { max-width:720px; margin:0 auto; text-align:center; position:relative; }
.test-quote {
  font-size:1.1rem; font-weight:500; line-height:1.85; color:#1A2333;
  position:relative; padding:0 24px; }
.test-quote-icon {
  font-size:4.5rem; font-weight:900; line-height:1;
  background:linear-gradient(135deg,#2E5A9C,#1B3A68);
  -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text;
  opacity:0.08; position:absolute; top:-32px; left:-2px; font-family:Georgia,serif; }
.test-stars {
  display:flex; align-items:center; justify-content:center; gap:4px;
  margin-top:20px; }
.test-stars svg { width:18px; height:18px; color:#2E5A9C; fill:#2E5A9C;
  animation:starBreathe 5s ease-in-out infinite; }
.test-stars svg:nth-child(2) { animation-delay:0.3s; }
.test-stars svg:nth-child(3) { animation-delay:0.6s; }
.test-stars svg:nth-child(4) { animation-delay:0.9s; }
.test-stars svg:nth-child(5) { animation-delay:1.2s; }
@keyframes starBreathe {
  0%,100% { transform:scale(1); opacity:1; }
  50% { transform:scale(1.08); opacity:0.7; } }
.test-author { margin-top:24px; display:flex; align-items:center; justify-content:center; gap:14px; }
.test-author-avatar {
  width:44px; height:44px; border-radius:50%;
  background:linear-gradient(135deg,#2E5A9C,#1B3A68);
  display:flex; align-items:center; justify-content:center;
  font-size:0.82rem; font-weight:700; color:#fff; flex-shrink:0;
  box-shadow:0 4px 12px rgba(46,90,156,0.12); }
.test-author-info { text-align:left; }
.test-author-name { font-weight:700; color:#1A2333; font-size:0.9rem; }
.test-author-title { font-size:0.78rem; color:rgba(26,35,51,0.35); margin-top:2px; }

/* ---- CTA ---- */
.cta-section {
  position:relative; z-index:1; padding:120px 48px;
  background:linear-gradient(135deg,#F5F8FC 0%,#fff 50%,#EEF3FB 100%);
  text-align:center; overflow:hidden; }
.cta-section h2 {
  font-family:'Sora',sans-serif;
  font-size:clamp(2rem,3.8vw,2.8rem); font-weight:700; color:#1A2333;
  letter-spacing:-0.035em; line-height:1.15; margin-bottom:18px; position:relative; }
.cta-section p { font-size:1.05rem; color:rgba(26,35,51,0.5); max-width:520px; margin:0 auto 32px; position:relative; }
.cta-section .btn-primary { font-size:1.05rem; padding:18px 48px; }
/* ---- login card ---- */
#login-section {
  scroll-margin-top:80px; position:relative; z-index:1;
  display:flex; justify-content:center; padding:120px 24px;
  background:linear-gradient(180deg,#F5F8FC 0%,#fff 100%); }
.auth-card-landing {
  width:100%; max-width:440px;
  background:rgba(255,255,255,0.85); backdrop-filter:blur(28px);
  -webkit-backdrop-filter:blur(28px);
  border:1px solid rgba(216,228,245,0.4); border-radius:24px;
  padding:44px 40px;
  box-shadow:0 20px 60px rgba(46,90,156,0.04), 0 4px 12px rgba(46,90,156,0.02);
  animation:cardSlide .7s ease-out; position:relative; overflow:hidden; }
.auth-card-landing::before {
  content:''; position:absolute; top:0; left:0; right:0; height:3px;
  background:linear-gradient(90deg,#2E5A9C,#1B3A68); }
@keyframes cardSlide { from { opacity:0; transform:translateY(20px); } to { opacity:1; transform:translateY(0); } }
.logo-area { text-align:center; margin-bottom:30px; }
.logo-area .login-icon { margin-bottom:14px; position:relative; display:inline-block; }
.logo-area .login-icon img { width:56px; height:56px; border-radius:14px; object-fit:contain; box-shadow:0 6px 20px rgba(46,90,156,0.08); }
.logo-area .login-icon-ring { position:absolute; inset:-4px; border-radius:50%; border:1.5px solid rgba(46,90,156,0.1); }
.logo-area h1 { font-size:1.12rem; font-weight:800; color:#1A2333; letter-spacing:-0.02em; line-height:1.35; }
.logo-area .subtitle { font-size:0.75rem; color:rgba(26,35,51,0.35); margin-top:5px; font-weight:500; }
.alert { font-size:0.8rem; padding:12px 16px; border-radius:10px; margin-bottom:16px; }
.alert-danger { background:rgba(197,48,48,0.05); color:#C53030; border:1px solid rgba(197,48,48,0.08); }
.form-group { margin-bottom:20px; }
.form-group label { display:block; font-size:0.78rem; font-weight:600; color:rgba(26,35,51,0.5); margin-bottom:7px; }
.form-group label .required { color:#C53030; }
.form-group input {
  width:100%; font-family:inherit; font-size:0.9rem; color:#1A2333;
  background:#fff; border:1.5px solid #D8E4F5; border-radius:11px;
  padding:13px 16px; outline:none; transition:border .3s,box-shadow .3s; }
.form-group input:focus { border-color:#2E5A9C; box-shadow:0 0 0 4px rgba(46,90,156,0.06); }
.form-group input::placeholder { color:rgba(26,35,51,0.3); }
.btn-block { width:100%; }
.btn-signin {
  display:inline-flex; align-items:center; justify-content:center; gap:8px;
  font-family:inherit; font-size:0.9rem; font-weight:600; color:#fff;
  background:linear-gradient(135deg,#2E5A9C,#1B3A68); border:none; border-radius:100px;
  padding:14px 24px; cursor:pointer; transition:all .4s; text-decoration:none;
  box-shadow:0 4px 18px rgba(46,90,156,0.2); position:relative; overflow:hidden; }
.btn-signin::before {
  content:''; position:absolute; inset:0;
  background:linear-gradient(135deg,#244A82,#152D52);
  opacity:0; transition:opacity .4s; border-radius:100px; }
.btn-signin:hover { transform:translateY(-2px); box-shadow:0 8px 28px rgba(46,90,156,0.3); }
.btn-signin:hover::before { opacity:1; }
.btn-signin span { position:relative; z-index:1; }

/* ---- footer ---- */
.landing-footer {
  position:relative; z-index:1;
  background:#1A2333; padding:64px 48px 36px; }
.footer-grid { max-width:1080px; margin:0 auto; display:grid; grid-template-columns:2fr 1fr 1fr; gap:56px; margin-bottom:40px; }
.footer-brand .footer-logo { font-family:'Sora',sans-serif; font-size:1.05rem; font-weight:700; color:#fff; margin-bottom:8px; }
.footer-brand p { font-size:0.82rem; color:rgba(255,255,255,0.4); line-height:1.7; max-width:300px; }
.footer-col h4 { font-size:0.7rem; font-weight:600; color:rgba(255,255,255,0.4); text-transform:uppercase; letter-spacing:0.08em; margin-bottom:14px; }
.footer-col a { display:block; font-size:0.84rem; color:rgba(255,255,255,0.45); text-decoration:none; margin-bottom:9px; transition:color .35s; }
.footer-col a:hover { color:rgba(255,255,255,0.7); }
.footer-col p { font-size:0.84rem; color:rgba(255,255,255,0.45); margin:0 0 9px 0; line-height:1.5; }
.footer-bottom { max-width:1080px; margin:0 auto; padding-top:28px; border-top:1px solid rgba(255,255,255,0.06); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px; }
.footer-bottom p { font-size:0.78rem; color:rgba(255,255,255,0.35); }

/* ---- scroll progress bar ---- */
.scroll-progress {
  position:fixed; top:0; left:0; right:0; height:3px; z-index:999;
  background:linear-gradient(90deg,#2E5A9C,#4A76B8);
  transform-origin:0 50%; transform:scaleX(0);
  transition:transform .1s linear; }

/* ---- back to top ---- */
.back-top {
  position:fixed; bottom:32px; right:32px; z-index:200;
  width:48px; height:48px; border-radius:50%;
  background:linear-gradient(135deg,#2E5A9C,#1B3A68);
  color:#fff; border:none; cursor:pointer;
  display:flex; align-items:center; justify-content:center;
  box-shadow:0 4px 20px rgba(46,90,156,0.25);
  opacity:0; transform:translateY(20px) scale(0.8);
  transition:all .5s cubic-bezier(.25,.1,.25,1);
  pointer-events:none; }
.back-top.visible { opacity:1; transform:translateY(0) scale(1); pointer-events:auto; }
.back-top:hover { transform:translateY(-3px) scale(1.05); box-shadow:0 8px 32px rgba(46,90,156,0.35); }
.back-top svg { width:20px; height:20px; }
@media (max-width:640px) { .back-top { bottom:20px; right:20px; width:42px; height:42px; } }

/* ---- card tilt 3D ---- */
.tilt-card { transform-style:preserve-3d; perspective:800px; }
.tilt-card .tilt-inner { will-change:transform; transition:transform .15s ease-out; }

/* ---- particle sparkles ---- */
.particles { position:absolute; pointer-events:none; z-index:0; top:0; left:0; right:0; bottom:0; overflow:hidden; }
.particle {
  position:absolute; width:4px; height:4px; border-radius:50%;
  background:#2E5A9C; opacity:0;
  animation:particleFade 4s ease-in-out infinite; }
@keyframes particleFade {
  0%,100% { opacity:0; transform:translate(0,0) scale(0); }
  20% { opacity:0.4; }
  50% { opacity:0.6; transform:translate(30px,-30px) scale(1.2); }
  80% { opacity:0.2; }
  100% { opacity:0; transform:translate(-20px,20px) scale(0); } }

/* ---- scroll reveal ---- */
.reveal { opacity:0; transform:translateY(30px); transition:opacity .7s cubic-bezier(.25,.1,.25,1),transform .7s cubic-bezier(.25,.1,.25,1); }
.reveal.visible { opacity:1; transform:translateY(0); }
.r-delay-1 { transition-delay:0.12s; }
.r-delay-2 { transition-delay:0.24s; }
.r-delay-3 { transition-delay:0.36s; }

/* ---- responsive ---- */
@media (max-width:1024px) {
  .nav { padding:14px 28px; }
  .nav.scrolled { padding:10px 28px; }
  .hero-wrap { flex-direction:column; padding:100px 28px 60px; gap:60px; text-align:center; }
  .hero-left { max-width:100%; }
  .hero p { margin:0 auto; }
  .hero-actions { justify-content:center; }
  .hero-trust { justify-content:center; }
  .hero-right { width:100%; }
  .card-stack { max-width:350px; height:480px; margin:0 auto; }
  .features { grid-template-columns:1fr 1fr; }
  .trust-inner { flex-direction:column; gap:20px; }
  .steps { flex-direction:column; align-items:center; gap:32px; max-width:380px; }
  .step-line { display:none; }
  .footer-grid { grid-template-columns:1fr 1fr; }
  .float-blob-1, .float-blob-2, .float-blob-3, .float-blob-4, .float-blob-5 { display:none; } }
@media (max-width:640px) {
  .nav { padding:12px 20px; }
  .nav-center { display:none; }
  .hero h1 { font-size:1.9rem; }
  .features { grid-template-columns:1fr; gap:18px; }
  .hero-right { min-height:360px; }
  .card-stack { max-width:280px; height:400px; }
  section.section { padding:80px 20px; }
  .how-section { padding:80px 20px; }
  .testimonial { padding:80px 20px; }
  .cta-section { padding:80px 20px; }
  .trust-bar { padding:40px 20px; }
  .trust-stats { gap:20px; flex-wrap:wrap; justify-content:center; }
  .trust-divider { display:none; }
  #login-section { padding:80px 20px; }
  .auth-card-landing { padding:32px 24px; }
  .footer-grid { grid-template-columns:1fr; text-align:center; gap:32px; }
  .footer-brand p { margin:0 auto; }
  .footer-bottom { flex-direction:column; text-align:center; } }
</style>
</head>
<body>

<div class="scroll-progress" id="scrollProgress"></div>
<button class="back-top" id="backTop" onclick="window.scrollTo({top:0,behavior:'smooth'})" aria-label="Back to top">
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"/></svg>
</button>
<div class="ambient">
  <div class="ambient-gradient"></div>
  <div class="ambient-pattern"></div>
  <div class="ambient-orbs">
    <div class="ambient-orb"></div>
    <div class="ambient-orb"></div>
    <div class="ambient-orb"></div>
  </div>
</div>

<div class="bg-silhouette sil-1">
  <svg viewBox="0 0 1440 200" preserveAspectRatio="none">
    <path d="M0 200 L40 160 L80 170 L120 140 L160 150 L200 120 L240 130 L280 100 L320 110 L360 80 L400 90 L440 70 L480 80 L520 55 L560 65 L600 40 L640 50 L680 30 L720 40 L760 28 L800 38 L840 22 L880 32 L920 18 L960 28 L1000 15 L1040 25 L1080 12 L1120 22 L1160 10 L1200 20 L1240 8 L1280 18 L1320 5 L1360 15 L1400 8 L1440 12 L1440 200 Z" fill="#2E5A9C" opacity="0.3"/>
    <path d="M0 200 L60 155 L120 165 L180 135 L240 145 L300 115 L360 125 L420 95 L480 105 L540 75 L600 85 L660 55 L720 65 L780 42 L840 52 L900 30 L960 40 L1020 22 L1080 32 L1140 18 L1200 28 L1260 12 L1320 22 L1380 10 L1440 15 L1440 200 Z" fill="#4A76B8" opacity="0.15"/>
  </svg>
</div>
<div class="bg-silhouette sil-2">
  <svg viewBox="0 0 1440 160" preserveAspectRatio="none">
    <path d="M0 160 L60 130 L120 140 L180 110 L240 120 L300 95 L360 105 L420 80 L480 90 L540 65 L600 75 L660 50 L720 60 L780 38 L840 48 L900 25 L960 35 L1020 18 L1080 28 L1140 14 L1200 24 L1260 10 L1320 20 L1380 8 L1440 12 L1440 160 Z" fill="#2E5A9C" opacity="0.2"/>
  </svg>
</div>

<div class="float-blob float-blob-1"></div>
<div class="float-blob float-blob-2"></div>
<div class="float-blob float-blob-3"></div>
<div class="float-blob float-blob-4"></div>
<div class="float-blob float-blob-5"></div>

<div class="doc-float df-doc">
  <svg viewBox="0 0 24 24" fill="none" stroke="#2E5A9C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
</div>
<div class="doc-float df-folder">
  <svg viewBox="0 0 24 24" fill="none" stroke="#4A76B8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
</div>
<div class="doc-float df-pen">
  <svg viewBox="0 0 24 24" fill="none" stroke="#2E5A9C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/></svg>
</div>
<div class="doc-float df-building">
  <svg viewBox="0 0 24 24" fill="none" stroke="#4A76B8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="2" width="16" height="20" rx="2" ry="2"/><path d="M9 22v-4h6v4M8 6h.01M16 6h.01M12 6h.01M12 10h.01M12 14h.01M16 10h.01M16 14h.01M8 10h.01M8 14h.01"/></svg>
</div>
<div class="doc-float df-stamp">
  <svg viewBox="0 0 24 24" fill="none" stroke="#2E5A9C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="5"/><path d="M3 21v-2a7 7 0 0 1 7-7h4a7 7 0 0 1 7 7v2"/><path d="M9 12h6"/></svg>
</div>
<div class="doc-float df-clipboard">
  <svg viewBox="0 0 24 24" fill="none" stroke="#4A76B8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/><path d="M9 12h6M9 16h4"/></svg>
</div>
<div class="doc-float df-id">
  <svg viewBox="0 0 24 24" fill="none" stroke="#2E5A9C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><circle cx="8" cy="10" r="3"/><path d="M19 16v-2a4 4 0 0 0-4-4h-2"/><line x1="13" y1="8" x2="19" y2="8"/><line x1="13" y1="12" x2="18" y2="12"/></svg>
</div>
<div class="doc-float df-calendar">
  <svg viewBox="0 0 24 24" fill="none" stroke="#4A76B8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><circle cx="12" cy="14" r="1"/><circle cx="16" cy="14" r="1"/><circle cx="8" cy="14" r="1"/></svg>
</div>
<div class="doc-float df-laptop">
  <svg viewBox="0 0 24 24" fill="none" stroke="#2E5A9C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="12" rx="2" ry="2"/><line x1="3" y1="15" x2="3" y2="21"/><line x1="21" y1="15" x2="21" y2="21"/></svg>
</div>
<div class="doc-float df-sign">
  <svg viewBox="0 0 24 24" fill="none" stroke="#4A76B8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 17.5V19a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-1.5"/><path d="M12 3v10m0 0l-3-3m3 3l3-3"/></svg>
</div>
<div class="doc-float df-check">
  <svg viewBox="0 0 24 24" fill="none" stroke="#2E5A9C" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
</div>
<div class="doc-float df-mail">
  <svg viewBox="0 0 24 24" fill="none" stroke="#4A76B8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
</div>
<div class="doc-float df-search">
  <svg viewBox="0 0 24 24" fill="none" stroke="#2E5A9C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
</div>

<div class="paper-plane" id="paperPlane">
  <svg viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="planeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#4A76B8"/>
        <stop offset="100%" stop-color="#2E5A9C"/>
      </linearGradient>
      <linearGradient id="wingGrad" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stop-color="#5A8BC0"/>
        <stop offset="100%" stop-color="#2E5A9C"/>
      </linearGradient>
      <filter id="planeShadow">
        <feDropShadow dx="0" dy="10" stdDeviation="16" flood-color="#2E5A9C" flood-opacity="0.28"/>
      </filter>
    </defs>
    <g filter="url(#planeShadow)">
      <path class="plane-body" d="M30 6L6 48l24-10 24 10L30 6z"/>
      <path class="plane-wing" d="M30 20l10 18L30 34V20z" />
      <path class="plane-wing" d="M30 20l-10 18 10-4V20z" />
      <path class="plane-tail" d="M30 6l-6 14 6-3V6z"/>
      <path class="plane-tail" d="M30 6l6 14-6-3V6z"/>
    </g>
  </svg>
</div>

<!-- dotted flight path SVG line updated by JS -->
<div class="flight-path" id="flightPath">
  <svg viewBox="0 0 1440 900" preserveAspectRatio="xMidYMax slice">
    <path id="pathLine" d="" fill="none" stroke="#2E5A9C" stroke-width="1.8" stroke-dasharray="6 10" opacity="0.2"/>
  </svg>
</div>

<nav class="nav" id="navbar">
  <div class="nav-left">
    <a href="#home" class="nav-logo">
      <img src="resify.png" alt="Resify logo">
      <span class="nav-wordmark">Resify</span>
    </a>
  </div>
  <div class="nav-center">
    <a href="#home">Home</a>
    <a href="#features">Features</a>
    <a href="#how-it-works">How It Works</a>
    <a href="#login-section">Sign In</a>
  </div>
  <div class="nav-right">
  </div>
</nav>

<section class="hero-wrap" id="home">
  <div class="hero-left">
    <div class="hero-badge">
      <span class="hero-badge-dot"></span>
      Now accepting online updates
    </div>
    <h1 style="position:relative;"><span style="background:linear-gradient(120deg,rgba(46,90,156,0.25) 0%,rgba(46,90,156,0.4) 100%);padding:0 14px 4px 14px;border-radius:10px;display:inline-block;box-shadow:0 2px 8px rgba(46,90,156,0.06);">Your records,</span><br><span style="color:#2E5A9C;font-family:'Prata',serif;">always up to date.</span>
    <div class="particles" id="particles"></div></h1>
    <p>Update your personal information, household data, and health records online — no more paper forms or trips to the barangay hall.</p>
    <div class="hero-actions">
      <a href="#login-section" class="btn-primary"><span>Sign In to Your Portal</span></a>
      <a href="#features" class="btn-ghost" style="border:none;background:none;text-decoration:underline;text-underline-offset:4px;">Learn more</a>
    </div>
    <div class="hero-trust">
      <span class="hero-trust-pill">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
        Encrypted records
      </span>
      <span class="hero-trust-pill">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
        DOH-aligned privacy
      </span>
      <span class="hero-trust-pill">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 12l2 2 4-4"/><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
        Staff-verified updates
      </span>
    </div>
  </div>
  <div class="hero-right">
    <div class="card-stack">
      <div class="card-floating card-back">
        <div class="card-back-inner">
          <div class="card-back-head">Recent Updates<span>2 this month</span></div>
          <div class="back-row"><span class="back-dot primary"></span><div class="back-info"><div class="back-title">Contact Number</div><div class="back-date">Updated Jul 28, 2026</div></div></div>
          <div class="back-row"><span class="back-dot green"></span><div class="back-info"><div class="back-title">Civil Status</div><div class="back-date">Updated Jul 15, 2026</div></div></div>
          <div class="back-row"><span class="back-dot primary-light"></span><div class="back-info"><div class="back-title">Address</div><div class="back-date">Updated Jun 20, 2026</div></div></div>
        </div>
      </div>
      <div class="card-floating card-main">
        <div class="card-inner">
          <div class="card-head">
            <div class="card-avatar"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg></div>
            <div class="card-head-text">
              <div class="card-name">Maria C. Santos</div>
              <div class="card-id">Resident # 2026-0042</div>
            </div>
            <span class="card-badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="width:13px;height:13px;vertical-align:-2px;"><polyline points="20 6 9 17 4 12"/></svg> Verified</span>
          </div>
          <div class="card-grid">
            <div><div class="card-label">Household</div><div class="card-value">4 members</div></div>
            <div><div class="card-label">Civil Status</div><div class="card-value">Married</div></div>
            <div><div class="card-label">Last Update</div><div class="card-value">Jul 28, 2026</div></div>
            <div><div class="card-label">Blood Type</div><div class="card-value highlight">O+</div></div>
          </div>
          <div class="card-divider"></div>
          <div style="display:flex;justify-content:space-between;font-size:0.73rem;color:rgba(26,35,51,0.35);">
            <span>Purok 3 &#183; Poblacion</span>
            <span style="font-weight:600;color:#2E5A9C;">View profile &rarr;</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<div class="trust-bar reveal">
  <div class="trust-inner">
    <div class="trust-label">Trusted by 40+ barangays</div>
    <div class="trust-stats">
      <div class="trust-stat">
        <div class="trust-stat-value">12,847</div>
        <div class="trust-stat-label">Residents served</div>
      </div>
      <div class="trust-divider"></div>
      <div class="trust-stat">
        <div class="trust-stat-value">3,620</div>
        <div class="trust-stat-label">Records updated</div>
      </div>
      <div class="trust-divider"></div>
      <div class="trust-stat">
        <div class="trust-stat-value">68%</div>
        <div class="trust-stat-label">Avg. time saved</div>
      </div>
    </div>
  </div>
</div>

<!-- wave divider -->
<div class="wave-divider">
  <svg viewBox="0 0 1440 48" preserveAspectRatio="none" fill="#fff">
    <path d="M0 24 Q180 48 360 28 Q540 8 720 24 Q900 40 1080 20 Q1260 0 1440 24 L1440 48 L0 48 Z" opacity="0.6" fill="#F5F8FC"/>
    <path d="M0 32 Q240 12 480 32 Q720 52 960 32 Q1200 12 1440 32 L1440 48 L0 48 Z" opacity="0.3" fill="#EEF3FB"/>
  </svg>
</div>

<section id="features" class="section">
  <div class="section-inner">
    <div class="section-label reveal">Features</div>
    <div class="section-title reveal r-delay-1">Everything you need to<br>keep records current.</div>
    <div class="features">
      <div class="f-card tilt-card reveal r-delay-1">
        <div class="tilt-inner"><div class="f-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/><line x1="8" y1="7" x2="16" y2="7"/><line x1="8" y1="11" x2="14" y2="11"/></svg>
        </div>
        <h3>Update from home</h3>
        <p>No more in-person paper forms. Update your address, contact info, civil status, and more from any device.</p>
      </div></div>
      <div class="f-card tilt-card reveal r-delay-2">
        <div class="tilt-inner"><div class="f-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
        </div>
        <h3>Household &amp; health</h3>
        <p>Manage your whole family's information in one place — spouse, children, blood type, medical history, and emergency contacts.</p>
      </div></div>
      <div class="f-card tilt-card reveal r-delay-3">
        <div class="tilt-inner"><div class="f-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
        </div>
        <h3>Verified &amp; secure</h3>
        <p>Every change is reviewed by barangay staff before taking effect. Your data is encrypted and DOH-privacy compliant.</p>
      </div></div>
    </div>
  </div>
</section>

<div class="wave-divider wave-divider--top">
  <svg viewBox="0 0 1440 48" preserveAspectRatio="none" fill="#fff">
    <path d="M0 24 Q180 48 360 28 Q540 8 720 24 Q900 40 1080 20 Q1260 0 1440 24 L1440 48 L0 48 Z" opacity="0.6" fill="#F5F8FC"/>
    <path d="M0 32 Q240 12 480 32 Q720 52 960 32 Q1200 12 1440 32 L1440 48 L0 48 Z" opacity="0.3" fill="#EEF3FB"/>
  </svg>
</div>

<section id="how-it-works" class="section how-section">
  <div class="section-inner">
    <div class="section-label reveal">How It Works</div>
    <div class="section-title reveal r-delay-1">Three simple steps.</div>
    <div class="steps">
      <div class="step reveal r-delay-1">
        <div class="step-num">1</div>
        <div class="step-line"></div>
        <h4>Sign in</h4>
        <p>Use your resident number or staff credentials to log in securely.</p>
      </div>
      <div class="step reveal r-delay-2">
        <div class="step-num">2</div>
        <div class="step-line"></div>
        <h4>Update your info</h4>
        <p>Edit personal details, add family members, upload health records.</p>
      </div>
      <div class="step reveal r-delay-3">
        <div class="step-num">3</div>
        <div class="step-line"></div>
        <h4>Get verified</h4>
        <p>Barangay staff reviews and approves changes — ensuring data accuracy.</p>
      </div>
    </div>
  </div>
</section>



<div class="testimonial reveal">
  <div class="test-inner">
    <div class="test-quote-icon">&#x201C;</div>
    <div class="test-quote">Resify transformed how we manage resident records. What used to take days of paperwork now happens in minutes — and our residents love being able to update their info without visiting the hall.</div>
    <div class="test-stars">
      <svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
      <svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
      <svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
      <svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
      <svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
    </div>
    <div class="test-author">
      <div class="test-author-avatar">AC</div>
      <div class="test-author-info">
        <div class="test-author-name">Capt. Alejandro V. Cruz</div>
        <div class="test-author-title">Barangay Captain, San Jose Del Monte</div>
      </div>
    </div>
  </div>
</div>

<div class="wave-divider">
  <svg viewBox="0 0 1440 48" preserveAspectRatio="none" fill="#fff">
    <path d="M0 24 Q180 48 360 28 Q540 8 720 24 Q900 40 1080 20 Q1260 0 1440 24 L1440 48 L0 48 Z" opacity="0.6" fill="#F5F8FC"/>
    <path d="M0 32 Q240 12 480 32 Q720 52 960 32 Q1200 12 1440 32 L1440 48 L0 48 Z" opacity="0.3" fill="#EEF3FB"/>
  </svg>
</div>

<div class="cta-section reveal">
  <h2>Keep your records current<br>in minutes.</h2>
  <p>Join thousands of residents who already manage their personal and health information online — safely, securely, and from anywhere.</p>
  <a href="#login-section" class="btn-primary"><span>Sign In to Your Portal</span></a>
</div>

<div id="login-section">
  <div class="auth-card-landing">
    <div class="logo-area">
      <div class="login-icon">
        <img src="resify.png" alt="Resify logo">
        <div class="login-icon-ring"></div>
      </div>
      <h1>Resify Information<br>Management System</h1>
      <div class="subtitle">Resify</div>
    </div>

    <?php if (!empty($authFlash)): ?>
      <div class="alert alert-<?= e($authFlash['type'] === 'danger' ? 'danger' : $authFlash['type']) ?>"><?= e($authFlash['message']) ?></div>
    <?php endif; ?>
    <?php foreach ($errors as $err): ?>
      <div class="alert alert-danger"><?= e($err) ?></div>
    <?php endforeach; ?>

    <form method="POST" id="loginForm" data-validate novalidate>
      <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
      <div class="form-group">
        <label>Username, Email, or Resident No. <span class="required">*</span></label>
        <input type="text" name="login" data-required value="<?= e($input) ?>" placeholder="Staff username, email, or resident no.">
      </div>
      <div class="form-group">
        <label>Password <span class="required">*</span></label>
        <input type="password" name="password" data-required placeholder="Enter your password">
      </div>
      <button type="submit" class="btn-signin btn-block"><span>Sign In</span></button>
      <div style="text-align:center;margin-top:14px;">
        <a href="forgot_password.php" style="font-size:0.82rem;color:#2E5A9C;font-weight:500;text-decoration:none;">Forgot password?</a>
      </div>
      <div style="margin-top:18px;padding-top:16px;border-top:1px solid rgba(216,228,245,0.5);font-size:0.72rem;color:rgba(26,35,51,0.4);line-height:1.7;">
        <strong style="color:rgba(26,35,51,0.55);">Staff</strong> &mdash; sign in with your staff username.<br>
        <strong style="color:rgba(26,35,51,0.55);">Residents</strong> &mdash; sign in with your Resident No. (e.g. 2026-0001).
      </div>
    </form>
  </div>
</div>

<footer class="landing-footer">
  <div class="footer-grid">
    <div class="footer-brand">
      <div class="footer-logo">Resify</div>
      <p>Modern resident information management for barangay health centers and communities.</p>
    </div>
    <div class="footer-col">
      <h4>Explore</h4>
      <a href="#home">Home</a>
      <a href="#features">Features</a>
      <a href="#how-it-works">How It Works</a>
      <a href="#login-section">Sign In</a>
    </div>
    <div class="footer-col" id="contact">
      <h4>Contact</h4>
      <p>Barangay Health Center</p>
      <p>Purok 1, Barangay Hall Complex</p>
      <p>Monday–Friday, 8:00 AM – 5:00 PM</p>
      <p>(02) 123-4567 · health@resify.ph</p>
    </div>
  </div>
  <div class="footer-bottom">
    <p>&copy; <?= date('Y') ?> Resify. All rights reserved.</p>
  </div>
</footer>

<script src="assets/js/validation.js"></script>
<script>
const nav = document.getElementById('navbar');
let ticking = false;
window.addEventListener('scroll', () => {
  if (!ticking) {
    window.requestAnimationFrame(() => {
      nav.classList.toggle('scrolled', window.scrollY > 20);
      ticking = false;
    });
    ticking = true;
  }
});

const observer = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
}, { threshold:0.12 });
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

/* ---- paper plane + flight path ---- */
(function() {
  const plane = document.getElementById('paperPlane');
  const pathLine = document.getElementById('pathLine');
  if (!plane) return;

  let vw = window.innerWidth;
  let vh = window.innerHeight;
  let pathPoints = [];

  function getParams() {
    vw = window.innerWidth;
    vh = window.innerHeight;
    if (vw < 640) {
      return { size: 90, circAmp: 30, sweepAmp: 80, freq: 1.2, bankMul: 16, baseTilt: -5 };
    } else if (vw < 1024) {
      return { size: 130, circAmp: 45, sweepAmp: 110, freq: 1.0, bankMul: 20, baseTilt: -6 };
    } else {
      return { size: 200, circAmp: 60, sweepAmp: 150, freq: 0.9, bankMul: 24, baseTilt: -8 };
    }
  }

  let p = getParams();
  window.addEventListener('resize', () => { p = getParams(); });

  const svg = plane.querySelector('svg');
  function setSize(px) { svg.style.width = px + 'px'; svg.style.height = px + 'px'; }
  setSize(p.size);

  let curX = 0, curY = 0, curRot = 0, curO = 0.55;
  let tgtX = 0, tgtY = 0, tgtRot = 0, tgtO = 0.55;

  function lerp(a, b, t) { return a + (b - a) * t; }

  function updatePlane() {
    const scrollMax = Math.max(document.body.scrollHeight - vh, 1);
    const progress = Math.min(window.scrollY / scrollMax, 1);
    const t = progress;

    /* Y stays within viewport — goes from top to bottom as you scroll */
    const baseY = t * (vh - 220) + 80;

    /* circular looping motion around the main path */
    const loopX = Math.cos(t * Math.PI * p.freq) * p.circAmp;
    const loopY = Math.sin(t * Math.PI * p.freq * 0.8) * p.circAmp * 0.6;

    /* wide left-right sweep */
    const sweepX = Math.sin(t * Math.PI * 0.6) * p.sweepAmp;

    const x = vw * 0.5 + sweepX + loopX;
    const y = baseY + loopY;

    /* banking based on horizontal velocity + loop direction */
    const hVel = Math.cos(t * Math.PI * p.freq) + Math.cos(t * Math.PI * 0.6);
    const bank = hVel * p.bankMul + p.baseTilt;

    /* visible all the way down */
    const fade = 0.55 - t * 0.2;

    tgtX = x;
    tgtY = y;
    tgtRot = bank;
    tgtO = Math.max(0.2, fade);

    curX = lerp(curX, tgtX, 0.1);
    curY = lerp(curY, tgtY, 0.1);
    curRot = lerp(curRot, tgtRot, 0.08);
    curO = lerp(curO, tgtO, 0.06);

    plane.style.transform = 'translateX(' + curX + 'px) translateY(' + curY + 'px) rotate(' + curRot + 'deg)';
    plane.style.opacity = curO;

    /* record path point for dotted trail */
    const idx = Math.round(progress * 60);
    if (idx >= pathPoints.length) {
      pathPoints.push({ x: curX, y: curY });
      if (pathPoints.length > 60) pathPoints.shift();
      if (pathLine && pathPoints.length > 1) {
        const d = pathPoints.map((pt, i) => (i === 0 ? 'M' : 'L') + pt.x + ' ' + pt.y).join(' ');
        pathLine.setAttribute('d', d);
      }
    }

    requestAnimationFrame(updatePlane);
  }

  requestAnimationFrame(updatePlane);
})();

/* ---- scroll progress bar ---- */
(function() {
  const bar = document.getElementById('scrollProgress');
  if (!bar) return;
  function update() {
    const max = document.body.scrollHeight - window.innerHeight;
    bar.style.transform = 'scaleX(' + (max > 0 ? window.scrollY / max : 0) + ')';
    requestAnimationFrame(update);
  }
  requestAnimationFrame(update);
})();

/* ---- back to top ---- */
(function() {
  const btn = document.getElementById('backTop');
  if (!btn) return;
  let ticking = false;
  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        btn.classList.toggle('visible', window.scrollY > 400);
        ticking = false;
      });
      ticking = true;
    }
  });
})();

/* ---- animated counter ---- */
(function() {
  const stats = document.querySelectorAll('.trust-stat-value');
  if (!stats.length) return;
  const counterObs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (!e.isIntersecting || e.target.dataset.counted) return;
      e.target.dataset.counted = '1';
      const target = parseInt(e.target.textContent.replace(/[^0-9]/g,''));
      if (isNaN(target)) return;
      let current = 0;
      const dur = 2000, step = 16;
      const inc = target / (dur / step);
      function count() {
        current += inc;
        if (current >= target) {
          e.target.textContent = e.target.textContent.replace(/[0-9,]+/, target.toLocaleString());
          return;
        }
        e.target.textContent = e.target.textContent.replace(/[0-9,]+/, Math.floor(current).toLocaleString());
        requestAnimationFrame(count);
      }
      count();
    });
  }, { threshold:0.5 });
  stats.forEach(el => counterObs.observe(el));
})();

/* ---- card tilt 3D ---- */
(function() {
  const cards = document.querySelectorAll('.tilt-card');
  cards.forEach(card => {
    const inner = card.querySelector('.tilt-inner');
    if (!inner) return;
    card.addEventListener('mousemove', e => {
      const r = card.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      inner.style.transform = 'rotateX(' + (-y * 8) + 'deg) rotateY(' + (x * 8) + 'deg)';
    });
    card.addEventListener('mouseleave', () => {
      inner.style.transform = 'rotateX(0) rotateY(0)';
    });
  });
})();

/* ---- particle sparkles ---- */
(function() {
  const container = document.getElementById('particles');
  if (!container) return;
  const colors = ['#2E5A9C','#4A76B8','#5A8BC0','#1B3A68'];
  for (let i = 0; i < 16; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.left = (5 + Math.random() * 90) + '%';
    p.style.top = (5 + Math.random() * 90) + '%';
    p.style.width = p.style.height = (3 + Math.random() * 4) + 'px';
    p.style.background = colors[i % colors.length];
    p.style.animationDelay = (Math.random() * 4) + 's';
    p.style.animationDuration = (3 + Math.random() * 3) + 's';
    container.appendChild(p);
  }
})();
</script>
</body>
</html>
