<?php
require_once '../includes/functions.php';
require_once '../config/db.php';

header('Content-Type: application/json');

$action = $_POST['action'] ?? '';

if ($action === 'read' && !empty($_POST['id'])) {
    if (empty($_SESSION['staff_id']) && empty($_SESSION['member_id'])) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'Unauthenticated']);
        exit;
    }
    $id = (int)$_POST['id'];
    $stmt = $pdo->prepare("SELECT member_id, staff_id FROM notifications WHERE notification_id = ?");
    $stmt->execute([$id]);
    $notif = $stmt->fetch();
    if (!$notif) {
        echo json_encode(['ok' => false, 'error' => 'Notification not found']);
        exit;
    }
    if (!empty($_SESSION['member_id']) && (int)$notif['member_id'] === (int)$_SESSION['member_id']) {
        markNotificationRead($pdo, $id);
        echo json_encode(['ok' => true]);
        exit;
    }
    if (!empty($_SESSION['staff_id'])) {
        $isStaffNotif = !empty($notif['staff_id']) && (int)$notif['staff_id'] === (int)$_SESSION['staff_id'];
        $isSystemNotif = empty($notif['staff_id']) && empty($notif['member_id']);
        if ($isStaffNotif || $isSystemNotif) {
            markNotificationRead($pdo, $id);
            echo json_encode(['ok' => true]);
            exit;
        }
    }
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Forbidden']);
    exit;
}

if ($action === 'read_all') {
    if (!empty($_SESSION['staff_id'])) {
        $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE staff_id = ? OR (staff_id IS NULL AND member_id IS NULL)");
        $stmt->execute([$_SESSION['staff_id']]);
    } elseif (!empty($_SESSION['member_id'])) {
        $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE member_id = ? AND staff_id IS NULL");
        $stmt->execute([$_SESSION['member_id']]);
    } else {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'Unauthenticated']);
        exit;
    }
    echo json_encode(['ok' => true]);
    exit;
}

echo json_encode(['ok' => false, 'error' => 'Invalid action']);