-- ============================================================
-- Web-Based Survey Management Module - New Tables
-- Runs against the existing `barangay_health_center` database.
-- Reuses the existing `members` (Residents) and `staff` tables.
-- All new tables are prefixed `survey_` to avoid collisions.
-- ============================================================

USE barangay_health_center;

-- ------------------------------------------------------------
-- Survey definitions (created by staff)
-- status: draft = not visible, active = visible to residents,
--         closed = deactivated. Residents can only answer while
--         status = 'active' AND within [starts_at, ends_at].
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS survey_surveys (
    survey_id   INT AUTO_INCREMENT PRIMARY KEY,
    title       VARCHAR(200) NOT NULL,
    description TEXT DEFAULT NULL,
    starts_at   DATE DEFAULT NULL,
    ends_at     DATE DEFAULT NULL,
    status      ENUM('draft','active','closed') NOT NULL DEFAULT 'draft',
    created_by  INT DEFAULT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES staff(staff_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Questions belonging to a survey
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS survey_questions (
    question_id   INT AUTO_INCREMENT PRIMARY KEY,
    survey_id     INT NOT NULL,
    question_text TEXT NOT NULL,
    question_type ENUM('multiple_choice','yes_no','rating','short_answer') NOT NULL DEFAULT 'multiple_choice',
    is_required   TINYINT(1) NOT NULL DEFAULT 1,
    sort_order    INT NOT NULL DEFAULT 0,
    FOREIGN KEY (survey_id) REFERENCES survey_surveys(survey_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Choices for multiple-choice / yes-no questions
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS survey_choices (
    choice_id   INT AUTO_INCREMENT PRIMARY KEY,
    question_id INT NOT NULL,
    choice_text VARCHAR(255) NOT NULL,
    sort_order  INT NOT NULL DEFAULT 0,
    FOREIGN KEY (question_id) REFERENCES survey_questions(question_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- One row per resident submission (unique per survey per resident)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS survey_responses (
    response_id  INT AUTO_INCREMENT PRIMARY KEY,
    survey_id    INT NOT NULL,
    member_id    INT NOT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_survey_response (survey_id, member_id),
    FOREIGN KEY (survey_id) REFERENCES survey_surveys(survey_id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Individual answers per question
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS survey_answers (
    answer_id    INT AUTO_INCREMENT PRIMARY KEY,
    response_id  INT NOT NULL,
    question_id  INT NOT NULL,
    choice_id    INT DEFAULT NULL,
    rating_value TINYINT DEFAULT NULL,
    answer_text  TEXT DEFAULT NULL,
    FOREIGN KEY (response_id) REFERENCES survey_responses(response_id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES survey_questions(question_id) ON DELETE CASCADE,
    FOREIGN KEY (choice_id) REFERENCES survey_choices(choice_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Aggregated survey results (rebuilt automatically on submit)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS survey_results (
    result_id      INT AUTO_INCREMENT PRIMARY KEY,
    survey_id      INT NOT NULL,
    question_id    INT NOT NULL,
    choice_id      INT DEFAULT NULL,
    rating_value   TINYINT DEFAULT NULL,
    response_count INT NOT NULL DEFAULT 0,
    UNIQUE KEY uq_survey_result (survey_id, question_id, choice_id, rating_value),
    FOREIGN KEY (survey_id) REFERENCES survey_surveys(survey_id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES survey_questions(question_id) ON DELETE CASCADE,
    FOREIGN KEY (choice_id) REFERENCES survey_choices(choice_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Login history (general audit trail - optional)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_history (
    login_id   INT AUTO_INCREMENT PRIMARY KEY,
    role       ENUM('staff','member') NOT NULL,
    user_id    INT NOT NULL,
    username   VARCHAR(150) DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
