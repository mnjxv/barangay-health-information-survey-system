-- ============================================================
-- Revisions migration (applied to Group 3 evaluation feedback)
-- Adds: structured address fields, hotline/alternate contact,
-- and the password_resets table for the Forgot Password flow.
-- ============================================================

-- 1) Structured address breakdown + hotline
ALTER TABLE members
  ADD COLUMN address_household   VARCHAR(100) DEFAULT NULL AFTER address,
  ADD COLUMN address_barangay    VARCHAR(150) DEFAULT NULL AFTER address_household,
  ADD COLUMN address_municipality VARCHAR(150) DEFAULT NULL AFTER address_barangay,
  ADD COLUMN address_province    VARCHAR(100) DEFAULT NULL AFTER address_municipality,
  ADD COLUMN address_postal      VARCHAR(10)  DEFAULT NULL AFTER address_province,
  ADD COLUMN address_country     VARCHAR(100) DEFAULT NULL AFTER address_postal,
  ADD COLUMN hotline             VARCHAR(20)  DEFAULT NULL AFTER contact_number;

-- 2) Password reset tokens (Forgot Password)
CREATE TABLE IF NOT EXISTS password_resets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  member_id INT NOT NULL,
  token_hash VARCHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  used TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE
) ENGINE=InnoDB;