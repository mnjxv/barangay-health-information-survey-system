<?php
/**
 * ONE-TIME SETUP HELPER (CLI ONLY)
 * Run via CLI: php generate_admin_hash.php
 * Generates correct bcrypt hashes for seed accounts.
 *
 * SECURITY: This script is blocked from web access. Only CLI execution is allowed.
 */

if (php_sapi_name() !== 'cli') {
    die('This script can only be run from the command line.');
}

$adminPassword  = 'admin123';
$memberPassword = '2026-0001';

$adminHash  = password_hash($adminPassword, PASSWORD_DEFAULT);
$memberHash = password_hash($memberPassword, PASSWORD_DEFAULT);

echo "Run these SQL statements to set correct default passwords:\n\n";
echo "UPDATE staff SET password = '{$adminHash}' WHERE username = 'admin';\n\n";
echo "UPDATE members SET password = '{$memberHash}' WHERE account_number = '2026-0001';\n\n";
echo "Default staff login   -> username: admin      password: admin123\n";
echo "Default member login  -> resident#: 2026-0001   password: 2026-0001\n";
