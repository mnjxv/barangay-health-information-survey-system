-- ============================================================
-- 15 Dummy Records for Barangay Health Center
-- Import via phpMyAdmin after the schema is set up.
-- ============================================================

USE barangay_health_center;

-- Clear existing (order matters for FK constraints)
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE notifications;
TRUNCATE update_logs;
TRUNCATE children;
TRUNCATE spouse_info;
TRUNCATE members;
SET FOREIGN_KEY_CHECKS = 1;

-- ------------------------------------------------------------
-- Members (15 records)
-- ------------------------------------------------------------
INSERT INTO members (account_number, password, must_change_password, last_name, first_name, middle_name, extension_name, civil_status, gender, address, purok, email, contact_number, birthday, age, occupation, employer, employer_address, father_name, mother_name, reference1_name, reference1_relationship, reference1_contact, reference1_address, reference2_name, reference2_relationship, reference2_contact, reference2_address, created_at, updated_at) VALUES
('2026-0001', '$2y$10$GSktYzZCZL73QaO4pvpl/eMAEeFlqBx4aGHS6Q5cvKdMlqjTgLYJ2', 1, 'Dela Cruz', 'Juan', 'C.', NULL, 'Married', 'Male', 'Barangay San Jose, Bulacan, Philippines', 'Purok 1', 'juan.delacruz0@email.com', '09123456701', '1985-03-15', 41, 'Teacher', 'DepEd', 'City Center, Bulacan', 'Juan C. Dela Cruz', NULL, 'Reference Person A-0', 'Friend', '09123456001', 'Barangay San Jose, Bulacan, Philippines', 'Reference Person B-0', 'Neighbor', '09123456001', 'Barangay San Jose, Bulacan, Philippines', NOW() - INTERVAL 10 DAY, NOW() - INTERVAL 2 DAY),
('2026-0002', '$2y$10$eXrfak./1WsFr1QjFHOCcOb0Quh1Qr7i57BK64zu3iuR27rNHyBJW', 1, 'Santos', 'Maria', 'D.', NULL, 'Single', 'Female', 'Barangay Santo Niño, Nueva Ecija, Philippines', 'Purok 2', 'maria.santos1@email.com', '09123456702', '1998-07-22', 28, 'Engineer', 'Private Company', 'Municipal Hall, Nueva Ecija', NULL, 'Maria D. Santos', 'Reference Person A-1', 'Coworker', '09123456002', 'Barangay Santo Niño, Nueva Ecija, Philippines', 'Reference Person B-1', 'Former Classmate', '09123456002', 'Barangay Santo Niño, Nueva Ecija, Philippines', NOW() - INTERVAL 45 DAY, NOW() - INTERVAL 5 DAY),
('2026-0003', '$2y$10$.FAnyT7OMDv3xN2VgdNN5usHAYhF18zVoaLyvhFxcrT2WeJURMbva', 1, 'Reyes', 'Jose', 'E.', 'Jr.', 'Married', 'Male', 'Barangay Poblacion, Bulacan, Philippines', 'Purok 3', 'jose.reyes2@email.com', '09123456703', '1979-11-08', 47, 'Nurse', 'Hospital', 'City Center, Bulacan', 'Jose E. Reyes', NULL, 'Reference Person A-2', 'Church Member', '09123456003', 'Barangay Poblacion, Bulacan, Philippines', 'Reference Person B-2', 'Friend', '09123456003', 'Barangay Poblacion, Bulacan, Philippines', NOW() - INTERVAL 120 DAY, NOW() - INTERVAL 10 DAY),
('2026-0004', '$2y$10$5QG6NeWM7I57VVd3sjnHfOlq3UQMvKkgWAWZ2DAtBhj6IQRQ8C57K', 1, 'Gonzales', 'Ana', 'F.', NULL, 'Single', 'Female', 'Barangay San Isidro, Nueva Ecija, Philippines', 'Purok 4', 'ana.gonzales3@email.com', '09123456704', '2002-01-30', 24, 'Student', NULL, NULL, NULL, 'Ana F. Gonzales', 'Reference Person A-3', 'Neighbor', '09123456004', 'Barangay San Isidro, Nueva Ecija, Philippines', 'Reference Person B-3', 'Coworker', '09123456004', 'Barangay San Isidro, Nueva Ecija, Philippines', NOW() - INTERVAL 60 DAY, NOW() - INTERVAL 15 DAY),
('2026-0005', '$2y$10$lwg4HRlb4Oq1ECFaH7eST.U91yvG9pdPIMpXVvwVqZwpuHqam2lLS', 1, 'Bautista', 'Pedro', 'G.', 'III', 'Married', 'Male', 'Barangay Bagong Silang, Bulacan, Philippines', 'Purok 5', 'pedro.bautista4@email.com', '09123456705', '1970-05-12', 56, 'Farmer', 'Self-Employed', 'City Center, Bulacan', 'Pedro G. Bautista', NULL, 'Reference Person A-4', 'Former Classmate', '09123456005', 'Barangay Bagong Silang, Bulacan, Philippines', 'Reference Person B-4', 'Friend', '09123456005', 'Barangay Bagong Silang, Bulacan, Philippines', NOW() - INTERVAL 200 DAY, NOW() - INTERVAL 30 DAY),
('2026-0006', '$2y$10$yGgLb4ToPH1.IzfjwEcY8O8RiE2LY7L89GhFol8p1MDjkVGz2I70m', 1, 'Villanueva', 'Rosa', 'C.', NULL, 'Single', 'Female', 'Barangay Mabuhay, Nueva Ecija, Philippines', 'Purok 6', 'rosa.villanueva5@email.com', '09123456706', '1995-09-18', 31, 'Housewife', NULL, NULL, NULL, 'Rosa C. Villanueva', 'Reference Person A-5', 'Church Member', '09123456006', 'Barangay Mabuhay, Nueva Ecija, Philippines', 'Reference Person B-5', 'Coworker', '09123456006', 'Barangay Mabuhay, Nueva Ecija, Philippines', NOW() - INTERVAL 15 DAY, NOW() - INTERVAL 3 DAY),
('2026-0007', '$2y$10$aA4CvBCKMHeoHuuqNILYk.QEVWY0Hezq2abXKjv9mtoo03vkSBTTi', 1, 'Fernandez', 'Carlos', 'D.', NULL, 'Widowed', 'Male', 'Barangay Maligaya, Bulacan, Philippines', 'Purok 7', 'carlos.fernandez6@email.com', '09123456707', '1988-12-25', 37, 'Driver', 'Private Company', 'Municipal Hall, Nueva Ecija', 'Carlos D. Fernandez', NULL, 'Reference Person A-6', 'Friend', '09123456007', 'Barangay Maligaya, Bulacan, Philippines', 'Reference Person B-6', 'Neighbor', '09123456007', 'Barangay Maligaya, Bulacan, Philippines', NOW() - INTERVAL 90 DAY, NOW() - INTERVAL 7 DAY),
('2026-0008', '$2y$10$jw57FISuURsTXM277O4THO83eCB4FPBgZLKBJxvhwLUtvmaCAAJW2', 1, 'Mendoza', 'Elena', 'E.', NULL, 'Married', 'Female', 'Barangay San Roque, Nueva Ecija, Philippines', 'Purok 8', 'elena.mendoza7@email.com', '09123456708', '1982-06-05', 44, 'Vendor', 'Market Vendor', 'City Center, Bulacan', NULL, 'Elena E. Mendoza', 'Reference Person A-7', 'Coworker', '09123456008', 'Barangay San Roque, Nueva Ecija, Philippines', 'Reference Person B-7', 'Friend', '09123456008', 'Barangay San Roque, Nueva Ecija, Philippines', NOW() - INTERVAL 30 DAY, NOW() - INTERVAL 1 DAY),
('2026-0009', '$2y$10$EecjwclLgDUiCIdSgVuyfeRgWlkuyya7pNYe6igoWHa2HdJSsGreS', 1, 'Lopez', 'Miguel', 'F.', NULL, 'Single', 'Male', 'Barangay San Juan, Bulacan, Philippines', 'Purok 1', 'miguel.lopez8@email.com', '09123456709', '2000-04-20', 26, 'Clerk', 'LGU', 'Municipal Hall, Nueva Ecija', 'Miguel F. Lopez', NULL, 'Reference Person A-8', 'Neighbor', '09123456009', 'Barangay San Juan, Bulacan, Philippines', 'Reference Person B-8', 'Church Member', '09123456009', 'Barangay San Juan, Bulacan, Philippines', NOW() - INTERVAL 75 DAY, NOW() - INTERVAL 12 DAY),
('2026-0010', '$2y$10$dubOzOGMUFd.7e2OpOrmDeMqxp9X.O2HM6KtzCx.AciOVF/jitn2W', 1, 'Garcia', 'Sofia', 'G.', NULL, 'Married', 'Female', 'Barangay San Pedro, Nueva Ecija, Philippines', 'Purok 2', 'sofia.garcia9@email.com', '09123456710', '1991-08-14', 35, 'Government Employee', 'Government Agency', 'City Center, Bulacan', NULL, 'Sofia G. Garcia', 'Reference Person A-9', 'Former Classmate', '09123456010', 'Barangay San Pedro, Nueva Ecija, Philippines', 'Reference Person B-9', 'Coworker', '09123456010', 'Barangay San Pedro, Nueva Ecija, Philippines', NOW() - INTERVAL 150 DAY, NOW() - INTERVAL 20 DAY),
('2026-0011', '$2y$10$ERYxaa9Jhax.nv9XK3DB..OIQ7CeXx5OernV3L/pKYsFhcTvvitEe', 1, 'Martinez', 'Antonio', 'C.', 'Jr.', 'Single', 'Male', 'Barangay San Jose, Bulacan, Philippines', 'Purok 3', 'antonio.martinez10@email.com', '09123456711', '1993-02-28', 33, 'Carpenter', 'Construction Firm', 'Municipal Hall, Nueva Ecija', 'Antonio C. Martinez', NULL, 'Reference Person A-10', 'Coworker', '09123456011', 'Barangay San Jose, Bulacan, Philippines', 'Reference Person B-10', 'Neighbor', '09123456011', 'Barangay San Jose, Bulacan, Philippines', NOW() - INTERVAL 55 DAY, NOW() - INTERVAL 8 DAY),
('2026-0012', '$2y$10$bb/c90JoZWDZabgCTLd.M.QsGgYyA4pAwhqSRBIvTb0F6ucZpGAra', 1, 'Rodriguez', 'Luisa', 'D.', NULL, 'Married', 'Female', 'Barangay Santo Niño, Nueva Ecija, Philippines', 'Purok 4', 'luisa.rodriguez11@email.com', '09123456712', '1987-10-03', 39, 'OFW', 'Private Company', 'City Center, Bulacan', NULL, 'Luisa D. Rodriguez', 'Reference Person A-11', 'Friend', '09123456012', 'Barangay Santo Niño, Nueva Ecija, Philippines', 'Reference Person B-11', 'Church Member', '09123456012', 'Barangay Santo Niño, Nueva Ecija, Philippines', NOW() - INTERVAL 180 DAY, NOW() - INTERVAL 25 DAY),
('2026-0013', '$2y$10$9TodECVj2hfuSvzcY4lyX.zKnEaHnLQA8cxf0M6w/zQjQxD3XorYa', 1, 'Cruz', 'Ramon', 'E.', NULL, 'Single', 'Male', 'Barangay Poblacion, Bulacan, Philippines', 'Purok 5', 'ramon.cruz12@email.com', '09123456713', '1990-07-07', 36, 'Business Owner', 'Self-Employed', 'Municipal Hall, Nueva Ecija', 'Ramon E. Cruz', NULL, 'Reference Person A-12', 'Neighbor', '09123456013', 'Barangay Poblacion, Bulacan, Philippines', 'Reference Person B-12', 'Former Classmate', '09123456013', 'Barangay Poblacion, Bulacan, Philippines', NOW() - INTERVAL 40 DAY, NOW() - INTERVAL 6 DAY),
('2026-0014', '$2y$10$WTrjDESjqQ9Eg8t/SzkipOsODkuGMk5idj3X.bG7xp4XhJfIqpmDm', 1, 'Aquino', 'Carmen', 'F.', NULL, 'Married', 'Female', 'Barangay San Isidro, Nueva Ecija, Philippines', 'Purok 6', 'carmen.aquino13@email.com', '09123456714', '1975-09-01', 51, 'Teacher', 'DepEd', 'City Center, Bulacan', NULL, 'Carmen F. Aquino', 'Reference Person A-13', 'Coworker', '09123456014', 'Barangay San Isidro, Nueva Ecija, Philippines', 'Reference Person B-13', 'Friend', '09123456014', 'Barangay San Isidro, Nueva Ecija, Philippines', NOW() - INTERVAL 100 DAY, NOW() - INTERVAL 14 DAY),
('2026-0015', '$2y$10$l55DNgzcxIN/ilxBNxfX8O2LRxaPp65QAiWnKz5.TY0X/dbsUxw2W', 1, 'Castillo', 'Gregorio', 'G.', NULL, 'Single', 'Male', 'Barangay Bagong Silang, Bulacan, Philippines', 'Purok 7', 'gregorio.castillo14@email.com', '09123456715', '1996-12-19', 29, 'Security Guard', 'Private Company', 'Municipal Hall, Nueva Ecija', 'Gregorio G. Castillo', NULL, 'Reference Person A-14', 'Church Member', '09123456015', 'Barangay Bagong Silang, Bulacan, Philippines', 'Reference Person B-14', 'Neighbor', '09123456015', 'Barangay Bagong Silang, Bulacan, Philippines', NOW() - INTERVAL 85 DAY, NOW() - INTERVAL 9 DAY);

-- ------------------------------------------------------------
-- Spouse Info (for married members: 1,3,5,8,10,12,14)
-- ------------------------------------------------------------
INSERT INTO spouse_info (member_id, spouse_name, occupation, employer) VALUES
(1, 'Maria Dela Cruz', 'Housewife', NULL),
(3, 'Ana Reyes', 'Teacher', 'DepEd'),
(5, 'Rosa Bautista', 'Vendor', 'Market Vendor'),
(8, 'Carlos Mendoza', 'Driver', 'Private Company'),
(10, 'Juan Garcia', 'Carpenter', 'Construction Firm'),
(12, 'Antonio Rodriguez', 'Business Owner', 'Self-Employed'),
(14, 'Ramon Aquino', 'Government Employee', 'LGU');

-- ------------------------------------------------------------
-- Children (for married members)
-- ------------------------------------------------------------
INSERT INTO children (member_id, child_name, age) VALUES
(1, 'Michael Dela Cruz', 10),
(1, 'Angela Dela Cruz', 7),
(3, 'John Reyes', 14),
(5, 'Catherine Bautista', 12),
(5, 'Mark Bautista', 8),
(8, 'Patricia Mendoza', 9),
(10, 'Dan Garcia', 6),
(12, 'Maricar Rodriguez', 11),
(14, 'Kevin Aquino', 15),
(14, 'Rachel Aquino', 13);

-- ------------------------------------------------------------
-- Update Logs (audit trail)
-- ------------------------------------------------------------
INSERT INTO update_logs (member_id, updated_by, updated_by_name, section, updated_at) VALUES
(1, 'Staff', 'System Administrator', 'Personal Info', NOW() - INTERVAL 1 DAY),
(1, 'Staff', 'System Administrator', 'Contact Info', NOW() - INTERVAL 1 DAY),
(2, 'Staff', 'System Administrator', 'Personal Info', NOW() - INTERVAL 3 DAY),
(3, 'Staff', 'System Administrator', 'Spouse Info', NOW() - INTERVAL 2 DAY),
(3, 'Staff', 'System Administrator', 'Children', NOW() - INTERVAL 2 DAY),
(4, 'Member', 'Ana Gonzales', 'Personal Info', NOW() - INTERVAL 5 DAY),
(5, 'Staff', 'System Administrator', 'Personal Info', NOW() - INTERVAL 7 DAY),
(5, 'Staff', 'System Administrator', 'Spouse Info', NOW() - INTERVAL 7 DAY),
(6, 'Member', 'Rosa Villanueva', 'Contact Info', NOW() - INTERVAL 2 DAY),
(7, 'Staff', 'System Administrator', 'Personal Info', NOW() - INTERVAL 10 DAY),
(8, 'Staff', 'System Administrator', 'Personal Info', NOW() - INTERVAL 4 DAY),
(8, 'Staff', 'System Administrator', 'Children', NOW() - INTERVAL 4 DAY),
(9, 'Member', 'Miguel Lopez', 'Personal Info', NOW() - INTERVAL 6 DAY),
(10, 'Staff', 'System Administrator', 'Personal Info', NOW() - INTERVAL 8 DAY),
(11, 'Staff', 'System Administrator', 'Personal Info', NOW() - INTERVAL 3 DAY),
(12, 'Staff', 'System Administrator', 'Spouse Info', NOW() - INTERVAL 5 DAY),
(13, 'Member', 'Ramon Cruz', 'Personal Info', NOW() - INTERVAL 1 DAY),
(14, 'Staff', 'System Administrator', 'Personal Info', NOW() - INTERVAL 9 DAY),
(14, 'Staff', 'System Administrator', 'Children', NOW() - INTERVAL 9 DAY),
(15, 'Staff', 'System Administrator', 'Personal Info', NOW() - INTERVAL 12 DAY);

-- ------------------------------------------------------------
-- Notifications
-- ------------------------------------------------------------
INSERT INTO notifications (member_id, staff_id, type, title, message, is_read, created_at) VALUES
(NULL, NULL, 'info', 'System Update', 'New resident records have been added to the system.', 0, NOW() - INTERVAL 2 DAY),
(1, NULL, 'success', 'Profile Updated', 'Your profile information has been updated by staff.', 1, NOW() - INTERVAL 1 DAY),
(3, NULL, 'success', 'Spouse Info Added', 'Your spouse information has been recorded.', 0, NOW() - INTERVAL 2 DAY),
(NULL, 1, 'info', 'Bulk Import Complete', '15 new resident records were successfully added.', 0, NOW() - INTERVAL 1 DAY),
(5, NULL, 'warning', 'Password Reset', 'Your password was reset to your Resident Number by staff.', 0, NOW() - INTERVAL 3 DAY);

-- ------------------------------------------------------------
-- Done
-- ------------------------------------------------------------
SELECT '✅ 15 dummy records inserted successfully.' AS message;