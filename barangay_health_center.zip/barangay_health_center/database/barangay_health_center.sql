-- ============================================================
-- Web-Based Member Personal Information Updating System
-- Multipurpose Cooperative - Database Schema
-- IT 305 - Advance Web Development
-- ============================================================

CREATE DATABASE IF NOT EXISTS barangay_health_center CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE barangay_health_center;

-- ------------------------------------------------------------
-- Table: staff  (Cooperative Staff accounts)
-- ------------------------------------------------------------
CREATE TABLE staff (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(150) DEFAULT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Default staff account -> username: admin / password: admin123
INSERT INTO staff (username, password, full_name, email)
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin@coop.local');
-- NOTE: the hash above is a placeholder. Run database/generate_admin_hash.php
-- once and update this row, OR simply log in with admin/admin123 if your
-- PHP password_hash() default algorithm matches (recommended: regenerate).

-- ------------------------------------------------------------
-- Table: members  (Core account + personal information)
-- ------------------------------------------------------------
CREATE TABLE members (
    member_id INT AUTO_INCREMENT PRIMARY KEY,
    account_number VARCHAR(20) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,             -- default = account_number (hashed)
    must_change_password TINYINT(1) NOT NULL DEFAULT 1,
    is_active TINYINT(1) NOT NULL DEFAULT 1,

    last_name VARCHAR(100) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100) DEFAULT NULL,
    extension_name VARCHAR(20) DEFAULT NULL,     -- Jr., Sr., III, etc.
    civil_status ENUM('Single','Married','Widowed','Separated','Divorced') DEFAULT 'Single',
    gender ENUM('Male','Female') DEFAULT NULL,
    address VARCHAR(255) DEFAULT NULL,
    purok VARCHAR(100) DEFAULT NULL,
    email VARCHAR(150) DEFAULT NULL,
    contact_number VARCHAR(20) DEFAULT NULL,
    birthday DATE DEFAULT NULL,
    age INT DEFAULT NULL,
    occupation VARCHAR(100) DEFAULT NULL,
    employer VARCHAR(150) DEFAULT NULL,
    employer_address VARCHAR(255) DEFAULT NULL,

    father_name VARCHAR(150) DEFAULT NULL,
    mother_name VARCHAR(150) DEFAULT NULL,

    reference1_name VARCHAR(150) DEFAULT NULL,
    reference1_relationship VARCHAR(50) DEFAULT NULL,
    reference1_contact VARCHAR(20) DEFAULT NULL,
    reference1_address VARCHAR(255) DEFAULT NULL,
    reference2_name VARCHAR(150) DEFAULT NULL,
    reference2_relationship VARCHAR(50) DEFAULT NULL,
    reference2_contact VARCHAR(20) DEFAULT NULL,
    reference2_address VARCHAR(255) DEFAULT NULL,
    emergency_contact_name VARCHAR(150) DEFAULT NULL,
    emergency_contact_relationship VARCHAR(50) DEFAULT NULL,
    emergency_contact_number VARCHAR(20) DEFAULT NULL,
    signature_path VARCHAR(255) DEFAULT NULL,

    photo_path VARCHAR(255) DEFAULT NULL,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: spouse_info  (1-to-1 with members)
-- ------------------------------------------------------------
CREATE TABLE spouse_info (
    spouse_id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT NOT NULL UNIQUE,
    spouse_name VARCHAR(150) DEFAULT NULL,
    occupation VARCHAR(100) DEFAULT NULL,
    employer VARCHAR(150) DEFAULT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: children  (1-to-many with members)
-- ------------------------------------------------------------
CREATE TABLE children (
    child_id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT NOT NULL,
    child_name VARCHAR(150) NOT NULL,
    age INT DEFAULT NULL,
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: notifications  (in-app notification system)
-- ------------------------------------------------------------
CREATE TABLE notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT DEFAULT NULL,
    staff_id INT DEFAULT NULL,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT DEFAULT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: update_logs  (audit trail - "View Updated Records")
-- ------------------------------------------------------------
CREATE TABLE update_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT DEFAULT NULL,
    updated_by ENUM('Member','Staff') NOT NULL,
    updated_by_name VARCHAR(150) DEFAULT NULL,
    section VARCHAR(100) NOT NULL,
    remarks VARCHAR(255) DEFAULT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Sample member for testing
-- Resident Number: 2026-0001 | Default password = resident number
-- ------------------------------------------------------------
INSERT INTO members (account_number, password, last_name, first_name, middle_name, civil_status, address, contact_number)
VALUES ('2026-0001', '$2y$10$7teS.mBq6Ril6P7MSRhare261wK2fohV1.8vCM3/LCu1kCUZ7.MXW', 'Dela Cruz', 'Juan', 'Santos', 'Single', 'Bulacan, Philippines', '09171234567');
