<?php
/**
 * SEED DUMMY DATA (CLI ONLY)
 * Run via CLI: php seed_dummy.php
 *
 * SECURITY: This script destroys real data and is blocked from web access.
 */

if (php_sapi_name() !== 'cli') {
    die('This script can only be run from the command line.');
}

require_once __DIR__ . '/../config/db.php';

$firstNames = ['Juan','Maria','Jose','Ana','Pedro','Rosa','Carlos','Elena','Miguel','Sofia',
               'Antonio','Luisa','Ramon','Carmen','Gregorio','Teresa','Fernando','Luzviminda',
               'Ricardo','Milagros','Eduardo','Corazon','Manuel','Guadalupe','Jorge'];
$lastNames  = ['Dela Cruz','Santos','Reyes','Gonzales','Bautista','Villanueva','Fernandez',
               'Mendoza','Lopez','Garcia','Martinez','Rodriguez','Cruz','Aquino','Castillo',
               'Gomez','Domingo','Ramos','Morales','Rivera','Soriano','Mercado','Diaz',
               'Valdez','Torres'];
$puroks     = ['Purok 1','Purok 2','Purok 3','Purok 4','Purok 5','Purok 6','Purok 7','Purok 8'];
$statuses   = ['Single','Married','Married','Single','Married','Widowed','Single','Married','Separated','Single'];
$genders    = ['Male','Female'];
$barangays  = ['Barangay San Jose','Barangay Santo Niño','Barangay Poblacion',
               'Barangay San Isidro','Barangay Bagong Silang','Barangay Mabuhay',
               'Barangay Maligaya','Barangay San Roque','Barangay San Juan','Barangay San Pedro'];
$occupations = ['Teacher','Engineer','Nurse','Farmer','Driver','Clerk','Vendor',
                'Carpenter','Fisherman','Housewife','Government Employee','OFW',
                'Business Owner','Security Guard','Electrician',null,null,null];
$employers  = ['DepEd','LGU','Private Company','Self-Employed','Hospital',
               'Construction Firm','Market Vendor','Government Agency',null];

echo "Seeding 25 dummy records...\n";

// Clear existing test data (optional — comment out if you want to keep existing)
$pdo->exec("DELETE FROM notifications");
$pdo->exec("DELETE FROM update_logs");
$pdo->exec("DELETE FROM children");
$pdo->exec("DELETE FROM spouse_info");
$pdo->exec("DELETE FROM members WHERE member_id > 0");

for ($i = 0; $i < 25; $i++) {
    $acct = '2026-' . str_pad($i + 1, 4, '0', STR_PAD_LEFT);
    $pw   = password_hash($acct, PASSWORD_DEFAULT);
    $fn   = $firstNames[$i % count($firstNames)];
    $ln   = $lastNames[$i % count($lastNames)];
    $mn   = ['','','C.','D.','','E.','','F.','','G.'][$i % 10];
    $ext  = $i % 7 === 0 ? 'Jr.' : ($i % 11 === 0 ? 'III' : null);
    $cs   = $statuses[$i % count($statuses)];
    $gen  = $genders[$i % 2];
    $addr = ($barangays[$i % count($barangays)]) . ', ' . ($i % 2 === 0 ? 'Bulacan' : 'Nueva Ecija') . ', Philippines';
    $p    = $puroks[$i % count($puroks)];
    $email = strtolower($fn . '.' . $ln . $i . '@email.com');
    $phone = '09' . rand(100000000, 999999999);
    $bday  = date('Y-m-d', strtotime('-' . (18 + ($i % 55)) . ' years'));
    $age   = (int)date('Y') - (int)date('Y', strtotime($bday));
    $occ   = $occupations[$i % count($occupations)] ?? null;
    $emp   = $occ ? $employers[$i % count($employers)] ?? null : null;
    $empAddr = $emp ? ($i % 2 === 0 ? 'City Center, Bulacan' : 'Municipal Hall, Nueva Ecija') : null;
    $father = $genders[$i % 2] === 'Female' ? null : $fn . ' ' . $mn . ' ' . $ln;
    $mother = $genders[$i % 2] === 'Male' ? null : $fn . ' ' . $mn . ' ' . $ln;
    $ref1 = 'Reference Person A-' . $i;
    $ref2 = 'Reference Person B-' . $i;

    $relList = ['Friend','Neighbor','Coworker','Former Classmate','Church Member'];
    $ref1Rel = $relList[$i % count($relList)];
    $ref2Rel = $relList[($i + 3) % count($relList)];
    $refContact = '09' . rand(100000000, 999999999);

    $stmt = $pdo->prepare("INSERT INTO members (
        account_number, password, must_change_password,
        last_name, first_name, middle_name, extension_name,
        civil_status, gender, address, purok, email, contact_number, birthday, age,
        occupation, employer, employer_address,
        father_name, mother_name,
        reference1_name, reference1_relationship, reference1_contact, reference1_address,
        reference2_name, reference2_relationship, reference2_contact, reference2_address,
        created_at, updated_at
    ) VALUES (?,?,1,
             ?,?,?,?,
             ?,?,?,?,?,?,?,?,
             ?,?,?,
             ?,?,
             ?,?,?,?,
             ?,?,?,?,
             NOW() - INTERVAL ? DAY, NOW() - INTERVAL ? DAY)");

    $createdOffset = rand(1, 365);
    $updatedOffset = rand(0, $createdOffset);

    $stmt->execute([
        $acct, $pw,
        $ln, $fn, $mn ?: null, $ext,
        $cs, $gen, $addr, $p, $email, $phone, $bday, $age,
        $occ, $emp, $empAddr,
        $father, $mother,
        $ref1, $ref1Rel, $refContact, $addr,
        $ref2, $ref2Rel, $refContact, $addr,
        $createdOffset, $updatedOffset
    ]);

    $memberId = $pdo->lastInsertId();

    // Add spouse if Married
    if (in_array($cs, ['Married'])) {
        $spouseNames = $genders[$i % 2] === 'Female'
            ? ['Juan','Jose','Pedro','Carlos','Miguel']
            : ['Maria','Ana','Rosa','Elena','Sofia'];
        $spouseName = ($spouseNames[array_rand($spouseNames)]) . ' ' . $ln;

        $pdo->prepare("INSERT INTO spouse_info (member_id, spouse_name, occupation, employer)
                       VALUES (?,?,?,?)")->execute([
            $memberId,
            $spouseName,
            $occupations[($i + 3) % count($occupations)],
            $employers[($i + 2) % count($employers)]
        ]);

        // Add 1-2 children for some married members
        $childCount = ($i % 3 === 0) ? 2 : (($i % 5 === 0) ? 0 : 1);
        for ($c = 0; $c < $childCount; $c++) {
            $childNames = ['Michael','Angela','John','Catherine','Mark','Patricia','Dan','Maricar','Kevin','Rachel'];
            $childAge = rand(1, 17);
            $pdo->prepare("INSERT INTO children (member_id, child_name, age) VALUES (?,?,?)")
                ->execute([$memberId, $childNames[array_rand($childNames)] . ' ' . $ln, $childAge]);
        }
    }

    // Update logs
    $logSections = ['Personal Info','Contact Info','Spouse Info','Children','Parents'];
    $logCount = rand(1, 4);
    for ($l = 0; $l < $logCount; $l++) {
        $section = $logSections[array_rand($logSections)];
        $daysAgo = rand(1, 60);
        $pdo->prepare("INSERT INTO update_logs (member_id, updated_by, updated_by_name, section, updated_at)
                       VALUES (?, 'Staff', 'System Administrator', ?, NOW() - INTERVAL ? DAY)")
            ->execute([$memberId, $section, $daysAgo]);
    }

    echo "  $acct — $fn $ln ($cs) ✓\n";
}

echo "\n✅ 25 dummy records inserted.\n";
