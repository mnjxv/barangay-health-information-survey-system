-- User Management migration
-- Adds account activation flags so staff/resident accounts can be
-- deactivated and reactivated from the User Management module.
-- Safe to re-run (uses IF NOT EXISTS, supported in MariaDB 10.4+).

ALTER TABLE barangay_health_center.staff ADD COLUMN IF NOT EXISTS is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER email;
ALTER TABLE barangay_health_center.members ADD COLUMN IF NOT EXISTS is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER must_change_password;
