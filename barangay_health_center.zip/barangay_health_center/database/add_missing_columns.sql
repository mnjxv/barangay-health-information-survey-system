ALTER TABLE members
  ADD COLUMN reference1_relationship VARCHAR(50) DEFAULT NULL AFTER reference1_name,
  ADD COLUMN reference1_contact VARCHAR(20) DEFAULT NULL AFTER reference1_relationship,
  ADD COLUMN reference1_address VARCHAR(255) DEFAULT NULL AFTER reference1_contact,
  ADD COLUMN reference2_relationship VARCHAR(50) DEFAULT NULL AFTER reference2_name,
  ADD COLUMN reference2_contact VARCHAR(20) DEFAULT NULL AFTER reference2_relationship,
  ADD COLUMN reference2_address VARCHAR(255) DEFAULT NULL AFTER reference2_contact,
  ADD COLUMN emergency_contact_name VARCHAR(150) DEFAULT NULL AFTER reference2_address,
  ADD COLUMN emergency_contact_relationship VARCHAR(50) DEFAULT NULL AFTER emergency_contact_name,
  ADD COLUMN emergency_contact_number VARCHAR(20) DEFAULT NULL AFTER emergency_contact_relationship;
