# Web-Based Member Personal Information Updating System
### Multipurpose Cooperative -- IT 305 Advance Web Development (Act 5, Set A)

A full-stack HTML / CSS / JavaScript / PHP / MySQL system that lets
cooperative members log in and update their personal, contact, spouse, and
children's information online, while staff manage member accounts, records,
and reports.

---

## 1. Tech Stack (as required by the activity sheet)
- HTML5 -- pages and forms
- CSS3 -- custom stylesheet (`assets/css/style.css`), fully responsive
- JavaScript (vanilla) -- client-side validation, photo preview, dynamic
  child rows, age auto-calculation (`assets/js/validation.js`)
- PHP 8 (PDO) -- server-side logic, session-based auth, prepared statements
- MySQL -- relational database (`database/barangay_health_center.sql`)

## 2. Folder Structure
```
coop-system/
├── config/db.php              -> database connection (edit credentials here)
├── database/
│   ├── barangay_health_center.sql        -> full schema + seed data (import this)
│   ├── survey_module.sql                 -> survey tables (import once for the survey module)
│   ├── user_management.sql               -> adds account activation flags (import once)
│   └── generate_admin_hash.php-> one-time helper to (re)generate password hashes
├── includes/                  -> shared header, footer, sidebars, functions.php
│   └── survey_functions.php   -> survey helpers (results rebuild, live checks, etc.)
├── assets/css/style.css       -> global stylesheet
├── assets/js/validation.js    -> client-side validation & interactivity
├── index.php                  -> single login page (auto-detects member or staff)
├── member/                    -> member-facing pages
│   ├── change_password.php
│   ├── dashboard.php
│   ├── surveys.php             -> list of barangay health surveys
│   ├── survey_take.php         -> answer a survey (once per resident)
│   ├── update_info.php        -> personal / contact / spouse / children / photo
│   ├── print_profile.php
│   └── logout.php
├── staff/                     -> staff-facing pages
│   ├── dashboard.php
│   ├── add_member.php
│   ├── view_members.php
│   ├── search_member.php
│   ├── edit_member.php
│   ├── delete_member.php
│   ├── reset_password.php
│   ├── print_member.php
│   ├── updated_records.php    -> audit trail of profile changes
│   ├── reports.php
│   ├── surveys.php            -> manage surveys (create/edit/activate/delete)
│   ├── survey_builder.php     -> survey creation wizard with question builder
│   ├── survey_results.php     -> per-question results with charts
│   ├── survey_respondents.php -> list of respondents (remove a response)
│   ├── survey_report.php      -> print-friendly survey report
│   ├── survey_export.php      -> CSV export of all responses
│   ├── survey_status.php      -> activate/deactivate handler
│   ├── survey_delete.php      -> delete handler
│   ├── user_management.php    -> manage staff & resident accounts (tabs)
│   ├── add_staff.php          -> create a staff account
│   ├── edit_staff.php         -> edit staff details
│   ├── staff_status.php       -> activate/deactivate staff (blocks login)
│   ├── member_status.php      -> activate/deactivate resident accounts
│   ├── staff_delete.php       -> delete a staff account
│   ├── reset_staff_password.php -> reset staff password (shows once)
│   └── logout.php
└── uploads/photos/            -> member photo uploads
```

## 3. Login
There is a single login form at `index.php`. The account number / username
entered is checked against the `staff` table first, then the `members`
table -- the system automatically determines the role and redirects to the
correct dashboard. There is no separate "Member Login" / "Staff Login"
selection screen.

## 4. Setup Instructions (XAMPP / WAMP / LAMP)
1. Copy the `barangay_health_center` folder into your server's web root

   (e.g. `htdocs/barangay_health_center` for XAMPP).
2. Start Apache and MySQL.
3. Open phpMyAdmin, and import `database/barangay_health_center.sql`. It creates the
   `barangay_health_center` database, all tables, and seed data automatically.
4. Open `config/db.php` and confirm `DB_USER` / `DB_PASS` match your MySQL
   setup (defaults: `root` / empty password, standard for XAMPP).
5. Password hashes: the seed `.sql` file ships with a placeholder bcrypt
   hash. To be sure logins work on your machine, run
   `database/generate_admin_hash.php` once in your browser, copy the two
   `UPDATE` statements it prints, and run them in phpMyAdmin's SQL tab.
6. For the Survey module, also import `database/survey_module.sql` (creates
   the `survey_*` tables and `login_history`; safe to run after the main
   import).
7. For User Management, import `database/user_management.sql` (adds the
   `is_active` account flag to `staff` and `members`; safe to re-run).
8. Visit `http://localhost/barangay_health_center/` in your browser.

### Default accounts
| Role   | Account # / Username | Password    |
|--------|-----------------------|-------------|
| Staff  | `admin`               | `admin123`  |
| Member | `2026-0001`           | `2026-0001` |

Members are always forced to change their password on first login
(default password = their account number), per the functional requirements.

## 5. Functional Requirements Coverage

Member -- login by account number, default password = account number, forced
password change, view/update personal, contact, spouse, and children info,
upload passport photo, logout.

Staff -- secure login, dashboard, add member, view records, search, edit,
delete, reset password, view updated records (audit log), print member
info, generate reports, logout.

Member Information -- Personal, Spouse, Children, Parents, References
sections all implemented with matching database columns/tables.

Data Validation -- required-field checks and format checks (PH mobile
number, numeric age) run both client-side (JS) and server-side (PHP), with
inline error messages; incomplete submissions are rejected server-side.

Database -- all data stored in MySQL; updates use `UPDATE`/upsert logic
(never creates duplicate member rows) and children are safely re-synced per
save.

Surveys -- staff build surveys with multiple-choice, yes/no, rating (1-5),
and open-ended questions; residents answer active surveys once (a unique
constraint prevents duplicates). Responses are tallied into `survey_results`
for charted staff views, a printable report, and CSV export. Expired surveys
(end date passed) auto-close on page load, and the survey results page adds
analytics: response rate by purok, responses by civil status, and average
rating broken down by age group. The staff dashboard shows live counts for
Active Surveys, total Survey Responses, and the overall response rate (% of
residents who answered at least one survey).

User Management -- admins manage both staff and resident accounts from one
tabbed page: add/edit staff, activate/deactivate any account (deactivated
accounts cannot log in), reset staff or resident passwords, and delete
accounts. You cannot deactivate or delete your own staff account.

UI -- single shared responsive stylesheet, sidebar navigation, and
mobile-friendly grid layout.

## 6. Notes for the Video Presentation / Submission
- Take screenshots of: Login Page, Dashboard/Home Page, Update Personal
  Information Page, Successful Update Confirmation (each save produces a
  success alert banner).
- Export your final `barangay_health_center` database via phpMyAdmin as the `.sql`
  submission file.
- Document each group member's contributed module (e.g. Member module,
  Staff module, Database design, UI/CSS, Validation JS) for the "Members'
  participation" requirement.
