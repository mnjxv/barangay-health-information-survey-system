<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireStaffLogin();

$memberId = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM members WHERE member_id = ?");
$stmt->execute([$memberId]);
$member = $stmt->fetch();

if (!$member) {
    setFlash('danger', 'Resident not found.');
    redirect('view_members.php');
}

$resetDone = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrfToken();
    $hash = password_hash($member['account_number'], PASSWORD_DEFAULT);
    $upd = $pdo->prepare("UPDATE members SET password = ?, must_change_password = 1 WHERE member_id = ?");
    $upd->execute([$hash, $memberId]);

    logUpdate($pdo, $memberId, 'Staff', $_SESSION['staff_name'], 'Password Reset', 'Password reset to default (resident number) by staff.');
    addNotification($pdo, 'warning', 'Password Reset', "Your password was reset to your Resident Number by staff.", $memberId);
    addNotification($pdo, 'info', 'Password Reset', "Password for {$member['first_name']} {$member['last_name']} was reset.", null, $_SESSION['staff_id']);

    $resetDone = ['number' => $member['account_number'], 'name' => $member['first_name'] . ' ' . $member['last_name']];
}

$pageTitle = 'Reset Password';
$userLabel = $_SESSION['staff_name'];
$userRole = 'Staff';
$logoutUrl = 'logout.php';
$assetsPath = '../';
$hideTopbar = false;
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Reset Password']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content">
    <?php if ($resetDone): ?>
    <div style="display:flex;align-items:center;justify-content:center;min-height:50vh;">
      <div class="modal-card" style="max-width:420px;width:100%;text-align:center;">
        <div class="modal-icon" style="background:var(--warning);color:#fff;margin:0 auto 20px;">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:28px;height:28px;"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
        </div>
        <h2 style="margin:0 0 6px;">Password Reset</h2>
        <p style="color:var(--text-muted);margin:0 0 20px;">The password has been reset to the resident's number.</p>
        <table class="modal-details" style="margin:0 auto;">
          <tr><td>Resident No.</td><td><strong><?= e($resetDone['number']) ?></strong></td></tr>
          <tr><td>Full Name</td><td><strong><?= e($resetDone['name']) ?></strong></td></tr>
          <tr><td>New Password</td><td><strong><?= e($resetDone['number']) ?></strong></td></tr>
        </table>
        <p class="text-muted" style="font-size:0.82rem;margin-top:12px;">The resident will be required to change their password on next login.</p>
        <div style="margin-top:24px;">
          <a href="view_members.php" class="btn btn-primary btn-block">Continue to Residents List</a>
        </div>
      </div>
    </div>
    <?php else: ?>
    <div style="display:flex;align-items:center;justify-content:center;min-height:50vh;">
      <div class="card" style="max-width:500px;width:100%;">
        <div class="card-header"><h2>Reset Resident Password</h2></div>
        <p>Reset the password for <strong><?= e($member['first_name'] . ' ' . $member['last_name']) ?></strong>
        (Resident #: <?= e($member['account_number']) ?>) back to their default password (their resident number)?</p>
        <p class="text-muted">They will be required to set a new password on their next login.</p>
        <form method="POST" style="display:flex;gap:10px;">
          <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
          <a href="view_members.php" class="btn btn-secondary">Cancel</a>
          <button type="submit" class="btn btn-danger">Confirm Reset</button>
        </form>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
