<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireStaffLogin();

$errors = [];
$formData = [];

$year = date('Y');
$max = $pdo->query("SELECT MAX(CAST(SUBSTRING_INDEX(account_number, '-', -1) AS UNSIGNED)) FROM members WHERE account_number LIKE '$year-%'")->fetchColumn();
$nextNum = $max ? $max + 1 : 1;
$accountNumber = $year . '-' . str_pad($nextNum, 4, '0', STR_PAD_LEFT);

$purokDb = $pdo->query("SELECT DISTINCT purok FROM members WHERE purok IS NOT NULL AND purok != ''")->fetchAll(PDO::FETCH_COLUMN);
$purokAll = range(1, 20);
$purokAll = array_map(function($n) { return "Purok $n"; }, $purokAll);
$purokList = array_values(array_unique(array_merge($purokAll, $purokDb)));
natsort($purokList); $purokList = array_values($purokList);

$occupations = ['Student','Teacher','Nurse','Doctor','Engineer','Accountant','Business Owner','Government Employee','OFW','Farmer','Fisherman','Driver','Vendor','Homemaker','Retired','Unemployed','Self-Employed','None','Other'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrfToken();
    $formData = $_POST;
    $lastName  = trim($_POST['last_name'] ?? '');
    $firstName = trim($_POST['first_name'] ?? '');
    $middleName = trim($_POST['middle_name'] ?? '');
    $extName   = trim($_POST['extension_name'] ?? '');
    $civilStatus = $_POST['civil_status'] ?? 'Single';
    $gender    = $_POST['gender'] ?? null;
    $addressHousehold  = trim($_POST['address_household'] ?? '');
    $addressBarangay   = trim($_POST['address_barangay'] ?? '');
    $addressMunicipality = trim($_POST['address_municipality'] ?? '');
    $addressProvince   = trim($_POST['address_province'] ?? '');
    $addressPostal     = trim($_POST['address_postal'] ?? '');
    $addressCountry    = trim($_POST['address_country'] ?? '');
    $purok     = trim($_POST['purok'] ?? '');
    $address   = buildAddress($addressHousehold, $purok, $addressBarangay, $addressMunicipality, $addressProvince, $addressPostal, $addressCountry);
    $contact   = trim($_POST['contact_number'] ?? '');
    $hotline   = trim($_POST['hotline'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $birthday  = $_POST['birthday'] ?? null;
    $occupation = $_POST['occupation'] ?? '';
    if ($occupation === 'Other') {
        $occupation = trim($_POST['occupation_other'] ?? '');
    }
    $employer  = trim($_POST['employer'] ?? '');
    $employerAddress = trim($_POST['employer_address'] ?? '');
    $fatherName = trim($_POST['father_name'] ?? '');
    $motherName = trim($_POST['mother_name'] ?? '');
    $ref1 = trim($_POST['reference1_name'] ?? '');
    $ref1Rel = trim($_POST['reference1_relationship'] ?? '');
    $ref1Contact = trim($_POST['reference1_contact'] ?? '');
    $ref1Addr = trim($_POST['reference1_address'] ?? '');
    $ref2 = trim($_POST['reference2_name'] ?? '');
    $ref2Rel = trim($_POST['reference2_relationship'] ?? '');
    $ref2Contact = trim($_POST['reference2_contact'] ?? '');
    $ref2Addr = trim($_POST['reference2_address'] ?? '');
    $emergencyName = trim($_POST['emergency_contact_name'] ?? '');
    $emergencyRel = trim($_POST['emergency_contact_relationship'] ?? '');
    $emergencyNumber = trim($_POST['emergency_contact_number'] ?? '');
    $spouseName = trim($_POST['spouse_name'] ?? '');
    $spouseOccupation = trim($_POST['spouse_occupation'] ?? '');
    $spouseEmployer = trim($_POST['spouse_employer'] ?? '');
    $childNames = $_POST['child_name'] ?? [];
    $childAges  = $_POST['child_age'] ?? [];

    if ($lastName === '') $errors[] = 'Last name is required.';
    if ($firstName === '') $errors[] = 'First name is required.';
    if ($civilStatus === '' || $civilStatus === null) $errors[] = 'Civil status is required.';
    if ($address === '') $errors[] = 'Address is required (fill in at least one address field).';
    if ($purok === '') $errors[] = 'Purok is required.';
    if ($birthday === '' || $birthday === null) {
        $errors[] = 'Birthday is required.';
    } elseif (!isValidDateString($birthday)) {
        $errors[] = 'Birthday is not a valid date (e.g. February 31 is impossible).';
    } elseif ($birthday > date('Y-m-d')) {
        $errors[] = 'Birthday cannot be a future date.';
    }
    if ($contact === '') {
        $errors[] = 'Contact number is required.';
    } elseif (!preg_match('/^(09\d{9}|\+639\d{9})$/', $contact)) {
        $errors[] = 'Contact number must be a valid PH mobile number.';
    }
    if ($hotline !== '' && !preg_match('/^(09\d{9}|\+639\d{9}|[0-9\-\s]{7,15})$/', $hotline)) {
        $errors[] = 'Hotline number must be a valid PH mobile or landline number.';
    }
    if ($occupation === '') $errors[] = 'Occupation is required.';
    if ($employerAddress === '') $errors[] = 'Employer address is required.';
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email format.';
    if ($ref1 === '') $errors[] = 'Character Reference 1 full name is required.';
    if ($ref1Rel === '') $errors[] = 'Character Reference 1 relationship is required.';
    if ($ref2 === '') $errors[] = 'Character Reference 2 full name is required.';
    if ($ref2Rel === '') $errors[] = 'Character Reference 2 relationship is required.';

    if (empty($errors)) {
        $age = calculateAge($birthday);
        $hash = password_hash($accountNumber, PASSWORD_DEFAULT);

        $photoPath = null;
        if (!empty($_FILES['photo']['name'])) {
            $file = $_FILES['photo'];
            $uploadErr = '';
            if (validateImageUpload($file, $uploadErr)) {
                $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                $fn = 'member_' . time() . '_' . rand(100,999) . '.' . $ext;
                $dest = __DIR__ . '/../uploads/photos/' . $fn;
                if (move_uploaded_file($file['tmp_name'], $dest)) {
                    $photoPath = 'uploads/photos/' . $fn;
                } else {
                    $errors[] = 'Could not save the uploaded photo.';
                }
            } else {
                $errors[] = $uploadErr;
            }
        }

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare(
                "INSERT INTO members (account_number, password, must_change_password, last_name, first_name, middle_name, extension_name, civil_status, gender, address, address_household, address_barangay, address_municipality, address_province, address_postal, address_country, purok, email, contact_number, hotline, birthday, age, occupation, employer, employer_address, father_name, mother_name, reference1_name, reference1_relationship, reference1_contact, reference1_address, reference2_name, reference2_relationship, reference2_contact, reference2_address, emergency_contact_name, emergency_contact_relationship, emergency_contact_number, photo_path)
                 VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );
            $stmt->execute([
                $accountNumber, $hash,
                $lastName, $firstName, $middleName ?: null, $extName ?: null,
                $civilStatus, $gender, $address ?: null,
                $addressHousehold ?: null, $addressBarangay ?: null, $addressMunicipality ?: null, $addressProvince ?: null, $addressPostal ?: null, $addressCountry ?: null,
                $purok ?: null, $email ?: null, $contact ?: null, $hotline ?: null, $birthday ?: null, $age,
                $occupation ?: null, $employer ?: null, $employerAddress ?: null,
                $fatherName ?: null, $motherName ?: null,
                $ref1 ?: null, $ref1Rel ?: null, $ref1Contact ?: null, $ref1Addr ?: null,
                $ref2 ?: null, $ref2Rel ?: null, $ref2Contact ?: null, $ref2Addr ?: null,
                $emergencyName ?: null, $emergencyRel ?: null, $emergencyNumber ?: null,
                $photoPath
            ]);
            $newId = $pdo->lastInsertId();

            if ($spouseName !== '') {
                $insSpouse = $pdo->prepare("INSERT INTO spouse_info (member_id, spouse_name, occupation, employer) VALUES (?, ?, ?, ?)");
                $insSpouse->execute([$newId, $spouseName, $spouseOccupation ?: null, $spouseEmployer ?: null]);
            }

            $insChild = $pdo->prepare("INSERT INTO children (member_id, child_name, age) VALUES (?, ?, ?)");
            foreach ($childNames as $i => $name) {
                $name = trim($name);
                if ($name === '') continue;
                $childAge = isset($childAges[$i]) && $childAges[$i] !== '' ? (int)$childAges[$i] : null;
                $insChild->execute([$newId, $name, $childAge]);
            }

            logUpdate($pdo, $newId, 'Staff', $_SESSION['staff_name'], 'Resident Account Created', 'New resident registered by staff.');
            addNotification($pdo, 'success', 'New Resident Created', "$firstName $lastName (Resident #$accountNumber) has been registered.", null, $_SESSION['staff_id']);
            addNotification($pdo, 'info', 'Welcome!', 'Your account has been created. Your default password is your Resident Number. Please change it on first login.', $newId);

            $pdo->commit();
            $accountCreated = ['number' => $accountNumber, 'name' => "$firstName $lastName"];
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = 'An error occurred while saving.';
        }
    }
}

$pageTitle = 'Add New Resident';
$userLabel = $_SESSION['staff_name'];
$userRole = 'Staff';
$logoutUrl = 'logout.php';
$assetsPath = '../';
$hideTopbar = false;
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Residents','url'=>'view_members.php'], ['label'=>'Add New Resident']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content">

    <?php if (!empty($errors)): ?>
      <div class="alert alert-danger">
        <ul style="margin:0 0 0 18px;"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
      </div>
    <?php endif; ?>

    <div class="alert alert-info">Default password will be set to the resident's Resident Number. They must change it on first login.</div>

    <form method="POST" enctype="multipart/form-data" id="addMemberForm" data-validate novalidate>
      <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
      <div class="profile-layout">
        <div>
          <div class="profile-card">
            <div>
              <div id="photoPreview" style="width:145px;height:187px;border-radius:3px;margin:0 auto;background:var(--bg-secondary);border:3px solid #fff;box-shadow:0 2px 10px rgba(0,0,0,0.15);display:flex;align-items:center;justify-content:center;font-size:2rem;font-weight:700;color:var(--text-dim);overflow:hidden;object-fit:cover;"></div>
              <div style="margin-top:12px;">
                <div class="drop-zone" style="padding:16px 12px;">
                  <div class="drop-zone-icon" style="width:36px;height:36px;margin-bottom:8px;">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:18px;height:18px;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                  </div>
                  <div class="drop-zone-text" style="font-size:0.78rem;">Drop photo here or click to browse</div>
                  <div class="drop-zone-hint" style="font-size:0.68rem;">JPG/PNG, max 2MB</div>
                  <input type="file" id="photoInput" name="photo" accept="image/png, image/jpeg">
                  <div class="drop-zone-preview">
                    <img class="dz-img" style="display:none;">
                    <div class="dz-meta"><div class="dz-name"></div><div class="dz-size"></div></div>
                    <span class="dz-remove" onclick="var p=this.closest('.drop-zone-preview');p.classList.remove('show');this.closest('.drop-zone').querySelector('input[type=file]').value='';event.stopPropagation();">Remove</span>
                  </div>
                </div>
                <button type="button" class="btn btn-primary btn-block profile-save-photo" id="savePhotoBtn" style="display:none;margin-top:12px;">Save</button>
              </div>
            </div>
            <h3 class="profile-name" style="margin-top:16px;">New Resident</h3>
            <div class="profile-account">Resident #<?= e($accountNumber) ?></div>
            <div class="profile-meta" style="margin-top:16px;">
              <div class="meta-row">
                <span class="meta-label">Account No.</span>
                <span class="meta-value"><?= e($accountNumber) ?></span>
              </div>
              <div class="meta-row">
                <span class="meta-label">Default Password</span>
                <span class="meta-value"><?= e($accountNumber) ?></span>
              </div>
            </div>
          </div>
        </div>

        <div class="form-stack">
          <div class="form-section">
            <h3 class="section-title">Personal Information</h3>
            <div class="card">
              <div class="form-grid cols-3">
                <div class="form-group"><label>Resident Number</label><input type="text" value="<?= e($accountNumber) ?>" disabled><input type="hidden" name="account_number" value="<?= e($accountNumber) ?>"></div>
                <div class="form-group"><label>Last Name <span class="required">*</span></label><input type="text" name="last_name" data-required placeholder="Enter last name" value="<?= e($formData['last_name'] ?? '') ?>"></div>
                <div class="form-group"><label>First Name <span class="required">*</span></label><input type="text" name="first_name" data-required placeholder="Enter first name" value="<?= e($formData['first_name'] ?? '') ?>"></div>
                <div class="form-group"><label>Middle Name</label><input type="text" name="middle_name" placeholder="Enter middle name (optional)" value="<?= e($formData['middle_name'] ?? '') ?>"></div>
                <div class="form-group"><label>Extension Name</label><input type="text" name="extension_name" placeholder="Jr., Sr., III" value="<?= e($formData['extension_name'] ?? '') ?>"></div>
                <div class="form-group">
                  <label>Civil Status <span class="required">*</span></label>
                  <select name="civil_status" data-required>
                    <option value="" disabled <?= empty($formData['civil_status']) ? 'selected' : '' ?>>Select civil status</option>
                    <?php foreach (['Single','Married','Widowed','Separated','Divorced'] as $cs): ?>
                      <option value="<?= $cs ?>" <?= (($formData['civil_status'] ?? '') === $cs) ? 'selected' : '' ?>><?= $cs ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="form-group">
                  <label>Gender</label>
                  <select name="gender">
                    <option value="" disabled <?= empty($formData['gender']) ? 'selected' : '' ?>>Select gender</option>
                    <option value="Male" <?= ($formData['gender'] ?? '') === 'Male' ? 'selected' : '' ?>>Male</option>
                    <option value="Female" <?= ($formData['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>Female</option>
                  </select>
                </div>
                <div class="form-group"><label>Birthday <span class="required">*</span></label><input type="date" id="birthday" name="birthday" data-required placeholder="Select birthday" value="<?= e($formData['birthday'] ?? '') ?>"></div>
                <div class="form-group"><label>Age <span style="color:var(--text-dim);font-weight:400;">(auto)</span></label><input type="number" id="age" name="age" data-type="age" readonly placeholder="Auto-calculated" value="<?= e($formData['age'] ?? '') ?>"></div>
                <div class="form-group">
                  <label>Occupation <span class="required">*</span></label>
                  <select name="occupation" id="occupationSelect" data-required>
                    <option value="" disabled <?= empty($formData['occupation']) ? 'selected' : '' ?>>Select occupation</option>
                    <?php foreach ($occupations as $oc): ?>
                      <option value="<?= e($oc) ?>" <?= ($formData['occupation'] ?? '') === $oc ? 'selected' : '' ?>><?= e($oc) ?></option>
                    <?php endforeach; ?>
                  </select>
                  <input type="text" name="occupation_other" id="occupationOther" placeholder="Type your occupation" style="display:none;margin-top:8px;">
                </div>
                <div class="form-group"><label>Employer</label><input type="text" name="employer" placeholder="Enter employer" value="<?= e($formData['employer'] ?? '') ?>"></div>
                <div class="form-group" style="grid-column:span 2;"><label>Employer Address <span class="required">*</span></label><input type="text" name="employer_address" data-required placeholder="Enter employer address" value="<?= e($formData['employer_address'] ?? '') ?>"></div>
              </div>
            </div>
          </div>

          <div class="form-section">
            <h3 class="section-title">Contact Information</h3>
            <div class="card">
              <div class="form-grid">
                <div class="form-group"><label>Household No. <span class="required">*</span></label><input type="text" name="address_household" data-required placeholder="e.g. Blk 12 Lot 5" value="<?= e($formData['address_household'] ?? '') ?>"></div>
                <div class="form-group"><label>Purok / Subdivision <span class="required">*</span></label>
                  <select name="purok" data-required style="font-family:inherit;">
                    <option value="" disabled <?= empty($formData['purok']) ? 'selected' : '' ?>>Select purok</option>
                    <?php foreach ($purokList as $p): ?>
                      <option value="<?= e($p) ?>" <?= ($formData['purok'] ?? '') === $p ? 'selected' : '' ?>><?= e($p) ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="form-group"><label>Barangay <span class="required">*</span></label><input type="text" name="address_barangay" data-required placeholder="Enter barangay" value="<?= e($formData['address_barangay'] ?? '') ?>"></div>
                <div class="form-group"><label>Municipality / City <span class="required">*</span></label><input type="text" name="address_municipality" data-required placeholder="Enter municipality / city" value="<?= e($formData['address_municipality'] ?? '') ?>"></div>
                <div class="form-group"><label>Province <span class="required">*</span></label><input type="text" name="address_province" data-required placeholder="Enter province" value="<?= e($formData['address_province'] ?? '') ?>"></div>
                <div class="form-group"><label>Postal Code</label><input type="text" name="address_postal" placeholder="e.g. 3020" value="<?= e($formData['address_postal'] ?? '') ?>"></div>
                <div class="form-group"><label>Country</label><input type="text" name="address_country" placeholder="e.g. Philippines" value="<?= e($formData['address_country'] ?? '') ?>"></div>
                <div class="form-group"><label>Contact Number <span class="required">*</span></label><input type="text" name="contact_number" data-required data-type="contact" placeholder="09171234567" value="<?= e($formData['contact_number'] ?? '') ?>"></div>
                <div class="form-group"><label>Hotline / Alternate Number</label><input type="text" name="hotline" data-type="contact" placeholder="Optional" value="<?= e($formData['hotline'] ?? '') ?>"></div>
                <div class="form-group"><label>Email</label><input type="email" name="email" placeholder="resident@email.com" value="<?= e($formData['email'] ?? '') ?>"></div>
              </div>
            </div>
          </div>

          <div class="form-section">
            <h3 class="section-title">Spouse Information</h3>
            <div class="card">
              <div class="form-grid cols-3">
                <div class="form-group"><label>Spouse Name</label><input type="text" name="spouse_name" placeholder="Enter spouse name" value="<?= e($formData['spouse_name'] ?? '') ?>"></div>
                <div class="form-group"><label>Occupation</label><input type="text" name="spouse_occupation" placeholder="Enter spouse occupation" value="<?= e($formData['spouse_occupation'] ?? '') ?>"></div>
                <div class="form-group"><label>Employer</label><input type="text" name="spouse_employer" placeholder="Enter spouse employer" value="<?= e($formData['spouse_employer'] ?? '') ?>"></div>
              </div>
            </div>
          </div>

          <div class="form-section">
            <h3 class="section-title">Children</h3>
            <div class="card">
              <div id="childrenContainer">
                <div class="form-grid child-row" style="margin-bottom:10px;">
                  <div class="form-group"><label>Child Name</label><input type="text" name="child_name[]" placeholder="Enter child name" value="<?= e($formData['child_name'][0] ?? '') ?>"></div>
                  <div class="form-group"><label>Age</label><input type="number" name="child_age[]" data-type="age" placeholder="Enter age" value="<?= e($formData['child_age'][0] ?? '') ?>"></div>
                </div>
              </div>
              <button type="button" class="btn btn-secondary btn-sm" id="addChildBtn">+ Add Child</button>
            </div>
          </div>

          <div class="form-section">
            <h3 class="section-title">Parents</h3>
            <div class="card">
              <div class="form-grid">
                <div class="form-group"><label>Father's Name</label><input type="text" name="father_name" placeholder="Enter father's name" value="<?= e($formData['father_name'] ?? '') ?>"></div>
                <div class="form-group"><label>Mother's Name</label><input type="text" name="mother_name" placeholder="Enter mother's name" value="<?= e($formData['mother_name'] ?? '') ?>"></div>
              </div>
            </div>
          </div>

          <div class="form-section">
            <h3 class="section-title">Character References</h3>
            <div class="card">
              <p style="font-size:0.82rem;color:var(--text-muted);margin-bottom:16px;">Provide two (2) character references who are <strong>not family members</strong> and who personally know you.</p>
              <div style="border:1px solid var(--border);border-radius:var(--radius-sm);padding:16px;margin-bottom:16px;">
                <h4 style="font-size:0.85rem;font-weight:600;margin-bottom:12px;">Character Reference 1 <span class="required">*</span></h4>
                <div class="form-grid cols-2">
                  <div class="form-group"><label>Full Name <span class="required">*</span></label><input type="text" name="reference1_name" data-required placeholder="Enter full name" value="<?= e($formData['reference1_name'] ?? '') ?>"></div>
                  <div class="form-group"><label>Relationship <span class="required">*</span></label><input type="text" name="reference1_relationship" data-required placeholder="Friend, Neighbor, Coworker, etc." value="<?= e($formData['reference1_relationship'] ?? '') ?>"></div>
                  <div class="form-group"><label>Contact Number</label><input type="text" name="reference1_contact" data-type="contact" placeholder="09171234567" value="<?= e($formData['reference1_contact'] ?? '') ?>"></div>
                  <div class="form-group"><label>Address</label><input type="text" name="reference1_address" placeholder="Enter address" value="<?= e($formData['reference1_address'] ?? '') ?>"></div>
                </div>
              </div>
              <div style="border:1px solid var(--border);border-radius:var(--radius-sm);padding:16px;margin-bottom:16px;">
                <h4 style="font-size:0.85rem;font-weight:600;margin-bottom:12px;">Character Reference 2 <span class="required">*</span></h4>
                <div class="form-grid cols-2">
                  <div class="form-group"><label>Full Name <span class="required">*</span></label><input type="text" name="reference2_name" data-required placeholder="Enter full name" value="<?= e($formData['reference2_name'] ?? '') ?>"></div>
                  <div class="form-group"><label>Relationship <span class="required">*</span></label><input type="text" name="reference2_relationship" data-required placeholder="Friend, Neighbor, Coworker, etc." value="<?= e($formData['reference2_relationship'] ?? '') ?>"></div>
                  <div class="form-group"><label>Contact Number</label><input type="text" name="reference2_contact" data-type="contact" placeholder="09171234567" value="<?= e($formData['reference2_contact'] ?? '') ?>"></div>
                  <div class="form-group"><label>Address</label><input type="text" name="reference2_address" placeholder="Enter address" value="<?= e($formData['reference2_address'] ?? '') ?>"></div>
                </div>
              </div>
            </div>
          </div>

          <div class="form-section">
            <h3 class="section-title">Emergency Contact</h3>
            <div class="card">
              <div class="form-grid">
                <div class="form-group"><label>Emergency Contact Name</label><input type="text" name="emergency_contact_name" placeholder="Enter full name" value="<?= e($formData['emergency_contact_name'] ?? '') ?>"></div>
                <div class="form-group"><label>Relationship</label><input type="text" name="emergency_contact_relationship" placeholder="Spouse, Parent, Sibling, etc." value="<?= e($formData['emergency_contact_relationship'] ?? '') ?>"></div>
                <div class="form-group"><label>Contact Number</label><input type="text" name="emergency_contact_number" data-type="contact" placeholder="09171234567" value="<?= e($formData['emergency_contact_number'] ?? '') ?>"></div>
              </div>
            </div>
          </div>

          <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:20px;">
            <a href="view_members.php" class="btn btn-secondary">Cancel</a>
            <button type="button" class="btn btn-primary" id="addConfirmTrigger">Create Resident</button>
          </div>
        </div>
      </div>
    </form>
  </div>
</div>

<?php if (!empty($accountCreated)): ?>
<div class="modal-overlay" id="successModal">
  <div class="modal-card">
    <div class="modal-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:28px;height:28px;"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
      </div>
      <h2>Account Created</h2>
    <p style="margin-bottom:20px;">A new resident account has been created successfully.</p>
    <table class="modal-details">
      <tr><td>Resident No.</td><td><strong><?= e($accountCreated['number']) ?></strong></td></tr>
      <tr><td>Full Name</td><td><strong><?= e($accountCreated['name']) ?></strong></td></tr>
      <tr><td>Default Password</td><td><strong><?= e($accountCreated['number']) ?></strong></td></tr>
    </table>
    <p class="text-muted" style="font-size:0.82rem;">The resident will be required to change their password on first login.</p>
    <a href="view_members.php" class="btn btn-primary btn-block">Continue to Residents List</a>
  </div>
</div>
<?php if (!empty($accountCreated)): ?>
<script>document.getElementById('successModal').style.display = 'flex';</script>
<?php endif; ?>
<?php endif; ?>

<div class="modal-overlay" id="addConfirmModal">
  <div class="modal-card">
    <div class="modal-icon" style="background:var(--primary);color:#fff;">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:28px;height:28px;"><path d="M12 5v14"/><path d="M5 12h14"/></svg>
    </div>
    <h2 style="margin:0 0 6px;">Create Account</h2>
    <p style="color:var(--text-muted);margin:0 0 20px;">Are you sure you want to create this resident account?</p>
    <div style="display:flex;gap:10px;justify-content:center;">
      <button type="button" class="btn btn-secondary" onclick="document.getElementById('addConfirmModal').style.display='none'">Cancel</button>
      <button type="button" class="btn btn-primary" id="addConfirmAction">Create</button>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  var aForm = document.getElementById('addMemberForm');

  bindAgeAutoCalc('birthday', 'age');

  var photoInput = document.getElementById('photoInput');
  var photoPreview = document.getElementById('photoPreview');
  if (photoInput && photoPreview) {
    photoInput.addEventListener('change', function() {
      var file = this.files[0];
      if (file) {
        var reader = new FileReader();
        reader.onload = function(e) {
          photoPreview.innerHTML = '';
          photoPreview.style.backgroundImage = 'url(' + e.target.result + ')';
          photoPreview.style.backgroundSize = 'cover';
          photoPreview.style.backgroundPosition = 'center';
        };
        reader.readAsDataURL(file);
      }
    });
  }

  var occSelect = document.getElementById('occupationSelect');
  var occOther = document.getElementById('occupationOther');
  function toggleOccOther() {
    if (occSelect && occOther) {
      if (occSelect.value === 'Other') {
        occOther.style.display = 'block';
        occOther.setAttribute('data-required', '');
      } else {
        occOther.style.display = 'none';
        occOther.removeAttribute('data-required');
        occOther.value = '';
      }
    }
  }
  if (occSelect) {
    occSelect.addEventListener('change', toggleOccOther);
    toggleOccOther();
  }

  document.getElementById('addChildBtn').addEventListener('click', function() {
    var container = document.getElementById('childrenContainer');
    var row = document.createElement('div');
    row.className = 'form-grid child-row';
    row.style.marginBottom = '10px';
    row.innerHTML =
      '<div class="form-group"><label>Child Name</label><input type="text" name="child_name[]" placeholder="Enter child name"></div>' +
      '<div class="form-group"><label>Age</label><input type="number" name="child_age[]" data-type="age" placeholder="Enter age">' +
        '<button type="button" class="btn btn-danger btn-sm remove-child" style="margin-top:6px;">Remove</button>' +
      '</div>';
    container.appendChild(row);
    row.querySelector('.remove-child').addEventListener('click', function() { row.remove(); });
  });

  document.querySelectorAll('.remove-child').forEach(function(btn) {
    btn.addEventListener('click', function() { this.closest('.child-row').remove(); });
  });

  var aBtn = document.getElementById('addConfirmTrigger');
  var aModal = document.getElementById('addConfirmModal');
  if (aBtn && aModal) {
    aBtn.addEventListener('click', function(e) {
      if (aForm.dataset.confirming !== '1') {
        e.preventDefault();
        aModal.style.display = 'flex';
      }
    });
  }
  document.getElementById('addConfirmAction').addEventListener('click', function() {
    if (typeof showValidationSummary === 'function' && !showValidationSummary(aForm)) {
      document.getElementById('addConfirmModal').style.display = 'none';
      return;
    }
    aForm.dataset.confirming = '1';
    aForm.submit();
    document.getElementById('addConfirmModal').style.display = 'none';
  });

  var savePhotoBtn = document.getElementById('savePhotoBtn');
  if (savePhotoBtn && aBtn && aModal) {
    savePhotoBtn.addEventListener('click', function(e) {
      e.preventDefault();
      if (aForm.dataset.confirming !== '1') {
        aModal.style.display = 'flex';
      }
    });
  }
});
</script>
<?php require_once '../includes/footer.php'; ?>
