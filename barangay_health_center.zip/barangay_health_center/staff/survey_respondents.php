<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
require_once '../includes/survey_functions.php';
requireStaffLogin();

$surveyId = (int)($_GET['id'] ?? 0);
$survey = getSurvey($pdo, $surveyId);
if (!$survey) redirect('surveys.php');

$errors = [];
$flashMsg = '';

// Remove a single response
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_response'])) {
    requireCsrfToken();
    $responseId = (int)($_POST['remove_response'] ?? 0);
    $stmt = $pdo->prepare("SELECT response_id FROM survey_responses WHERE response_id = ? AND survey_id = ?");
    $stmt->execute([$responseId, $surveyId]);
    if ($stmt->fetch()) {
        $pdo->beginTransaction();
        try {
            $pdo->prepare("DELETE FROM survey_responses WHERE response_id = ?")->execute([$responseId]);
            rebuildSurveyResults($pdo, $surveyId);
            $pdo->commit();
            $flashMsg = 'Response removed successfully.';
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = 'Could not remove the response.';
        }
    } else {
        $errors[] = 'Response not found.';
    }
}

$stmt = $pdo->prepare(
    "SELECT r.response_id, r.submitted_at, m.member_id, m.account_number, m.first_name, m.last_name, m.purok, m.contact_number
     FROM survey_responses r
     JOIN members m ON m.member_id = r.member_id
     WHERE r.survey_id = ?
     ORDER BY r.submitted_at DESC"
);
$stmt->execute([$surveyId]);
$respondents = $stmt->fetchAll();

$pageTitle = 'Survey Respondents';
$userLabel = $_SESSION['staff_name'];
$userRole = 'Staff';
$logoutUrl = 'logout.php';
$assetsPath = '../';
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Surveys','url'=>'surveys.php'], ['label'=>'Respondents']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content">
    <div class="card">
      <div class="card-header">
        <h2>Respondents — <?= e($survey['title']) ?> (<?= count($respondents) ?>)</h2>
        <div style="display:flex;gap:8px;">
          <a href="survey_results.php?id=<?= (int)$surveyId ?>" class="btn btn-sm btn-primary">View Results</a>
          <a href="survey_report.php?id=<?= (int)$surveyId ?>" class="btn btn-sm btn-secondary">Report</a>
        </div>
      </div>

      <?php if ($flashMsg): ?><div class="alert alert-success"><?= e($flashMsg) ?></div><?php endif; ?>
      <?php if (!empty($errors)): ?><div class="alert alert-danger"><?php foreach ($errors as $err): ?><div><?= e($err) ?></div><?php endforeach; ?></div><?php endif; ?>

      <?php if (count($respondents) === 0): ?>
        <div class="empty-state with-icon">
          <div class="empty-state-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
          </div>
          <div class="empty-state-title">No respondents yet</div>
          <div class="empty-state-desc">Residents who submit this survey will appear here.</div>
        </div>
      <?php else: ?>
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Resident #</th><th>Name</th><th>Purok</th><th>Contact</th><th>Submitted</th><th style="width:90px;">Action</th></tr>
          </thead>
          <tbody>
            <?php foreach ($respondents as $r): ?>
              <tr>
                <td><strong><?= e($r['account_number']) ?></strong></td>
                <td><?= e($r['last_name'] . ', ' . $r['first_name']) ?></td>
                <td><?= e(na($r['purok'])) ?></td>
                <td><?= e(na($r['contact_number'])) ?></td>
                <td style="white-space:nowrap;"><?= date('M d, Y h:i A', strtotime($r['submitted_at'])) ?></td>
                <td>
                  <form method="POST" onsubmit="return confirm('Remove this resident\\'s response? This cannot be undone.')" style="display:inline;">
                    <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
                    <input type="hidden" name="remove_response" value="<?= (int)$r['response_id'] ?>">
                    <button type="submit" class="btn btn-sm btn-danger">Remove</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>