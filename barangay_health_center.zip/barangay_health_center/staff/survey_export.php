<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
require_once '../includes/survey_functions.php';
requireStaffLogin();

$surveyId = (int)($_GET['id'] ?? 0);
$survey = getSurvey($pdo, $surveyId);
if (!$survey) redirect('surveys.php');

$questions = getSurveyQuestions($pdo, $surveyId);

// All responses with their answers
$stmt = $pdo->prepare(
    "SELECT r.response_id, r.submitted_at,
            m.account_number, m.last_name, m.first_name, m.middle_name, m.purok, m.contact_number,
            a.question_id, a.choice_id, a.rating_value, a.answer_text, c.choice_text
     FROM survey_responses r
     JOIN members m ON m.member_id = r.member_id
     LEFT JOIN survey_answers a ON a.response_id = r.response_id
     LEFT JOIN survey_choices c ON c.choice_id = a.choice_id
     WHERE r.survey_id = ?
     ORDER BY r.submitted_at, a.question_id"
);
$stmt->execute([$surveyId]);
$rows = $stmt->fetchAll();

$map = [];
foreach ($rows as $r) {
    $rid = (int)$r['response_id'];
    if (!isset($map[$rid])) {
        $map[$rid] = [
            'account_number' => $r['account_number'],
            'name'           => trim($r['last_name'] . ', ' . $r['first_name'] . ($r['middle_name'] ? ' ' . $r['middle_name'] : '')),
            'purok'          => $r['purok'] ?? '',
            'contact'        => $r['contact_number'] ?? '',
            'submitted_at'   => $r['submitted_at'],
            'answers'        => [],
        ];
    }
    $qid = (int)$r['question_id'];
    if ($r['choice_id'] !== null) {
        $map[$rid]['answers'][$qid] = $r['choice_text'] ?? '';
    } elseif ($r['rating_value'] !== null) {
        $map[$rid]['answers'][$qid] = $r['rating_value'] . ' / 5';
    } else {
        $map[$rid]['answers'][$qid] = $r['answer_text'] ?? '';
    }
}

// Build CSV
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="survey_' . $surveyId . '_responses_' . date('Ymd') . '.csv"');
$out = fopen('php://output', 'w');

// BOM for Excel
fwrite($out, "\xEF\xBB\xBF");

$header = ['Resident #', 'Name', 'Purok', 'Contact', 'Submitted'];
foreach ($questions as $i => $q) {
    $header[] = 'Q' . ($i + 1) . ': ' . $q['question_text'];
}
fputcsv($out, $header);

foreach ($map as $row) {
    $line = [$row['account_number'], $row['name'], $row['purok'], $row['contact'], $row['submitted_at']];
    foreach ($questions as $q) {
        $line[] = $row['answers'][(int)$q['question_id']] ?? '';
    }
    fputcsv($out, $line);
}

fclose($out);
exit;