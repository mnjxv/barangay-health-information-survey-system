<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireStaffLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('surveys.php');
}
requireCsrfToken();

$id = (int)($_POST['id'] ?? 0);

$stmt = $pdo->prepare("SELECT survey_id FROM survey_surveys WHERE survey_id = ?");
$stmt->execute([$id]);
if (!$stmt->fetch()) {
    setFlash('danger', 'Survey not found.');
    redirect('surveys.php');
}

// Cascading deletes remove questions, choices, responses, answers, and results
$pdo->prepare("DELETE FROM survey_surveys WHERE survey_id = ?")->execute([$id]);

setFlash('success', 'Survey deleted successfully.');
redirect('surveys.php');
