<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
require_once '../includes/survey_functions.php';
requireStaffLogin();
autoCloseExpiredSurveys($pdo);

$totalMembers = $pdo->query("SELECT COUNT(*) FROM members")->fetchColumn();
$pendingUpdates = $pdo->query("SELECT COUNT(*) FROM update_logs WHERE updated_at >= (NOW() - INTERVAL 7 DAY)")->fetchColumn();
$marriedMembers = $pdo->query("SELECT COUNT(*) FROM members WHERE civil_status = 'Married'")->fetchColumn();
$withChildren = $pdo->query("SELECT COUNT(DISTINCT member_id) FROM children")->fetchColumn();
$activeRecords = $pdo->query("SELECT COUNT(DISTINCT member_id) FROM update_logs WHERE updated_at >= (NOW() - INTERVAL 30 DAY)")->fetchColumn();

$activeSurveys = (int)$pdo->query("SELECT COUNT(*) FROM survey_surveys WHERE status = 'active'")->fetchColumn();
$totalResponses = (int)$pdo->query("SELECT COUNT(*) FROM survey_responses")->fetchColumn();
$responders = (int)$pdo->query("SELECT COUNT(DISTINCT member_id) FROM survey_responses")->fetchColumn();
$responseRate = $totalMembers > 0 ? round(($responders / $totalMembers) * 100) : 0;

$civStmt = $pdo->query("SELECT civil_status, COUNT(*) as cnt FROM members WHERE civil_status IS NOT NULL AND civil_status != '' GROUP BY civil_status ORDER BY cnt DESC");
$civData = $civStmt->fetchAll();
$civLabels = []; $civCounts = [];
foreach ($civData as $r) { $civLabels[] = $r['civil_status']; $civCounts[] = (int)$r['cnt']; }
if (empty($civLabels)) { $civLabels = ['N/A']; $civCounts = [0]; }

$monthlyLabels = []; $monthlyData = [];
for ($m = 1; $m <= 12; $m++) {
    $monthlyLabels[] = date('M', mktime(0, 0, 0, $m, 1));
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM members WHERE YEAR(created_at) = YEAR(CURDATE()) AND MONTH(created_at) = ?");
    $stmt->execute([$m]);
    $monthlyData[] = (int)$stmt->fetchColumn();
}

$recentStmt = $pdo->query(
    "SELECT ul.*, m.account_number, m.first_name, m.last_name
     FROM update_logs ul
     JOIN members m ON m.member_id = ul.member_id
     ORDER BY ul.updated_at DESC LIMIT 8"
);
$recentLogs = $recentStmt->fetchAll();

$pageTitle = 'Staff Dashboard';
$userLabel = $_SESSION['staff_name'];
$userRole = 'Staff';
$logoutUrl = 'logout.php';
$assetsPath = '../';
$breadcrumbs = [['label' => 'Dashboard']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content">

    <!-- Quick Actions -->
    <div class="quick-actions-card">
      <div class="qa-header"><h3>Quick Actions</h3></div>
      <div class="quick-actions-grid">
        <a href="add_member.php" class="qa-item" data-color="primary">
          <div class="qa-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>
          </div>
          <div class="qa-title">Add New Resident</div>
          <div class="qa-desc">Register a new resident record</div>
        </a>
        <a href="view_members.php" class="qa-item" data-color="success">
          <div class="qa-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
          </div>
          <div class="qa-title">View Residents</div>
          <div class="qa-desc">Browse and search all residents</div>
        </a>
        <a href="search_member.php" class="qa-item" data-color="info">
          <div class="qa-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          </div>
          <div class="qa-title">Search Member</div>
          <div class="qa-desc">Find by name, number, or email</div>
        </a>
        <a href="reports.php" class="qa-item" data-color="warning">
          <div class="qa-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
          </div>
          <div class="qa-title">Generate Reports</div>
          <div class="qa-desc">Export resident data and logs</div>
        </a>
        <a href="surveys.php" class="qa-item" data-color="info">
          <div class="qa-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
          </div>
          <div class="qa-title">Manage Surveys</div>
          <div class="qa-desc">Create and monitor health surveys</div>
        </a>
        <a href="updated_records.php" class="qa-item" data-color="accent">
          <div class="qa-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
          </div>
          <div class="qa-title">Updated Records</div>
          <div class="qa-desc">Review recent profile changes</div>
        </a>
      </div>
    </div>

    <!-- Stats -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-top">
          <div class="stat-label">Total Residents</div>
          <div class="stat-icon primary">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
          </div>
        </div>
        <div class="stat-bottom">
          <div class="stat-value"><span data-count="<?= (int)$totalMembers ?>">0</span></div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-top">
          <div class="stat-label">Active Records</div>
          <div class="stat-icon success">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
          </div>
        </div>
        <div class="stat-bottom">
          <div class="stat-value"><span data-count="<?= (int)$activeRecords ?>">0</span></div>
          <span class="stat-badge up">30 days</span>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-top">
          <div class="stat-label">Updates (7 days)</div>
          <div class="stat-icon warning">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
          </div>
        </div>
        <div class="stat-bottom">
          <div class="stat-value"><span data-count="<?= (int)$pendingUpdates ?>">0</span></div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-top">
          <div class="stat-label">Married Residents</div>
          <div class="stat-icon danger">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
          </div>
        </div>
        <div class="stat-bottom">
          <div class="stat-value"><span data-count="<?= (int)$marriedMembers ?>">0</span></div>
        </div>
      </div>
      <div class="stat-card" style="cursor:pointer;" onclick="window.location='surveys.php'">
        <div class="stat-top">
          <div class="stat-label">Active Surveys</div>
          <div class="stat-icon primary">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
          </div>
        </div>
        <div class="stat-bottom">
          <div class="stat-value"><span data-count="<?= (int)$activeSurveys ?>">0</span></div>
          <span class="stat-badge up">open now</span>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-top">
          <div class="stat-label">Survey Responses</div>
          <div class="stat-icon success">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 20V10"/><path d="M12 20V4"/><path d="M6 20v-6"/></svg>
          </div>
        </div>
        <div class="stat-bottom">
          <div class="stat-value"><span data-count="<?= (int)$totalResponses ?>">0</span></div>
          <span class="stat-badge up"><?= $responseRate ?>% of residents</span>
        </div>
      </div>
    </div>

    <!-- Charts -->
    <div class="charts-grid">
      <div class="chart-card">
        <div class="chart-title">Monthly Registration (<?= date('Y') ?>)</div>
        <canvas id="monthlyChart" height="220"></canvas>
      </div>
      <div class="chart-card">
        <div class="chart-title">Civil Status Distribution</div>
        <canvas id="donutChart" height="220"></canvas>
      </div>
    </div>

    <!-- Recent Activities -->
    <div class="card">
      <div class="card-header">
        <h3>Recent Activities</h3>
        <a href="updated_records.php" class="btn btn-sm btn-secondary">View All</a>
      </div>
      <?php if (count($recentLogs) === 0): ?>
      <div class="empty-state with-icon" style="padding:32px 24px;">
        <div class="empty-state-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
        </div>
        <div class="empty-state-title">No recent activity</div>
        <div class="empty-state-desc">Updates to resident records will appear here.</div>
      </div>
      <?php else: ?>
      <div class="timeline" style="padding-left:28px;">
        <?php foreach ($recentLogs as $log): ?>
          <div class="timeline-item">
            <div class="timeline-dot success"></div>
            <div class="timeline-content">
              <div class="timeline-title"><?= e($log['first_name'] . ' ' . $log['last_name']) ?></div>
              <div class="timeline-desc"><?= e($log['section']) ?></div>
              <div class="timeline-time"><?= e(date('M d, Y h:i A', strtotime($log['updated_at']))) ?> by <?= e($log['updated_by_name']) ?></div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>

  </div>
</div>
<script src="../assets/js/chart.umd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
  var isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  var blue500 = isDark ? '#4A76B8' : '#2E5A9C';
  var blue300 = isDark ? '#5F8AC9' : '#8FADD9';
  var blue100 = isDark ? '#274064' : '#D8E4F5';
  var gridColor = isDark ? 'rgba(232,228,247,0.06)' : '#EFE8FA';
  var tickColor = isDark ? 'rgba(232,228,247,0.4)' : 'rgba(33,26,56,0.4)';

  new Chart(document.getElementById('monthlyChart'), {
    type: 'bar',
    data: {
      labels: <?= json_encode($monthlyLabels) ?>,
      datasets: [{
        label: 'New Residents',
        data: <?= json_encode($monthlyData) ?>,
        backgroundColor: blue500,
        borderRadius: 6,
        barPercentage: 0.6
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, ticks: { stepSize: 1, font: { size: 11, color: tickColor } }, grid: { color: gridColor } },
        x: { ticks: { font: { size: 11, color: tickColor } }, grid: { display: false } }
      }
    }
  });

  new Chart(document.getElementById('donutChart'), {
    type: 'doughnut',
    data: {
      labels: <?= json_encode($civLabels) ?>,
      datasets: [{
        data: <?= json_encode($civCounts) ?>,
        backgroundColor: [blue500, blue300, blue100, isDark ? '#0F1F3C' : '#F5F8FC'],
        borderWidth: 0
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { position: 'bottom', labels: { boxWidth: 10, padding: 14, font: { size: 11, color: tickColor } } }
      },
      cutout: '68%'
    }
  });
});
</script>
<?php require_once '../includes/footer.php'; ?>
