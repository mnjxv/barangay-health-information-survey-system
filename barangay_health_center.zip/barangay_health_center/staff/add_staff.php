<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireStaffLogin();

$errors = [];
$input = ['username' => '', 'full_name' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrfToken();
    $input['username']  = trim($_POST['username'] ?? '');
    $input['full_name'] = trim($_POST['full_name'] ?? '');
    $input['email']     = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if ($input['username'] === '') $errors[] = 'Username is required.';
    elseif (!preg_match('/^[a-zA-Z0-9_.-]{3,50}$/', $input['username'])) $errors[] = 'Username must be 3-50 characters (letters, numbers, dot, dash, underscore only).';
    if ($input['full_name'] === '') $errors[] = 'Full name is required.';
    if ($input['email'] !== '' && !filter_var($input['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Please enter a valid email address.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    elseif ($password !== $confirm) $errors[] = 'Password and confirmation do not match.';

    if (!$errors) {
        $stmt = $pdo->prepare("SELECT staff_id FROM staff WHERE username = ?");
        $stmt->execute([$input['username']]);
        if ($stmt->fetch()) {
            $errors[] = 'That username is already taken.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $pdo->prepare("INSERT INTO staff (username, password, full_name, email, is_active) VALUES (?, ?, ?, ?, 1)")
                ->execute([$input['username'], $hash, $input['full_name'], $input['email'] !== '' ? $input['email'] : null]);
            addNotification($pdo, 'info', 'Staff Account Created', "A new staff account '{$input['username']}' was created.", null, $_SESSION['staff_id']);
            setFlash('success', 'Staff account created successfully.');
            redirect('user_management.php?tab=staff');
        }
    }
}

$pageTitle = 'Add Staff Account';
$userLabel = $_SESSION['staff_name'];
$userRole = 'Staff';
$logoutUrl = 'logout.php';
$assetsPath = '../';
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'User Management','url'=>'user_management.php'], ['label'=>'Add Staff']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content">
    <div class="card" style="max-width:560px;">
      <div class="card-header"><h2>Add Staff Account</h2></div>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <ul style="margin:0 0 0 18px;"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
        </div>
      <?php endif; ?>

      <form method="POST" data-validate novalidate>
        <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
        <div class="form-group">
          <label>Username <span class="required">*</span></label>
          <input type="text" name="username" data-required value="<?= e($input['username']) ?>" placeholder="e.g. nurse.maria">
        </div>
        <div class="form-group">
          <label>Full Name <span class="required">*</span></label>
          <input type="text" name="full_name" data-required value="<?= e($input['full_name']) ?>" placeholder="e.g. Maria Santos">
        </div>
        <div class="form-group">
          <label>Email Address</label>
          <input type="email" name="email" value="<?= e($input['email']) ?>" placeholder="optional">
        </div>
        <div class="form-group">
          <label>Password <span class="required">*</span></label>
          <input type="password" name="password" data-required placeholder="At least 6 characters">
        </div>
        <div class="form-group">
          <label>Confirm Password <span class="required">*</span></label>
          <input type="password" name="confirm_password" data-required placeholder="Re-enter password">
        </div>
        <div style="display:flex;gap:10px;margin-top:8px;">
          <a href="user_management.php?tab=staff" class="btn btn-secondary">Cancel</a>
          <button type="submit" class="btn btn-primary">Create Account</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>