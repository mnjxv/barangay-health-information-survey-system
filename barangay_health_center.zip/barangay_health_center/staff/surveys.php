<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
require_once '../includes/survey_functions.php';
requireStaffLogin();
autoCloseExpiredSurveys($pdo);

$surveys = $pdo->query(
    "SELECT s.*, st.full_name AS creator,
            (SELECT COUNT(*) FROM survey_questions q WHERE q.survey_id = s.survey_id) AS question_count,
            (SELECT COUNT(*) FROM survey_responses r WHERE r.survey_id = s.survey_id) AS response_count
     FROM survey_surveys s
     LEFT JOIN staff st ON st.staff_id = s.created_by
     ORDER BY s.created_at DESC"
)->fetchAll();

$pageTitle = 'Health Surveys';
$userLabel = $_SESSION['staff_name'];
$userRole = 'Staff';
$logoutUrl = 'logout.php';
$assetsPath = '../';
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Surveys']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content">
    <div class="card">
      <div class="card-header">
        <h2>Survey Management (<?= count($surveys) ?>)</h2>
        <a href="survey_builder.php" class="btn-primary-action">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Create Survey
        </a>
      </div>

      <?php if (count($surveys) === 0): ?>
        <div class="empty-state with-icon">
          <div class="empty-state-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
          </div>
          <div class="empty-state-title">No surveys yet</div>
          <div class="empty-state-desc">Create your first health center survey to start gathering responses.</div>
        </div>
      <?php else: ?>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Survey</th>
              <th>Status</th>
              <th>Schedule</th>
              <th>Questions</th>
              <th>Responses</th>
              <th>Created</th>
              <th style="width:auto;">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($surveys as $s):
                $live = surveyIsLive($s);
                if ($s['status'] === 'active') $badge = $live ? ['badge-active','Active'] : ['badge-pending','Scheduled'];
                elseif ($s['status'] === 'closed') $badge = ['badge-inactive','Closed'];
                else $badge = ['badge-pending','Draft'];
            ?>
              <tr>
                <td>
                  <div style="font-weight:600;"><?= e($s['title']) ?></div>
                  <?php if (!empty($s['description'])): ?>
                    <div style="font-size:0.78rem;color:var(--text-muted);max-width:320px;"><?= e(mb_strimwidth($s['description'], 0, 80, '…')) ?></div>
                  <?php endif; ?>
                  <?php if ($s['creator']): ?><div style="font-size:0.74rem;color:var(--text-dim);">by <?= e($s['creator']) ?></div><?php endif; ?>
                </td>
                <td><span class="badge <?= $badge[0] ?>"><?= $badge[1] ?></span></td>
                <td style="font-size:0.8rem;white-space:nowrap;">
                  <?= $s['starts_at'] ? date('M d, Y', strtotime($s['starts_at'])) : '—' ?><br>
                  <?= $s['ends_at'] ? date('M d, Y', strtotime($s['ends_at'])) : '—' ?>
                </td>
                <td><?= (int)$s['question_count'] ?></td>
                <td><strong><?= (int)$s['response_count'] ?></strong></td>
                <td style="font-size:0.8rem;white-space:nowrap;"><?= date('M d, Y', strtotime($s['created_at'])) ?></td>
                <td>
                  <div class="actions-cell">
                    <a href="survey_builder.php?id=<?= (int)$s['survey_id'] ?>" class="action-btn edit" title="Edit Survey">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"/><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"/></svg>
                      <span class="lbl">Edit</span>
                    </a>
                    <a href="survey_results.php?id=<?= (int)$s['survey_id'] ?>" class="action-btn chart" title="Results & Charts">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 20V10"/><path d="M12 20V4"/><path d="M6 20v-6"/></svg>
                      <span class="lbl">Results</span>
                    </a>
                    <a href="survey_respondents.php?id=<?= (int)$s['survey_id'] ?>" class="action-btn lock" title="Respondents">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                      <span class="lbl">Respondents</span>
                    </a>
                    <a href="survey_report.php?id=<?= (int)$s['survey_id'] ?>" class="action-btn print" title="Print Report">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                      <span class="lbl">Print</span>
                    </a>
                    <form method="POST" action="survey_status.php" style="display:inline;margin:0;">
                      <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
                      <input type="hidden" name="id" value="<?= (int)$s['survey_id'] ?>">
                      <button type="submit" class="action-btn <?= $s['status'] === 'active' ? 'danger' : 'chart' ?>" title="<?= $s['status'] === 'active' ? 'Deactivate Survey' : 'Activate Survey' ?>">
                        <?php if ($s['status'] === 'active'): ?>
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 3H2L8 9v6l4 4V9"/><line x1="16" y1="3" x2="16" y2="21"/></svg>
                          <span class="lbl">Close</span>
                        <?php else: ?>
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                          <span class="lbl">Activate</span>
                        <?php endif; ?>
                      </button>
                    </form>
                    <button type="button" class="action-btn danger del-survey" title="Delete Survey" data-id="<?= (int)$s['survey_id'] ?>" data-title="<?= e($s['title']) ?>" data-csrf="<?= generateCsrfToken() ?>">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                      <span class="lbl">Delete</span>
                    </button>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="modal-overlay" id="delModal">
  <div class="modal-card">
    <div class="modal-icon-danger">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:28px;height:28px;"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
    </div>
    <h2 style="margin:0 0 6px;">Delete Survey</h2>
    <p style="color:var(--text-muted);margin:0 0 20px;">Permanently delete <strong id="delTitle"></strong>? All questions, choices, and responses will also be removed. This cannot be undone.</p>
    <div style="display:flex;gap:10px;justify-content:center;">
      <button type="button" class="btn btn-secondary" id="delCancel">Cancel</button>
      <button type="button" class="btn btn-danger" id="delConfirm">Delete</button>
    </div>
  </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
  var modal = document.getElementById('delModal');
  var titleEl = document.getElementById('delTitle');
  var delData = { id: null, csrf: null };
  var handler = null;

  function close() { modal.style.display = 'none'; }
  document.getElementById('delCancel').addEventListener('click', close);
  modal.addEventListener('click', function(e) { if (e.target === modal) close(); });

  document.querySelectorAll('.del-survey').forEach(function(btn) {
    btn.addEventListener('click', function() {
      delData.id = this.getAttribute('data-id');
      delData.csrf = this.getAttribute('data-csrf');
      titleEl.textContent = this.getAttribute('data-title');
      modal.style.display = 'flex';
    });
  });

  var confirmBtn = document.getElementById('delConfirm');
  confirmBtn.addEventListener('click', function() {
    var f = document.createElement('form');
    f.method = 'POST'; f.action = 'survey_delete.php'; f.style.display = 'none';
    var c = document.createElement('input'); c.type = 'hidden'; c.name = '_csrf_token'; c.value = delData.csrf; f.appendChild(c);
    var i = document.createElement('input'); i.type = 'hidden'; i.name = 'id'; i.value = delData.id; f.appendChild(i);
    document.body.appendChild(f); f.submit();
  });
});
</script>
<?php require_once '../includes/footer.php'; ?>
