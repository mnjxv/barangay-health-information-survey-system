<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireStaffLogin();

$staffId = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM staff WHERE staff_id = ?");
$stmt->execute([$staffId]);
$staff = $stmt->fetch();

if (!$staff) {
    setFlash('danger', 'Staff account not found.');
    redirect('user_management.php?tab=staff');
}

$resetDone = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrfToken();
    $tempPassword = 'Resify@' . random_int(100000, 999999);
    $hash = password_hash($tempPassword, PASSWORD_DEFAULT);
    $pdo->prepare("UPDATE staff SET password = ? WHERE staff_id = ?")->execute([$hash, $staffId]);

    addNotification($pdo, 'warning', 'Password Reset', "Your staff account password was reset by an administrator.", null, $staffId);
    setFlash('success', 'Password has been reset.');
    $resetDone = ['username' => $staff['username'], 'name' => $staff['full_name'], 'password' => $tempPassword];
}

$pageTitle = 'Reset Staff Password';
$userLabel = $_SESSION['staff_name'];
$userRole = 'Staff';
$logoutUrl = 'logout.php';
$assetsPath = '../';
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'User Management','url'=>'user_management.php'], ['label'=>'Reset Password']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content">
    <?php if ($resetDone): ?>
    <div style="display:flex;align-items:center;justify-content:center;min-height:50vh;">
      <div class="modal-card" style="max-width:420px;width:100%;text-align:center;">
        <div class="modal-icon" style="background:var(--warning);color:#fff;margin:0 auto 20px;">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:28px;height:28px;"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
        </div>
        <h2 style="margin:0 0 6px;">Password Reset</h2>
        <p style="color:var(--text-muted);margin:0 0 20px;">Share this temporary password with the staff member. They should change it after logging in.</p>
        <table class="modal-details" style="margin:0 auto;">
          <tr><td>Username</td><td><strong><?= e($resetDone['username']) ?></strong></td></tr>
          <tr><td>Full Name</td><td><strong><?= e($resetDone['name']) ?></strong></td></tr>
          <tr><td>Temporary Password</td><td><strong style="font-size:1.05rem;letter-spacing:0.5px;"><?= e($resetDone['password']) ?></strong></td></tr>
        </table>
        <div style="margin-top:24px;">
          <a href="user_management.php?tab=staff" class="btn btn-primary btn-block">Back to Staff Accounts</a>
        </div>
      </div>
    </div>
    <?php else: ?>
    <div style="display:flex;align-items:center;justify-content:center;min-height:50vh;">
      <div class="card" style="max-width:500px;width:100%;">
        <div class="card-header"><h2>Reset Staff Password</h2></div>
        <p>Reset the password for <strong><?= e($staff['full_name']) ?></strong> (username: <?= e($staff['username']) ?>)?</p>
        <p class="text-muted">A temporary password will be generated and shown once. The staff member can change it from their own settings if available.</p>
        <form method="POST" style="display:flex;gap:10px;">
          <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
          <a href="user_management.php?tab=staff" class="btn btn-secondary">Cancel</a>
          <button type="submit" class="btn btn-danger">Confirm Reset</button>
        </form>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>