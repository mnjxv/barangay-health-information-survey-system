<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireStaffLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    setFlash('danger', 'Invalid request method.');
    redirect('view_members.php');
}
requireCsrfToken();

$memberIds = [];
if (isset($_POST['selected_ids']) && is_array($_POST['selected_ids'])) {
    $memberIds = array_map('intval', $_POST['selected_ids']);
} elseif (isset($_POST['id'])) {
    $memberIds = [(int)$_POST['id']];
}

if (empty($memberIds)) {
    setFlash('danger', 'No residents selected for deletion.');
    redirect('view_members.php');
}

$deleted = [];
foreach ($memberIds as $memberId) {
    $stmt = $pdo->prepare("SELECT account_number, first_name, last_name FROM members WHERE member_id = ?");
    $stmt->execute([$memberId]);
    $member = $stmt->fetch();
    if ($member) {
        $pdo->prepare("UPDATE update_logs SET member_id = NULL WHERE member_id = ?")->execute([$memberId]);
        $pdo->prepare("DELETE FROM notifications WHERE member_id = ?")->execute([$memberId]);
        $pdo->prepare("DELETE FROM children WHERE member_id = ?")->execute([$memberId]);
        $pdo->prepare("DELETE FROM spouse_info WHERE member_id = ?")->execute([$memberId]);
        $pdo->prepare("DELETE FROM members WHERE member_id = ?")->execute([$memberId]);
        $deleted[] = $member;
    }
}

$pageTitle = 'Member Deleted';
$userLabel = $_SESSION['staff_name'];
$userRole = 'Staff';
$logoutUrl = 'logout.php';
$assetsPath = '../';
$hideTopbar = false;
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Residents','url'=>'view_members.php'], ['label'=>'Delete']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content" style="display:flex;align-items:center;justify-content:center;min-height:60vh;">
    <?php if (count($deleted) > 0): ?>
    <div class="modal-card" style="max-width:480px;width:100%;text-align:center;">
      <div class="modal-icon" style="background:var(--danger);color:#fff;margin:0 auto 20px;">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:28px;height:28px;"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
      </div>
      <h2 style="margin:0 0 6px;"><?= count($deleted) > 1 ? 'Members Deleted' : 'Member Deleted' ?></h2>
      <p style="color:var(--text-muted);margin:0 0 20px;"><?= count($deleted) ?> resident record(s) have been permanently deleted.</p>
      <?php if (count($deleted) === 1): ?>
      <table class="modal-details" style="margin:0 auto;">
        <tr><td>Resident No.</td><td><strong><?= e($deleted[0]['account_number']) ?></strong></td></tr>
        <tr><td>Full Name</td><td><strong><?= e($deleted[0]['first_name'] . ' ' . $deleted[0]['last_name']) ?></strong></td></tr>
      </table>
      <?php else: ?>
      <div class="table-wrap" style="max-height:200px;overflow-y:auto;margin-bottom:16px;">
      <table>
        <thead><tr><th>Name</th><th>Account #</th></tr></thead>
        <tbody>
          <?php foreach ($deleted as $d): ?>
          <tr><td><?= e($d['first_name'] . ' ' . $d['last_name']) ?></td><td><?= e($d['account_number']) ?></td></tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      </div>
      <?php endif; ?>
      <div style="margin-top:24px;">
        <a href="view_members.php" class="btn btn-primary btn-block">Continue to Residents List</a>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
