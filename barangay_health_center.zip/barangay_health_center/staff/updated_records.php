<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireStaffLogin();

$perPage = 20;
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;

$total = $pdo->query("SELECT COUNT(*) FROM update_logs")->fetchColumn();
$totalPages = max(1, ceil($total / $perPage));

$stmt = $pdo->prepare(
    "SELECT ul.*, m.account_number, m.first_name, m.last_name
     FROM update_logs ul
     LEFT JOIN members m ON m.member_id = ul.member_id
     ORDER BY ul.updated_at DESC
     LIMIT :limit OFFSET :offset"
);
$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$logs = $stmt->fetchAll();

$pageTitle = 'Profile Update Requests';
$userLabel = $_SESSION['staff_name'];
$userRole = 'Staff';
$logoutUrl = 'logout.php';
$assetsPath = '../';
$hideTopbar = false;
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Updated Records']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content">
    <div class="card">
      <div class="card-header"><h2>Update Requests (<?= (int)$total ?>)</h2></div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Date/Time</th><th>Resident #</th><th>Resident</th><th>Section</th><th>Updated By</th><th>Remarks</th></tr>
          </thead>
          <tbody>
            <?php if (count($logs) === 0): ?>
              <tr><td colspan="6" class="text-center text-muted">No update history yet.</td></tr>
            <?php endif; ?>
            <?php foreach ($logs as $log): ?>
              <tr>
                <td><?= e(date('M d, Y h:i A', strtotime($log['updated_at']))) ?></td>
                <td><strong><?= e($log['account_number']) ?></strong></td>
                <td><?= e($log['first_name'] . ' ' . $log['last_name']) ?></td>
                <td><span class="badge badge-active"><?= e($log['section']) ?></span></td>
                <td><?= e($log['updated_by_name']) ?></td>
                <td class="text-muted"><?= e($log['remarks']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <?php if ($totalPages > 1): ?>
        <div style="display:flex;gap:6px;justify-content:center;margin-top:20px;">
          <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <a href="?page=<?= $p ?>" class="btn btn-sm <?= $p === $page ? 'btn-primary' : 'btn-secondary' ?>"><?= $p ?></a>
          <?php endfor; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>