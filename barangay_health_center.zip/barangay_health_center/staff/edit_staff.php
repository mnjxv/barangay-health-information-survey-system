<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireStaffLogin();

$staffId = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM staff WHERE staff_id = ?");
$stmt->execute([$staffId]);
$staff = $stmt->fetch();

if (!$staff) {
    setFlash('danger', 'Staff account not found.');
    redirect('user_management.php?tab=staff');
}

$errors = [];
$input = ['username' => $staff['username'], 'full_name' => $staff['full_name'], 'email' => $staff['email'] ?? ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrfToken();
    $input['username']  = trim($_POST['username'] ?? '');
    $input['full_name'] = trim($_POST['full_name'] ?? '');
    $input['email']     = trim($_POST['email'] ?? '');

    if ($input['username'] === '') $errors[] = 'Username is required.';
    elseif (!preg_match('/^[a-zA-Z0-9_.-]{3,50}$/', $input['username'])) $errors[] = 'Username must be 3-50 characters (letters, numbers, dot, dash, underscore only).';
    if ($input['full_name'] === '') $errors[] = 'Full name is required.';
    if ($input['email'] !== '' && !filter_var($input['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Please enter a valid email address.';

    if (!$errors) {
        $stmt = $pdo->prepare("SELECT staff_id FROM staff WHERE username = ? AND staff_id != ?");
        $stmt->execute([$input['username'], $staffId]);
        if ($stmt->fetch()) {
            $errors[] = 'That username is already taken by another staff member.';
        } else {
            $pdo->prepare("UPDATE staff SET username = ?, full_name = ?, email = ? WHERE staff_id = ?")
                ->execute([$input['username'], $input['full_name'], $input['email'] !== '' ? $input['email'] : null, $staffId]);
            if ($staffId === (int)$_SESSION['staff_id']) {
                $_SESSION['staff_name'] = $input['full_name'];
            }
            setFlash('success', 'Staff account updated successfully.');
            redirect('user_management.php?tab=staff');
        }
    }
}

$pageTitle = 'Edit Staff Account';
$userLabel = $_SESSION['staff_name'];
$userRole = 'Staff';
$logoutUrl = 'logout.php';
$assetsPath = '../';
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'User Management','url'=>'user_management.php'], ['label'=>'Edit Staff']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content">
    <div class="card" style="max-width:560px;">
      <div class="card-header"><h2>Edit Staff Account</h2></div>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <ul style="margin:0 0 0 18px;"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
        </div>
      <?php endif; ?>

      <form method="POST" data-validate novalidate>
        <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
        <div class="form-group">
          <label>Username <span class="required">*</span></label>
          <input type="text" name="username" data-required value="<?= e($input['username']) ?>">
        </div>
        <div class="form-group">
          <label>Full Name <span class="required">*</span></label>
          <input type="text" name="full_name" data-required value="<?= e($input['full_name']) ?>">
        </div>
        <div class="form-group">
          <label>Email Address</label>
          <input type="email" name="email" value="<?= e($input['email']) ?>" placeholder="optional">
        </div>
        <p class="text-muted" style="font-size:0.8rem;margin:0 0 16px;">To change the password, use "Reset PW" on the staff list.</p>
        <div style="display:flex;gap:10px;">
          <a href="user_management.php?tab=staff" class="btn btn-secondary">Cancel</a>
          <button type="submit" class="btn btn-primary">Save Changes</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>