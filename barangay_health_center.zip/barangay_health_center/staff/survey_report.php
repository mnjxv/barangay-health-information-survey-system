<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
require_once '../includes/survey_functions.php';
requireStaffLogin();

$surveyId = (int)($_GET['id'] ?? 0);
$survey = getSurvey($pdo, $surveyId);
if (!$survey) redirect('surveys.php');

$questions = getSurveyQuestions($pdo, $surveyId);
$results = getSurveyResults($pdo, $surveyId);
$shortAnswers = getSurveyShortAnswers($pdo, $surveyId);
$responseCount = surveyResponseCount($pdo, $surveyId);

$rows = [];
foreach ($questions as $q) {
    $qid = (int)$q['question_id'];
    $item = ['question' => $q, 'rows' => [], 'short_answers' => $shortAnswers[$qid] ?? []];
    if (in_array($q['question_type'], ['multiple_choice', 'yes_no'])) {
        foreach ($q['choices'] as $c) {
            $count = $results[$qid][(int)$c['choice_id']] ?? 0;
            $item['rows'][] = ['label' => $c['choice_text'], 'count' => $count];
        }
    } elseif ($q['question_type'] === 'rating') {
        for ($r = 1; $r <= 5; $r++) {
            $count = $results[$qid]['rating'][$r] ?? 0;
            $item['rows'][] = ['label' => $r . ' / 5', 'count' => $count];
        }
    }
    $rows[] = $item;
}

$pageTitle = 'Survey Report';
$userLabel = $_SESSION['staff_name'];
$userRole = 'Staff';
$logoutUrl = 'logout.php';
$assetsPath = '../';
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Surveys','url'=>'surveys.php'], ['label'=>'Report']];
require_once '../includes/header.php';
?>
<style>
@media print {
  .no-print { display: none !important; }
  body { background: #fff; }
  .app-shell { padding-left: 0 !important; }
  .sidebar, .topbar, .breadcrumbs { display: none !important; }
  .report-print-wrap { max-width: 100%; }
}
.report-print-wrap .report-title { font-size: 1.3rem; font-weight: 700; margin: 0 0 2px; }
.report-print-wrap table { margin-bottom: 24px; }
.report-q { margin-bottom: 26px; page-break-inside: avoid; }
.report-q h4 { margin: 0 0 10px; font-size: 0.92rem; }
.report-bar { height: 10px; background: var(--border-light); border-radius: 5px; overflow: hidden; margin-top: 6px; }
.report-bar > div { height: 100%; background: var(--primary); border-radius: 5px; }
</style>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content report-print-wrap">

    <div class="no-print" style="display:flex;justify-content:flex-end;gap:8px;margin-bottom:16px;">
      <a href="survey_export.php?id=<?= (int)$surveyId ?>" class="btn btn-sm btn-primary">Export CSV</a>
      <button onclick="window.print()" class="btn btn-sm btn-secondary">Print</button>
      <a href="survey_results.php?id=<?= (int)$surveyId ?>" class="btn btn-sm btn-secondary">Back to Results</a>
    </div>

    <div style="text-align:center;margin-bottom:24px;border-bottom:2px solid var(--text);padding-bottom:16px;">
      <div style="font-size:0.8rem;color:var(--text-muted);">Republic of the Philippines<br>Barangay Health Center</div>
      <div class="report-title"><?= e($survey['title']) ?></div>
      <div style="font-size:0.82rem;color:var(--text-muted);margin-top:6px;">
        Survey Report · Generated <?= date('F d, Y h:i A') ?> ·
        <?= (int)$responseCount ?> response(s) ·
        Period: <?= $survey['starts_at'] ? date('M d, Y', strtotime($survey['starts_at'])) : '—' ?> to <?= $survey['ends_at'] ? date('M d, Y', strtotime($survey['ends_at'])) : '—' ?>
      </div>
    </div>

    <?php if (!empty($survey['description'])): ?>
      <p style="font-size:0.85rem;margin:0 0 20px;"><?= e($survey['description']) ?></p>
    <?php endif; ?>

    <?php if ($responseCount === 0): ?>
      <p class="text-muted">No responses have been recorded for this survey yet.</p>
    <?php else: foreach ($rows as $i => $item): $q = $item['question']; ?>
      <div class="report-q">
        <h4>Q<?= $i + 1 ?>. <?= e($q['question_text']) ?>
          <span style="font-weight:400;font-size:0.75rem;color:var(--text-muted);">(<?= ucwords(str_replace('_', ' ', $q['question_type'])) ?>)</span>
        </h4>

        <?php if ($q['question_type'] === 'short_answer'): ?>
          <?php if (count($item['short_answers']) === 0): ?>
            <p style="font-size:0.82rem;color:var(--text-muted);">No written answers.</p>
          <?php else: ?>
            <table>
              <thead><tr><th style="width:30%;">Resident</th><th>Answer</th></tr></thead>
              <tbody>
                <?php foreach ($item['short_answers'] as $sa): ?>
                  <tr>
                    <td><?= e($sa['first_name'] . ' ' . $sa['last_name']) ?><br><span style="color:var(--text-muted);font-size:0.75rem;"><?= e($sa['account_number']) ?></span></td>
                    <td><?= e($sa['answer_text']) ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          <?php endif; ?>
        <?php else: ?>
          <table>
            <thead><tr><th>Option</th><th style="width:90px;text-align:center;">Count</th><th style="width:90px;text-align:center;">%</th></tr></thead>
            <tbody>
              <?php foreach ($item['rows'] as $row): $pct = $responseCount > 0 ? round(($row['count'] / $responseCount) * 100) : 0; ?>
                <tr>
                  <td>
                    <?= e($row['label']) ?>
                    <div class="report-bar"><div style="width:<?= $pct ?>%"></div></div>
                  </td>
                  <td style="text-align:center;"><strong><?= (int)$row['count'] ?></strong></td>
                  <td style="text-align:center;"><?= $pct ?>%</td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    <?php endforeach; endif; ?>

    <div style="margin-top:40px;display:flex;justify-content:space-between;gap:40px;font-size:0.82rem;">
      <div style="text-align:center;border-top:1px solid var(--text);padding-top:6px;flex:1;">Prepared by</div>
      <div style="text-align:center;border-top:1px solid var(--text);padding-top:6px;flex:1;">Noted by</div>
    </div>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>