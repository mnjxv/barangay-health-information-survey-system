<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireStaffLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('user_management.php?tab=staff');
}
requireCsrfToken();

$id = (int)($_POST['id'] ?? 0);
if ($id === (int)$_SESSION['staff_id']) {
    setFlash('danger', 'You cannot deactivate your own account.');
    redirect('user_management.php?tab=staff');
}

$stmt = $pdo->prepare("SELECT is_active, full_name FROM staff WHERE staff_id = ?");
$stmt->execute([$id]);
$row = $stmt->fetch();
if (!$row) {
    setFlash('danger', 'Staff account not found.');
    redirect('user_management.php?tab=staff');
}

$newState = (int)$row['is_active'] === 1 ? 0 : 1;
$pdo->prepare("UPDATE staff SET is_active = ? WHERE staff_id = ?")->execute([$newState, $id]);

setFlash('success', $newState === 1
    ? "Staff account '{$row['full_name']}' has been activated."
    : "Staff account '{$row['full_name']}' has been deactivated.");
redirect('user_management.php?tab=staff');
