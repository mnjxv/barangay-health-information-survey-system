<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireStaffLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('user_management.php?tab=residents');
}
requireCsrfToken();

$id = (int)($_POST['id'] ?? 0);
$stmt = $pdo->prepare("SELECT is_active, first_name, last_name FROM members WHERE member_id = ?");
$stmt->execute([$id]);
$row = $stmt->fetch();
if (!$row) {
    setFlash('danger', 'Resident account not found.');
    redirect('user_management.php?tab=residents');
}

$newState = (int)$row['is_active'] === 1 ? 0 : 1;
$pdo->prepare("UPDATE members SET is_active = ? WHERE member_id = ?")->execute([$newState, $id]);

$name = $row['first_name'] . ' ' . $row['last_name'];
setFlash('success', $newState === 1
    ? "Resident account '{$name}' has been activated."
    : "Resident account '{$name}' has been deactivated.");
redirect('user_management.php?tab=residents');