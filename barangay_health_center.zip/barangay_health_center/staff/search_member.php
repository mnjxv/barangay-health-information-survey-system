<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireStaffLogin();

$query = trim($_GET['q'] ?? '');
$results = [];

if ($query !== '') {
    $stmt = $pdo->prepare(
        "SELECT * FROM members
         WHERE account_number LIKE ? OR last_name LIKE ? OR first_name LIKE ? OR middle_name LIKE ? OR contact_number LIKE ? OR address LIKE ? OR purok LIKE ? OR email LIKE ? OR occupation LIKE ?
         ORDER BY last_name, first_name LIMIT 50"
    );
    $like = "%$query%";
    $stmt->execute([$like, $like, $like, $like, $like, $like, $like, $like, $like]);
    $results = $stmt->fetchAll();
}

$pageTitle = 'Search Resident';
$userLabel = $_SESSION['staff_name'];
$userRole = 'Staff';
$logoutUrl = 'logout.php';
$assetsPath = '../';
$hideTopbar = false;
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Search']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content">
    <div class="card">
      <div class="card-header">
        <h2>Search Resident</h2>
        <a href="add_member.php" class="btn-primary-action">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Add Resident
        </a>
      </div>
      <form method="GET" style="display:flex;gap:10px;margin-bottom:16px;">
        <input type="text" name="q" placeholder="Search by resident #, name, address, contact #, or any details" value="<?= e($query) ?>" style="flex:1;">
        <button type="submit" class="btn btn-primary">Search</button>
        <?php if ($query !== ''): ?>
          <a href="view_members.php" class="btn btn-secondary">Clear</a>
        <?php endif; ?>
      </form>

      <?php if ($query !== ''): ?>
        <div class="table-wrap">
          <table>
            <thead>
              <tr><th>Photo</th><th>Resident #</th><th>Name</th><th>Gender</th><th>Purok</th><th>Contact</th><th>Actions</th></tr>
            </thead>
            <tbody>
              <?php if (count($results) === 0): ?>
                <tr><td colspan="7" class="text-center text-muted">No matching records for "<?= e($query) ?>".</td></tr>
              <?php endif; ?>
              <?php foreach ($results as $m): ?>
                <tr>
                  <td>
                    <?php if (!empty($m['photo_path'])): ?>
                      <img src="../<?= e($m['photo_path']) ?>" class="table-photo">
                    <?php else: ?>
                      <div class="table-photo-placeholder"><?= e(strtoupper(substr($m['first_name'], 0, 1) . substr($m['last_name'], 0, 1))) ?></div>
                    <?php endif; ?>
                  </td>
                  <td><strong><?= e($m['account_number']) ?></strong></td>
                  <td><?= e($m['last_name'] . ', ' . $m['first_name']) ?></td>
                  <td><?= e(na($m['gender'])) ?></td>
                  <td><?= e(na($m['purok'])) ?></td>
                  <td><?= e(na($m['contact_number'])) ?></td>
                  <td>
                    <div class="actions-cell">
                      <a href="edit_member.php?id=<?= (int)$m['member_id'] ?>" class="action-btn edit" title="Edit">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"/><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"/></svg>
                      </a>
                      <a href="reset_password.php?id=<?= (int)$m['member_id'] ?>" class="action-btn lock" title="Reset Password">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                      </a>
                      <a href="print_member.php?id=<?= (int)$m['member_id'] ?>" class="action-btn print" title="Print">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                      </a>
                      <form method="POST" action="delete_member.php" class="delete-form" style="display:inline;">
                        <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
                        <input type="hidden" name="id" value="<?= (int)$m['member_id'] ?>">
                        <button type="button" class="action-btn danger delete-btn" title="Delete" data-name="<?= e($m['first_name'] . ' ' . $m['last_name']) ?>">
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                        </button>
                      </form>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <p class="text-muted">Enter a search term above to find a resident.</p>
      <?php endif; ?>
    </div>
  </div>
</div>
<div class="modal-overlay" id="confirmModal">
  <div class="modal-card">
    <div class="modal-icon-danger">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:28px;height:28px;"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
    </div>
    <h2 style="margin:0 0 6px;">Delete Resident</h2>
    <p style="color:var(--text-muted);margin:0 0 20px;">Are you sure you want to permanently delete <strong id="confirmName"></strong>? This action cannot be undone.</p>
    <div style="display:flex;gap:10px;justify-content:center;">
      <button type="button" class="btn btn-secondary" id="confirmCancel">Cancel</button>
      <a href="#" class="btn btn-danger" id="confirmDelete">Delete</a>
    </div>
  </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
  var modal = document.getElementById('confirmModal');
  var nameEl = document.getElementById('confirmName');
  var deleteLink = document.getElementById('confirmDelete');
  var cancelBtn = document.getElementById('confirmCancel');

  document.querySelectorAll('.delete-btn').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      var form = this.closest('.delete-form');
      nameEl.textContent = this.getAttribute('data-name');
      deleteLink.addEventListener('click', function onSubmit() {
        deleteLink.removeEventListener('click', onSubmit);
        form.submit();
      });
      modal.style.display = 'flex';
    });
  });

  function closeModal() { modal.style.display = 'none'; }
  cancelBtn.addEventListener('click', closeModal);
  modal.addEventListener('click', function(e) { if (e.target === modal) closeModal(); });
});
</script>
<?php require_once '../includes/footer.php'; ?>