<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireStaffLogin();

$search = trim($_GET['search'] ?? '');
$filterGender = $_GET['gender'] ?? '';
$filterPurok  = $_GET['purok'] ?? '';
$filterStatus = $_GET['status'] ?? '';
$filterOccupation = $_GET['occupation'] ?? '';
$minAge = $_GET['min_age'] ?? '';
$maxAge = $_GET['max_age'] ?? '';

$where = [];
$bindings = [];
if ($search !== '') {
    $where[] = '(account_number LIKE :search1 OR last_name LIKE :search2 OR first_name LIKE :search3 OR middle_name LIKE :search4 OR contact_number LIKE :search5 OR address LIKE :search6 OR purok LIKE :search7 OR email LIKE :search8 OR occupation LIKE :search9)';
    $like = "%$search%";
    for ($i = 1; $i <= 9; $i++) {
        $bindings[":search$i"] = $like;
    }
}
if ($filterGender !== '') {
    $where[] = 'gender = :gender';
    $bindings[':gender'] = $filterGender;
}
if ($filterPurok !== '') {
    $where[] = 'purok = :purok';
    $bindings[':purok'] = $filterPurok;
}
if ($filterStatus !== '') {
    $where[] = 'civil_status = :status';
    $bindings[':status'] = $filterStatus;
}
if ($filterOccupation !== '') {
    $where[] = 'occupation = :occupation';
    $bindings[':occupation'] = $filterOccupation;
}
if ($minAge !== '') {
    $where[] = 'age >= :min_age';
    $bindings[':min_age'] = (int)$minAge;
}
if ($maxAge !== '') {
    $where[] = 'age <= :max_age';
    $bindings[':max_age'] = (int)$maxAge;
}
$whereClause = count($where) ? 'WHERE ' . implode(' AND ', $where) : '';

$perPage = 10;
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM members $whereClause");
$countStmt->execute($bindings);
$total = $countStmt->fetchColumn();
$totalPages = max(1, ceil($total / $perPage));

$bindings[':limit'] = $perPage;
$bindings[':offset'] = $offset;
$stmt = $pdo->prepare("SELECT * FROM members $whereClause ORDER BY last_name, first_name LIMIT :limit OFFSET :offset");
$stmt->execute($bindings);
$members = $stmt->fetchAll();

$purokList = $pdo->query("SELECT DISTINCT purok FROM members WHERE purok IS NOT NULL AND purok != '' ORDER BY purok")->fetchAll(PDO::FETCH_COLUMN);
$occupationList = $pdo->query("SELECT DISTINCT occupation FROM members WHERE occupation IS NOT NULL AND occupation != '' ORDER BY occupation")->fetchAll(PDO::FETCH_COLUMN);

$pageTitle = 'Resident Records';
$userLabel = $_SESSION['staff_name'];
$userRole = 'Staff';
$logoutUrl = 'logout.php';
$assetsPath = '../';
$breadcrumbs = [['label' => 'Dashboard', 'url' => 'dashboard.php'], ['label' => 'Residents']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content">
    <div class="card">
      <div class="card-header">
        <h2>Resident Records (<?= (int)$total ?>)</h2>
        <div style="display:flex;gap:8px;">
          <form method="GET" style="display:flex;gap:6px;">
            <input type="text" name="search" placeholder="Search name, address, contact #, or any details..." value="<?= e($search) ?>" style="width:280px;padding:8px 14px;font-size:0.85rem;">
            <button type="submit" class="btn-primary-action" style="padding:8px 14px;">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:15px;height:15px;"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              Search
            </button>
            <?php if ($search !== ''): ?>
              <a href="view_members.php" style="padding:8px 14px;font-size:0.85rem;border-radius:6px;background:var(--bg-secondary);border:1px solid var(--border);color:var(--text-muted);text-decoration:none;display:inline-flex;align-items:center;">Clear</a>
            <?php endif; ?>
          </form>
          <a href="add_member.php" class="btn-primary-action">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Add Resident
          </a>
        </div>
      </div>

      <form method="GET" style="display:flex;gap:10px;align-items:flex-end;margin-bottom:20px;padding:14px 16px;background:var(--bg-secondary);border-radius:var(--radius-sm);border:1px solid var(--border);">
        <?php if ($search !== ''): ?>
          <input type="hidden" name="search" value="<?= e($search) ?>">
        <?php endif; ?>
        <div style="display:flex;flex-direction:column;gap:4px;">
          <label style="font-size:0.75rem;font-weight:500;color:var(--text-muted);">Gender</label>
          <select name="gender" onchange="this.form.submit()" style="padding:6px 10px;font-size:0.82rem;border:1px solid var(--border);border-radius:6px;background:var(--panel);color:var(--text);font-family:inherit;">
            <option value="">All Genders</option>
            <option value="Male" <?= $filterGender === 'Male' ? 'selected' : '' ?>>Male</option>
            <option value="Female" <?= $filterGender === 'Female' ? 'selected' : '' ?>>Female</option>
          </select>
        </div>
        <div style="display:flex;flex-direction:column;gap:4px;">
          <label style="font-size:0.75rem;font-weight:500;color:var(--text-muted);">Purok</label>
          <select name="purok" onchange="this.form.submit()" style="padding:6px 10px;font-size:0.82rem;border:1px solid var(--border);border-radius:6px;background:var(--panel);color:var(--text);font-family:inherit;">
            <option value="">All Puroks</option>
            <?php foreach ($purokList as $p): ?>
              <option value="<?= e($p) ?>" <?= $filterPurok === $p ? 'selected' : '' ?>><?= e($p) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div style="display:flex;flex-direction:column;gap:4px;">
          <label style="font-size:0.75rem;font-weight:500;color:var(--text-muted);">Civil Status</label>
          <select name="status" onchange="this.form.submit()" style="padding:6px 10px;font-size:0.82rem;border:1px solid var(--border);border-radius:6px;background:var(--panel);color:var(--text);font-family:inherit;">
            <option value="">All Statuses</option>
            <option value="Single" <?= $filterStatus === 'Single' ? 'selected' : '' ?>>Single</option>
            <option value="Married" <?= $filterStatus === 'Married' ? 'selected' : '' ?>>Married</option>
            <option value="Widowed" <?= $filterStatus === 'Widowed' ? 'selected' : '' ?>>Widowed</option>
            <option value="Separated" <?= $filterStatus === 'Separated' ? 'selected' : '' ?>>Separated</option>
            <option value="Divorced" <?= $filterStatus === 'Divorced' ? 'selected' : '' ?>>Divorced</option>
          </select>
        </div>
        <div style="display:flex;flex-direction:column;gap:4px;">
          <label style="font-size:0.75rem;font-weight:500;color:var(--text-muted);">Occupation</label>
          <select name="occupation" onchange="this.form.submit()" style="padding:6px 10px;font-size:0.82rem;border:1px solid var(--border);border-radius:6px;background:var(--panel);color:var(--text);font-family:inherit;">
            <option value="">All Occupations</option>
            <?php foreach ($occupationList as $o): ?>
              <option value="<?= e($o) ?>" <?= $filterOccupation === $o ? 'selected' : '' ?>><?= e($o ?: 'None') ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div style="display:flex;flex-direction:column;gap:4px;">
          <label style="font-size:0.75rem;font-weight:500;color:var(--text-muted);">Min Age</label>
          <input type="number" name="min_age" value="<?= e($minAge) ?>" placeholder="0" style="width:60px;padding:6px 8px;font-size:0.82rem;border:1px solid var(--border);border-radius:6px;background:var(--panel);color:var(--text);font-family:inherit;">
        </div>
        <div style="display:flex;flex-direction:column;gap:4px;">
          <label style="font-size:0.75rem;font-weight:500;color:var(--text-muted);">Max Age</label>
          <input type="number" name="max_age" value="<?= e($maxAge) ?>" placeholder="130" style="width:60px;padding:6px 8px;font-size:0.82rem;border:1px solid var(--border);border-radius:6px;background:var(--panel);color:var(--text);font-family:inherit;">
        </div>
        <button type="submit" style="padding:6px 16px;font-size:0.82rem;border-radius:6px;background:var(--primary);color:#fff;border:none;cursor:pointer;font-family:inherit;font-weight:500;">Filter</button>
        <?php if ($search !== '' || $filterGender !== '' || $filterPurok !== '' || $filterStatus !== '' || $filterOccupation !== '' || $minAge !== '' || $maxAge !== ''): ?>
          <a href="view_members.php" style="padding:6px 14px;font-size:0.82rem;border-radius:6px;background:var(--bg-secondary);border:1px solid var(--border);color:var(--text-muted);text-decoration:none;font-weight:500;white-space:nowrap;">Clear</a>
        <?php endif; ?>
      </form>
      <form method="POST" action="delete_member.php" id="bulkForm">
      <div class="bulk-bar" id="bulkBar">
        <span class="bulk-count"><span id="bulkCount">0</span> selected</span>
        <div class="bulk-actions">
          <button type="submit" name="action" value="delete_selected" class="btn btn-sm btn-danger" onclick="return confirm('Delete selected residents? This cannot be undone.')">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
            Delete
          </button>
        </div>
      </div>
      <div class="table-wrap" style="max-height:560px;overflow-y:auto;">
        <table class="table-sticky">
          <thead>
            <tr>
              <th class="select-cell"><input type="checkbox" id="selectAll" title="Select all"></th>
              <th style="width:50px;">Photo</th>
              <th><span data-tooltip="Unique resident identifier">Resident #</span></th>
              <th>Full Name</th>
              <th>Gender</th>
              <th>Purok</th>
              <th><span data-tooltip="Mobile number">Contact</span></th>
              <th>Address</th>
              <th style="width:180px;">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if (count($members) === 0): ?>
              <tr><td colspan="9">
                <div class="empty-state with-icon">
                  <div class="empty-state-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                  </div>
                  <div class="empty-state-title">No residents found</div>
                  <div class="empty-state-desc">Try adjusting your filters or add a new resident record.</div>
                </div>
              </td></tr>
            <?php endif; ?>
            <?php foreach ($members as $m): ?>
              <tr>
                <td class="select-cell"><input type="checkbox" name="selected_ids[]" value="<?= (int)$m['member_id'] ?>" class="row-checkbox"></td>
                <td>
                  <?php if (!empty($m['photo_path'])): ?>
                    <img src="../<?= e($m['photo_path']) ?>" class="table-photo" alt="<?= e($m['first_name'] . ' ' . $m['last_name']) ?>">
                  <?php else: ?>
                    <div class="table-photo-placeholder"><?= e(strtoupper(substr($m['first_name'], 0, 1) . substr($m['last_name'], 0, 1))) ?></div>
                  <?php endif; ?>
                </td>
                <td><strong><?= e($m['account_number']) ?></strong></td>
                <td><?= e($m['last_name'] . ', ' . $m['first_name']) ?></td>
                <td><?= e(na($m['gender'])) ?></td>
                <td><?= e(na($m['purok'])) ?></td>
                <td><?= e(na($m['contact_number'])) ?></td>
                <td><?= e(na(formatAddress($m))) ?></td>
                <td>
                  <div class="actions-cell">
                    <a href="edit_member.php?id=<?= (int)$m['member_id'] ?>" class="action-btn edit" title="Edit">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"/><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"/></svg>
                    </a>
                    <a href="reset_password.php?id=<?= (int)$m['member_id'] ?>" class="action-btn lock" title="Reset Password">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                    </a>
                    <a href="print_member.php?id=<?= (int)$m['member_id'] ?>" class="action-btn print" title="Print">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                    </a>
                    <button type="button" class="action-btn danger delete-btn" title="Delete" data-name="<?= e($m['first_name'] . ' ' . $m['last_name']) ?>" data-member-id="<?= (int)$m['member_id'] ?>" data-csrf="<?= generateCsrfToken() ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                    </button>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      </form>

      <?php if ($totalPages > 1): ?>
        <div style="display:flex;gap:6px;justify-content:center;margin-top:20px;">
          <?php
          $filterParams = http_build_query(array_filter(['search'=>$search,'gender'=>$filterGender,'purok'=>$filterPurok,'status'=>$filterStatus,'occupation'=>$filterOccupation,'min_age'=>$minAge,'max_age'=>$maxAge]));
          for ($p = 1; $p <= $totalPages; $p++):
            $url = '?page=' . $p . ($filterParams ? '&' . $filterParams : '');
          ?>
            <a href="<?= $url ?>" class="btn btn-sm <?= $p === $page ? 'btn-primary' : 'btn-secondary' ?>"><?= $p ?></a>
          <?php endfor; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<div class="modal-overlay" id="confirmModal">
  <div class="modal-card">
    <div class="modal-icon-danger">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:28px;height:28px;"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
    </div>
    <h2 style="margin:0 0 6px;">Delete Resident</h2>
    <p style="color:var(--text-muted);margin:0 0 20px;">Are you sure you want to permanently delete <strong id="confirmName"></strong>? This action cannot be undone.</p>
    <div style="display:flex;gap:10px;justify-content:center;">
      <button type="button" class="btn btn-secondary" id="confirmCancel">Cancel</button>
      <a href="#" class="btn btn-danger" id="confirmDelete">Delete</a>
    </div>
  </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
  var modal = document.getElementById('confirmModal');
  var nameEl = document.getElementById('confirmName');
  var deleteLink = document.getElementById('confirmDelete');
  var cancelBtn = document.getElementById('confirmCancel');

  var deleteHandler = null;

  document.querySelectorAll('.delete-btn').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      nameEl.textContent = this.getAttribute('data-name');
      var memberId = this.getAttribute('data-member-id');
      var csrf = this.getAttribute('data-csrf');

      if (deleteHandler) {
        deleteLink.removeEventListener('click', deleteHandler);
      }
      deleteHandler = function(ev) {
        ev.preventDefault();
        var form = document.createElement('form');
        form.method = 'POST';
        form.action = 'delete_member.php';
        form.style.display = 'none';

        var csrfInput = document.createElement('input');
        csrfInput.type = 'hidden';
        csrfInput.name = '_csrf_token';
        csrfInput.value = csrf;
        form.appendChild(csrfInput);

        var idInput = document.createElement('input');
        idInput.type = 'hidden';
        idInput.name = 'id';
        idInput.value = memberId;
        form.appendChild(idInput);

        document.body.appendChild(form);
        form.submit();
      };
      deleteLink.addEventListener('click', deleteHandler);
      modal.style.display = 'flex';
    });
  });

  function closeModal() { modal.style.display = 'none'; }
  cancelBtn.addEventListener('click', closeModal);
  modal.addEventListener('click', function(e) { if (e.target === modal) closeModal(); });

  // Bulk select
  var selectAll = document.getElementById('selectAll');
  var rowChecks = document.querySelectorAll('.row-checkbox');
  var bulkBar = document.getElementById('bulkBar');
  var bulkCount = document.getElementById('bulkCount');
  function updateBulk() {
    var checked = document.querySelectorAll('.row-checkbox:checked').length;
    if (checked > 0) { bulkBar.classList.add('show'); bulkCount.textContent = checked; }
    else { bulkBar.classList.remove('show'); }
  }
  if (selectAll) {
    selectAll.addEventListener('change', function() {
      rowChecks.forEach(function(c) { c.checked = selectAll.checked; });
      updateBulk();
    });
  }
  rowChecks.forEach(function(c) {
    c.addEventListener('change', function() {
      if (selectAll) selectAll.checked = rowChecks.length === document.querySelectorAll('.row-checkbox:checked').length;
      updateBulk();
    });
  });
});
</script>
<?php require_once '../includes/footer.php'; ?>