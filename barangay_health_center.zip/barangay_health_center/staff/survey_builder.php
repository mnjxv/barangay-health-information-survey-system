<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
require_once '../includes/survey_functions.php';
requireStaffLogin();

$surveyId = (int)($_GET['id'] ?? 0);
$survey = $surveyId ? getSurvey($pdo, $surveyId) : null;

$title = '';
$description = '';
$startsAt = '';
$endsAt = '';
$status = 'draft';
$questions = [];
$errors = [];
$responseCount = 0;
$saved = false;

// Load existing survey for edit mode
if ($surveyId && $survey) {
    $title = $survey['title'];
    $description = $survey['description'] ?? '';
    $startsAt = $survey['starts_at'] ?? '';
    $endsAt = $survey['ends_at'] ?? '';
    $status = $survey['status'];
    $responseCount = surveyResponseCount($pdo, $surveyId);
    foreach (getSurveyQuestions($pdo, $surveyId) as $q) {
        $questions[] = [
            'qid'      => (string)$q['question_id'],
            'text'     => $q['question_text'],
            'type'     => $q['question_type'],
            'required' => $q['is_required'],
            'choices'  => array_column($q['choices'], 'choice_text'),
        ];
    }
} elseif ($surveyId && !$survey) {
    redirect('surveys.php');
}

$validTypes = ['multiple_choice', 'yes_no', 'rating', 'short_answer'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrfToken();

    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $startsAt = trim($_POST['starts_at'] ?? '');
    $endsAt = trim($_POST['ends_at'] ?? '');
    $status = in_array($_POST['status'] ?? '', ['draft','active','closed'], true) ? $_POST['status'] : 'draft';

    if ($startsAt !== '' && !isValidDateString($startsAt)) $errors[] = 'Opening date is invalid.';
    if ($endsAt !== '' && !isValidDateString($endsAt)) $errors[] = 'Closing date is invalid.';
    if ($startsAt !== '' && $endsAt !== '' && $startsAt > $endsAt) $errors[] = 'Closing date must be after the opening date.';

    if ($title === '') $errors[] = 'Survey title is required.';

    $qids   = $_POST['qid'] ?? [];
    $qtexts = $_POST['qtext'] ?? [];
    $qtypes = $_POST['qtype'] ?? [];
    $qreqs  = $_POST['qreq'] ?? [];
    $choices = $_POST['choices'] ?? [];

    // Rebuild question array from POST (for re-rendering and saving)
    $questions = [];
    foreach ($qtexts as $key => $text) {
        $text = trim($text);
        if ($text === '') continue;
        $type = $qtypes[$key] ?? 'multiple_choice';
        if (!in_array($type, $validTypes, true)) $type = 'multiple_choice';
        $ch = [];
        foreach (($choices[$key] ?? []) as $ct) {
            $ct = trim($ct);
            if ($ct !== '') $ch[] = $ct;
        }
        $questions[] = [
            'qid'      => trim($qids[$key] ?? ''),
            'text'     => $text,
            'type'     => $type,
            'required' => !empty($qreqs[$key]) ? 1 : 0,
            'choices'  => $ch,
        ];
        if ($type === 'multiple_choice' && count($ch) === 0) {
            $errors[] = "Question \"$text\" needs at least one answer choice.";
        }
    }
    if (count($questions) === 0) $errors[] = 'Add at least one question.';

    if (empty($errors)) {
        $pdo->beginTransaction();
        try {
            if ($survey) {
                $upd = $pdo->prepare("UPDATE survey_surveys SET title = ?, description = ?, starts_at = ?, ends_at = ?, status = ? WHERE survey_id = ?");
                $upd->execute([$title, $description ?: null, $startsAt ?: null, $endsAt ?: null, $status, $surveyId]);
            } else {
                $ins = $pdo->prepare("INSERT INTO survey_surveys (title, description, starts_at, ends_at, status, created_by) VALUES (?, ?, ?, ?, ?, ?)");
                $ins->execute([$title, $description ?: null, $startsAt ?: null, $endsAt ?: null, $status, $_SESSION['staff_id']]);
                $surveyId = (int)$pdo->lastInsertId();
            }

            // Remove deleted questions
            foreach (($_POST['removed'] ?? []) as $rid) {
                $rid = (int)$rid;
                if ($rid > 0) {
                    $pdo->prepare("DELETE FROM survey_questions WHERE question_id = ? AND survey_id = ?")->execute([$rid, $surveyId]);
                }
            }

            // Save questions
            $sort = 0;
            $insQ = $pdo->prepare("INSERT INTO survey_questions (survey_id, question_text, question_type, is_required, sort_order) VALUES (?, ?, ?, ?, ?)");
            $updQ = $pdo->prepare("UPDATE survey_questions SET question_text = ?, question_type = ?, is_required = ?, sort_order = ? WHERE question_id = ? AND survey_id = ?");
            $insC = $pdo->prepare("INSERT INTO survey_choices (question_id, choice_text, sort_order) VALUES (?, ?, ?)");
            $delC = $pdo->prepare("DELETE FROM survey_choices WHERE question_id = ?");

            foreach ($questions as $q) {
                $existing = (int)$q['qid'];
                if ($existing) {
                    $chk = $pdo->prepare("SELECT question_id FROM survey_questions WHERE question_id = ? AND survey_id = ?");
                    $chk->execute([$existing, $surveyId]);
                    if (!$chk->fetch()) $existing = 0;
                }

                if ($existing) {
                    $updQ->execute([$q['text'], $q['type'], $q['required'], $sort, $existing, $surveyId]);
                    $questionId = $existing;
                } else {
                    $insQ->execute([$surveyId, $q['text'], $q['type'], $q['required'], $sort]);
                    $questionId = (int)$pdo->lastInsertId();
                }

                $delC->execute([$questionId]);
                if (in_array($q['type'], ['multiple_choice', 'yes_no'], true)) {
                    $choicesList = $q['choices'];
                    if ($q['type'] === 'yes_no' && count($choicesList) === 0) {
                        $choicesList = ['Yes', 'No'];
                    }
                    $cSort = 0;
                    foreach ($choicesList as $ct) {
                        $insC->execute([$questionId, $ct, $cSort]);
                        $cSort++;
                    }
                }

                $sort++;
            }

            rebuildSurveyResults($pdo, $surveyId);
            $pdo->commit();
            $saved = true;
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = 'An error occurred while saving the survey.';
        }
    }
}

if ($saved) {
    setFlash('success', 'Survey saved successfully.');
    redirect('surveys.php');
}

$pageTitle = $survey ? 'Edit Survey' : 'Create Survey';
$userLabel = $_SESSION['staff_name'];
$userRole = 'Staff';
$logoutUrl = 'logout.php';
$assetsPath = '../';
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Surveys','url'=>'surveys.php'], ['label'=>$pageTitle]];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content">

    <?php if (!empty($errors)): ?>
      <div class="alert alert-danger">
        <ul style="margin:0 0 0 18px;"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
      </div>
    <?php endif; ?>

    <?php if ($survey && $responseCount > 0): ?>
      <div class="alert alert-warning"><strong>Heads up:</strong> This survey already has <?= (int)$responseCount ?> response(s). Editing or deleting questions will affect stored answers and recompute results.</div>
    <?php endif; ?>

    <form method="POST" id="builderForm" novalidate>
      <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
      <?php if ($survey): ?><input type="hidden" name="id" value="<?= (int)$survey['survey_id'] ?>"><?php endif; ?>

      <div class="card" style="margin-bottom:24px;">
        <div class="card-header"><h2>Survey Details</h2></div>
        <div class="form-grid cols-3">
          <div class="form-group" style="grid-column:span 2;">
            <label>Survey Title <span class="required">*</span></label>
            <input type="text" id="surveyTitle" name="title" value="<?= e($title) ?>" placeholder="e.g. Barangay Health Services Satisfaction Survey">
          </div>
          <div class="form-group">
            <label>Status</label>
            <select name="status">
              <option value="draft" <?= $status === 'draft' ? 'selected' : '' ?>>Draft (hidden)</option>
              <option value="active" <?= $status === 'active' ? 'selected' : '' ?>>Active (visible)</option>
              <option value="closed" <?= $status === 'closed' ? 'selected' : '' ?>>Closed (deactivated)</option>
            </select>
          </div>
          <div class="form-group" style="grid-column:span 2;">
            <label>Description</label>
            <textarea name="description" rows="3" placeholder="Short description shown to residents..."><?= e($description) ?></textarea>
          </div>
          <div class="form-group">
            <label>Opening Date</label>
            <input type="date" name="starts_at" value="<?= e($startsAt) ?>">
          </div>
          <div class="form-group">
            <label>Closing Date</label>
            <input type="date" name="ends_at" value="<?= e($endsAt) ?>">
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h2>Questions</h2>
          <button type="button" class="btn btn-secondary btn-sm" id="addQuestionBtn">+ Add Question</button>
        </div>

        <div id="questionsContainer">
          <?php foreach ($questions as $qi => $q): ?>
            <?php renderQuestionCard($q, $qi + 1); ?>
          <?php endforeach; ?>
        </div>

        <?php if (count($questions) === 0): ?>
          <div class="empty-state with-icon" id="questionsEmpty">
            <div class="empty-state-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            </div>
            <div class="empty-state-title">No questions yet</div>
            <div class="empty-state-desc">Click "Add Question" to build your survey.</div>
          </div>
        <?php endif; ?>
      </div>

      <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:20px;">
        <a href="surveys.php" class="btn btn-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary">Save Survey</button>
      </div>
    </form>
  </div>
</div>
<?php
function renderQuestionCard($q, $num) {
    $choices = $q['choices'] ?? [];
    $type = $q['type'];
?>
<div class="card q-card" style="margin-bottom:16px;" data-qid="<?= e($q['qid'] ?? '') ?>">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
    <span class="q-number" style="font-size:0.78rem;font-weight:600;color:var(--primary);text-transform:uppercase;letter-spacing:0.05em;">Question <?= (int)$num ?></span>
    <button type="button" class="btn btn-danger btn-sm q-remove">Remove</button>
  </div>
  <div class="form-grid">
    <div class="form-group" style="grid-column:span 2;">
      <label>Question Text <span class="required">*</span></label>
      <textarea class="q-text" rows="2" placeholder="Type the question..."><?= e($q['text']) ?></textarea>
    </div>
    <div class="form-group">
      <label>Type</label>
      <select class="q-type">
        <option value="multiple_choice" <?= $type === 'multiple_choice' ? 'selected' : '' ?>>Multiple Choice</option>
        <option value="yes_no" <?= $type === 'yes_no' ? 'selected' : '' ?>>Yes / No</option>
        <option value="rating" <?= $type === 'rating' ? 'selected' : '' ?>>Rating Scale (1-5)</option>
        <option value="short_answer" <?= $type === 'short_answer' ? 'selected' : '' ?>>Short Answer</option>
      </select>
    </div>
    <div class="form-group" style="display:flex;align-items:flex-end;padding-bottom:4px;">
      <label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:0;">
        <input type="checkbox" class="q-req" <?= !empty($q['required']) ? 'checked' : '' ?> style="width:auto;"> Required
      </label>
    </div>
  </div>
  <div class="q-choices" style="<?= $type === 'multiple_choice' ? '' : 'display:none;' ?>">
    <label style="font-size:0.82rem;font-weight:500;color:var(--text-muted);margin-bottom:8px;display:block;">Answer Choices</label>
    <div class="q-choices-list" style="display:flex;flex-direction:column;gap:8px;margin-bottom:10px;">
      <?php if ($type === 'multiple_choice' && count($choices) === 0): ?>
        <div class="q-choice-row" style="display:flex;gap:8px;"><input type="text" class="q-choice" placeholder="Choice 1" style="flex:1;"><button type="button" class="btn btn-danger btn-sm q-choice-remove">×</button></div>
        <div class="q-choice-row" style="display:flex;gap:8px;"><input type="text" class="q-choice" placeholder="Choice 2" style="flex:1;"><button type="button" class="btn btn-danger btn-sm q-choice-remove">×</button></div>
      <?php else: foreach ($choices as $ci => $ct): ?>
        <div class="q-choice-row" style="display:flex;gap:8px;"><input type="text" class="q-choice" placeholder="Choice <?= $ci + 1 ?>" value="<?= e($ct) ?>" style="flex:1;"><button type="button" class="btn btn-danger btn-sm q-choice-remove">×</button></div>
      <?php endforeach; endif; ?>
    </div>
    <button type="button" class="btn btn-secondary btn-sm q-choice-add">+ Add Choice</button>
  </div>
</div>
<?php } ?>
<script>
(function() {
  function cardTemplate() {
    var div = document.createElement('div');
    div.className = 'card q-card';
    div.style.marginBottom = '16px';
    div.setAttribute('data-qid', '');
    div.innerHTML =
      '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">' +
        '<span class="q-number" style="font-size:0.78rem;font-weight:600;color:var(--primary);text-transform:uppercase;letter-spacing:0.05em;">Question 1</span>' +
        '<button type="button" class="btn btn-danger btn-sm q-remove">Remove</button>' +
      '</div>' +
      '<div class="form-grid">' +
        '<div class="form-group" style="grid-column:span 2;"><label>Question Text <span class="required">*</span></label><textarea class="q-text" rows="2" placeholder="Type the question..."></textarea></div>' +
        '<div class="form-group"><label>Type</label><select class="q-type">' +
          '<option value="multiple_choice">Multiple Choice</option>' +
          '<option value="yes_no">Yes / No</option>' +
          '<option value="rating">Rating Scale (1-5)</option>' +
          '<option value="short_answer">Short Answer</option>' +
        '</select></div>' +
        '<div class="form-group" style="display:flex;align-items:flex-end;padding-bottom:4px;">' +
          '<label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:0;"><input type="checkbox" class="q-req" style="width:auto;" checked> Required</label>' +
        '</div>' +
      '</div>' +
      '<div class="q-choices">' +
        '<label style="font-size:0.82rem;font-weight:500;color:var(--text-muted);margin-bottom:8px;display:block;">Answer Choices</label>' +
        '<div class="q-choices-list" style="display:flex;flex-direction:column;gap:8px;margin-bottom:10px;">' +
          '<div class="q-choice-row" style="display:flex;gap:8px;"><input type="text" class="q-choice" placeholder="Choice 1" style="flex:1;"><button type="button" class="btn btn-danger btn-sm q-choice-remove">×</button></div>' +
          '<div class="q-choice-row" style="display:flex;gap:8px;"><input type="text" class="q-choice" placeholder="Choice 2" style="flex:1;"><button type="button" class="btn btn-danger btn-sm q-choice-remove">×</button></div>' +
        '</div>' +
        '<button type="button" class="btn btn-secondary btn-sm q-choice-add">+ Add Choice</button>' +
      '</div>';
    return div;
  }

  function renumber() {
    document.querySelectorAll('#questionsContainer .q-card').forEach(function(card, i) {
      var n = card.querySelector('.q-number');
      if (n) n.textContent = 'Question ' + (i + 1);
    });
  }

  function syncType(card) {
    var type = card.querySelector('.q-type').value;
    var choices = card.querySelector('.q-choices');
    if (type === 'multiple_choice') choices.style.display = '';
    else choices.style.display = 'none';
  }

  function bindCard(card) {
    card.querySelector('.q-type').addEventListener('change', function() { syncType(card); });
    card.querySelector('.q-remove').addEventListener('click', function() {
      var qid = card.getAttribute('data-qid');
      if (qid) {
        var inp = document.createElement('input');
        inp.type = 'hidden';
        inp.name = 'removed[]';
        inp.value = qid;
        card.parentElement.appendChild(inp);
      }
      card.remove();
      renumber();
      toggleEmpty();
    });
    card.querySelector('.q-choice-add').addEventListener('click', function() {
      var list = card.querySelector('.q-choices-list');
      var row = document.createElement('div');
      row.className = 'q-choice-row';
      row.style.display = 'flex';
      row.style.gap = '8px';
      row.innerHTML = '<input type="text" class="q-choice" placeholder="Choice ' + (list.children.length + 1) + '" style="flex:1;"><button type="button" class="btn btn-danger btn-sm q-choice-remove">×</button>';
      row.querySelector('.q-choice-remove').addEventListener('click', function() { row.remove(); });
      list.appendChild(row);
    });
    card.querySelectorAll('.q-choice-remove').forEach(function(btn) {
      btn.addEventListener('click', function() {
        var list = btn.closest('.q-choices-list');
        btn.closest('.q-choice-row').remove();
        if (list.children.length === 0) {
          var row = document.createElement('div');
          row.className = 'q-choice-row';
          row.style.display = 'flex';
          row.style.gap = '8px';
          row.innerHTML = '<input type="text" class="q-choice" placeholder="Choice 1" style="flex:1;"><button type="button" class="btn btn-danger btn-sm q-choice-remove">×</button>';
          row.querySelector('.q-choice-remove').addEventListener('click', function() { row.remove(); });
          list.appendChild(row);
        }
      });
    });
  }

  function toggleEmpty() {
    var empty = document.getElementById('questionsEmpty');
    if (empty) empty.style.display = document.querySelectorAll('#questionsContainer .q-card').length === 0 ? '' : 'none';
  }

  document.addEventListener('DOMContentLoaded', function() {
    var container = document.getElementById('questionsContainer');
    var addBtn = document.getElementById('addQuestionBtn');

    if (addBtn) {
      addBtn.addEventListener('click', function() {
        var card = cardTemplate();
        bindCard(card);
        container.appendChild(card);
        renumber();
        toggleEmpty();
      });
    }

    document.querySelectorAll('#questionsContainer .q-card').forEach(function(card) {
      bindCard(card);
      syncType(card);
    });

    var form = document.getElementById('builderForm');
    if (form) {
      form.addEventListener('submit', function(e) {
        // Remove any previous generated hidden fields
        form.querySelectorAll('.gen-hidden').forEach(function(el) { el.remove(); });

        var cards = document.querySelectorAll('#questionsContainer .q-card');
        var qid = [], qtext = [], qtype = [], qreq = [];
        var choices = {};
        var valid = true;

        var titleInput = document.getElementById('surveyTitle');
        if (titleInput && titleInput.value.trim() === '') {
          titleInput.classList.add('invalid');
          valid = false;
        } else if (titleInput) {
          titleInput.classList.remove('invalid');
        }

        if (cards.length === 0) valid = false;

        cards.forEach(function(card, i) {
          var text = card.querySelector('.q-text').value.trim();
          var type = card.querySelector('.q-type').value;
          qid.push(card.getAttribute('data-qid'));
          qtext.push(text);
          qtype.push(type);
          qreq.push(card.querySelector('.q-req').checked ? '1' : '0');

          var ch = [];
          if (type === 'multiple_choice') {
            card.querySelectorAll('.q-choice').forEach(function(inp) {
              var v = inp.value.trim();
              if (v !== '') ch.push(v);
            });
            if (ch.length === 0) {
              valid = false;
              var el = card.querySelector('.q-choices');
              var err = el.querySelector('.error-text');
              if (!err) {
                err = document.createElement('span');
                err.className = 'error-text';
                err.textContent = 'Add at least one answer choice.';
                el.appendChild(err);
              }
            }
          }
          choices[i] = ch;
        });

        if (!valid) {
          e.preventDefault();
          return;
        }

        function addHidden(name, value) {
          var inp = document.createElement('input');
          inp.type = 'hidden';
          inp.name = name;
          inp.value = value;
          inp.className = 'gen-hidden';
          form.appendChild(inp);
        }

        qid.forEach(function(v, i) {
          addHidden('qid[]', v);
          addHidden('qtext[]', qtext[i]);
          addHidden('qtype[]', qtype[i]);
          addHidden('qreq[]', qreq[i]);
        });
        Object.keys(choices).forEach(function(i) {
          choices[i].forEach(function(v) {
            addHidden('choices[' + i + '][]', v);
          });
        });
      });
    }
  });
})();
</script>
<?php require_once '../includes/footer.php'; ?>