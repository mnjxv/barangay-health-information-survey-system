<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireStaffLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('user_management.php?tab=staff');
}
requireCsrfToken();

$id = (int)($_POST['id'] ?? 0);
if ($id === (int)$_SESSION['staff_id']) {
    setFlash('danger', 'You cannot delete your own account.');
    redirect('user_management.php?tab=staff');
}

$stmt = $pdo->prepare("SELECT full_name FROM staff WHERE staff_id = ?");
$stmt->execute([$id]);
$row = $stmt->fetch();
if (!$row) {
    setFlash('danger', 'Staff account not found.');
    redirect('user_management.php?tab=staff');
}

$pdo->prepare("DELETE FROM staff WHERE staff_id = ?")->execute([$id]);
setFlash('success', "Staff account '{$row['full_name']}' has been deleted.");
redirect('user_management.php?tab=staff');
