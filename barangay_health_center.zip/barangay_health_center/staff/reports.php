<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireStaffLogin();

// ── Filters ──
$allPuroks = $pdo->query("SELECT DISTINCT purok FROM members WHERE purok IS NOT NULL AND purok != '' ORDER BY purok")->fetchAll(PDO::FETCH_COLUMN);
$filterPurok = $_GET['purok'] ?? '';
$filterGender = $_GET['gender'] ?? '';
if ($filterPurok !== '' && !in_array($filterPurok, $allPuroks, true)) $filterPurok = '';
if ($filterGender !== '' && !in_array($filterGender, ['Male','Female'], true)) $filterGender = '';

$fw = '';
if ($filterPurok !== '')  $fw .= " AND m.purok = " . $pdo->quote($filterPurok);
if ($filterGender !== '') $fw .= " AND m.gender = " . $pdo->quote($filterGender);
$fwm = str_replace('m.', '', $fw);

// ── Summary ──
$totalResidents = (int)$pdo->query("SELECT COUNT(*) FROM members m WHERE 1=1$fwm")->fetchColumn();
$addedThisMonth = (int)$pdo->query("SELECT COUNT(*) FROM members m WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())$fwm")->fetchColumn();
$addedToday     = (int)$pdo->query("SELECT COUNT(*) FROM members m WHERE DATE(created_at) = CURDATE()$fwm")->fetchColumn();
$totalSpouses   = (int)$pdo->query("SELECT COUNT(*) FROM spouse_info")->fetchColumn();
$totalChildren  = (int)$pdo->query("SELECT COUNT(*) FROM children")->fetchColumn();
$marriedMembers = (int)$pdo->query("SELECT COUNT(*) FROM members m WHERE civil_status = 'Married'$fwm")->fetchColumn();
$activeUpdates  = (int)$pdo->query("SELECT COUNT(DISTINCT member_id) FROM update_logs WHERE updated_at >= (NOW() - INTERVAL 30 DAY)")->fetchColumn();
$totalLogs      = (int)$pdo->query("SELECT COUNT(*) FROM update_logs")->fetchColumn();
$uniquePuroks   = (int)$pdo->query("SELECT COUNT(DISTINCT purok) FROM members m WHERE purok IS NOT NULL AND purok != ''$fwm")->fetchColumn();

// ── Age distribution ──
$ageGroups = [
    '0-12'  => "age BETWEEN 0 AND 12",
    '13-17' => "age BETWEEN 13 AND 17",
    '18-39' => "age BETWEEN 18 AND 39",
    '40-59' => "age BETWEEN 40 AND 59",
    '60+'   => "age >= 60"
];
$ageData = [];
foreach ($ageGroups as $label => $cond) {
    $ageData[$label] = (int)$pdo->query("SELECT COUNT(*) FROM members m WHERE $cond$fwm")->fetchColumn();
}

// ── Gender ──
$byGender = $pdo->query("SELECT gender, COUNT(*) AS cnt FROM members m WHERE gender IS NOT NULL AND gender != ''$fwm GROUP BY gender ORDER BY cnt DESC")->fetchAll();

// ── Civil status ──
$byCivil = $pdo->query("SELECT civil_status, COUNT(*) AS cnt FROM members m WHERE civil_status IS NOT NULL AND civil_status != ''$fwm GROUP BY civil_status ORDER BY cnt DESC")->fetchAll();

// ── Purok distribution ──
$byPurok = $pdo->query("SELECT purok, COUNT(*) AS cnt FROM members m WHERE purok IS NOT NULL AND purok != ''$fwm GROUP BY purok ORDER BY cnt DESC")->fetchAll();

// ── Occupation ──
$byOccupation = $pdo->query("SELECT occupation, COUNT(*) AS cnt FROM members m WHERE occupation IS NOT NULL AND occupation != ''$fwm GROUP BY occupation ORDER BY cnt DESC")->fetchAll();

// ── Employment categories ──
$empEmployed    = (int)$pdo->query("SELECT COUNT(*) FROM members m WHERE occupation IS NOT NULL AND occupation != '' AND occupation NOT IN ('Student','None','Retired','Unemployed')$fwm")->fetchColumn();
$empUnemployed  = (int)$pdo->query("SELECT COUNT(*) FROM members m WHERE (occupation IS NULL OR occupation = '' OR occupation = 'Unemployed' OR occupation = 'None')$fwm")->fetchColumn();
$empStudents    = (int)$pdo->query("SELECT COUNT(*) FROM members m WHERE occupation = 'Student'$fwm")->fetchColumn();

// ── Character Reference report ──
$refComplete = (int)$pdo->query("SELECT COUNT(*) FROM members m WHERE reference1_name IS NOT NULL AND reference1_name != '' AND reference2_name IS NOT NULL AND reference2_name != ''$fwm")->fetchColumn();
$refMissing  = (int)$pdo->query("SELECT COUNT(*) FROM members m WHERE (reference1_name IS NULL OR reference1_name = '' OR reference2_name IS NULL OR reference2_name = '')$fwm")->fetchColumn();

// ── Incomplete Profiles ──
$incompleteProfiles = $pdo->query("SELECT member_id, account_number, last_name, first_name FROM members m WHERE (address IS NULL OR address = '' OR contact_number IS NULL OR contact_number = '' OR birthday IS NULL OR gender IS NULL OR gender = '')$fwm")->fetchAll();

// ── Monthly registrations ──
$monthlyLabels = []; $monthlyData = [];
$monthlyRows = $pdo->query("SELECT MONTH(created_at) AS m, COUNT(*) AS cnt FROM members m WHERE YEAR(created_at) = YEAR(CURDATE())$fwm GROUP BY MONTH(created_at)")->fetchAll();
$monthlyMap = [];
foreach ($monthlyRows as $r) { $monthlyMap[(int)$r['m']] = (int)$r['cnt']; }
for ($m = 1; $m <= 12; $m++) {
    $monthlyLabels[] = date('M', mktime(0, 0, 0, $m, 1));
    $monthlyData[] = $monthlyMap[$m] ?? 0;
}

// ── Recent signups ──
$recentMembers = $pdo->query("SELECT account_number, first_name, last_name, gender, purok, created_at FROM members m WHERE 1=1$fwm ORDER BY created_at DESC LIMIT 10")->fetchAll();

// ── Update activity (last 14 days) ──
$updateActivity = []; $updateLabels = [];
$updateRows = $pdo->query("SELECT DATEDIFF(CURDATE(), DATE(updated_at)) AS days_ago, COUNT(*) AS cnt FROM update_logs WHERE updated_at >= CURDATE() - INTERVAL 13 DAY GROUP BY DATE(updated_at)")->fetchAll();
$updateMap = [];
foreach ($updateRows as $r) { $updateMap[(int)$r['days_ago']] = (int)$r['cnt']; }
for ($d = 13; $d >= 0; $d--) {
    $updateLabels[] = date('M d', strtotime("-$d days"));
    $updateActivity[] = $updateMap[$d] ?? 0;
}

// ── Top sections updated ──
$bySection = $pdo->query("SELECT section, COUNT(*) AS cnt FROM update_logs GROUP BY section ORDER BY cnt DESC")->fetchAll();

// ── Staff update counts ──
$byStaff = $pdo->query("SELECT updated_by_name, COUNT(*) AS cnt FROM update_logs WHERE updated_by = 'Staff' GROUP BY updated_by_name ORDER BY cnt DESC")->fetchAll();

// ── Members with/without children ──
$withChildren  = (int)$pdo->query("SELECT COUNT(DISTINCT member_id) FROM children")->fetchColumn();
$withoutChildren = $totalResidents - $withChildren;

$pageTitle = 'Resident Reports';
$userLabel = $_SESSION['staff_name'];
$userRole  = 'Staff';
$logoutUrl = 'logout.php';
$assetsPath = '../';
$breadcrumbs = [['label' => 'Dashboard', 'url' => 'dashboard.php'], ['label' => 'Resident Reports']];
require_once '../includes/header.php';
?>
<style>
.report-tabs {
  display:flex; gap:4px; margin-bottom:28px; background:var(--bg-secondary);
  padding:4px; border-radius:var(--radius-sm); flex-wrap:wrap;
}
.report-tab {
  padding:10px 20px; border-radius:var(--radius-xs); cursor:pointer;
  font-size:0.82rem; font-weight:500; color:var(--text-muted);
  transition:all var(--transition); border:none; background:none; font-family:inherit;
}
.report-tab:hover { color:var(--text); background:var(--panel); }
.report-tab.active { background:var(--panel); color:var(--primary); font-weight:600; box-shadow:var(--shadow); }
.report-section { display:none; }
.report-section.active { display:block; }
.report-grid {
  display:grid; grid-template-columns:repeat(auto-fit, minmax(240px,1fr)); gap:16px; margin-bottom:28px;
}
.report-kpi {
  background:var(--panel); border:1px solid var(--border); border-radius:var(--radius);
  padding:24px; box-shadow:var(--shadow);
}
.report-kpi .kpi-value { font-size:2rem; font-weight:700; color:var(--text); letter-spacing:-0.03em; line-height:1.1; }
.report-kpi .kpi-label { font-size:0.78rem; color:var(--text-muted); margin-top:6px; }
.report-kpi .kpi-sub { font-size:0.72rem; color:var(--text-dim); margin-top:2px; }
.chart-row {
  display:grid; grid-template-columns:1fr 1fr; gap:24px; margin-bottom:28px;
}
@media (max-width:900px) { .chart-row { grid-template-columns:1fr; } }
.chart-box {
  background:var(--panel); border:1px solid var(--border); border-radius:var(--radius);
  padding:24px; box-shadow:var(--shadow);
}
.chart-box .chart-hd { font-size:0.88rem; font-weight:600; margin-bottom:16px; color:var(--text); }
.chart-box canvas { max-height:220px; max-width:100%; }

/* export bar */
.export-bar {
  display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin-bottom:20px;
}
@media print { .no-print { display:none !important; } body { background:#fff; } }
</style>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content">

    <!-- Filters -->
    <form method="GET" class="no-print" style="display:flex;gap:12px;align-items:end;flex-wrap:wrap;margin-bottom:20px;padding:16px 20px;background:var(--panel);border:1px solid var(--border);border-radius:var(--radius-sm);">
      <div>
        <label style="font-size:0.75rem;font-weight:600;color:var(--text-muted);display:block;margin-bottom:4px;">Purok</label>
        <select name="purok" style="padding:8px 14px;border:1px solid var(--border);border-radius:var(--radius-xs);font-size:0.85rem;font-family:inherit;color:var(--text);background:var(--bg);">
          <option value="">All Puroks</option>
          <?php foreach ($allPuroks as $p): ?>
            <option value="<?= e($p) ?>" <?= $filterPurok === $p ? 'selected' : '' ?>><?= e($p) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label style="font-size:0.75rem;font-weight:600;color:var(--text-muted);display:block;margin-bottom:4px;">Gender</label>
        <select name="gender" style="padding:8px 14px;border:1px solid var(--border);border-radius:var(--radius-xs);font-size:0.85rem;font-family:inherit;color:var(--text);background:var(--bg);">
          <option value="">All Genders</option>
          <option value="Male" <?= $filterGender === 'Male' ? 'selected' : '' ?>>Male</option>
          <option value="Female" <?= $filterGender === 'Female' ? 'selected' : '' ?>>Female</option>
        </select>
      </div>
      <button type="submit" class="btn btn-sm btn-primary">Apply</button>
      <?php if ($filterPurok !== '' || $filterGender !== ''): ?>
        <a href="reports.php" class="btn btn-sm btn-secondary">Clear</a>
      <?php endif; ?>
      <?php if ($filterPurok !== '' || $filterGender !== ''): ?>
        <span style="font-size:0.78rem;color:var(--text-muted);">Filtering <?= (int)$totalResidents ?> resident(s)</span>
      <?php endif; ?>
    </form>

    <!-- Tabs -->
    <div class="report-tabs no-print">
      <button class="report-tab active" data-tab="overview">Overview</button>
      <button class="report-tab" data-tab="demographics">Demographics</button>
      <button class="report-tab" data-tab="household">Household</button>
      <button class="report-tab" data-tab="activity">Activity</button>
      <button class="report-tab" data-tab="directory">Directory</button>
      <button class="report-tab" data-tab="profiles">Profiles</button>
    </div>

    <!-- ─── OVERVIEW ─── -->
    <div class="report-section active" id="tab-overview">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:4px;">
        <h2 style="margin:0;font-size:1.15rem;font-weight:600;">Executive Summary</h2>
        <button onclick="window.print()" class="btn btn-sm btn-secondary no-print">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
          Print
        </button>
      </div>
      <p class="text-muted" style="font-size:0.82rem;margin-bottom:24px;">Generated <?= date('F d, Y h:i A') ?></p>

      <div class="report-grid">
        <div class="report-kpi">
          <div class="kpi-value"><span data-count="<?= (int)$totalResidents ?>">0</span></div>
          <div class="kpi-label">Total Residents</div>
          <div class="kpi-sub"><span data-count="<?= (int)$addedToday ?>">0</span> joined today</div>
        </div>
        <div class="report-kpi">
          <div class="kpi-value"><span data-count="<?= (int)$addedThisMonth ?>">0</span></div>
          <div class="kpi-label">New This Month</div>
          <div class="kpi-sub"><?= date('F Y') ?></div>
        </div>
        <div class="report-kpi">
          <div class="kpi-value"><span data-count="<?= (int)$activeUpdates ?>">0</span></div>
          <div class="kpi-label">Active Records (30d)</div>
          <div class="kpi-sub"><?= round($totalResidents > 0 ? ($activeUpdates / $totalResidents) * 100 : 0) ?>% of residents</div>
        </div>
        <div class="report-kpi">
          <div class="kpi-value"><span data-count="<?= (int)$totalLogs ?>">0</span></div>
          <div class="kpi-label">Total Updates Logged</div>
          <div class="kpi-sub">Across <?= count($bySection) ?> sections</div>
        </div>
      </div>

      <div class="chart-row">
        <div class="chart-box">
          <div class="chart-hd">Monthly Registration (<?= date('Y') ?>)</div>
          <canvas id="overviewMonthly"></canvas>
        </div>
        <div class="chart-box">
          <div class="chart-hd">Update Activity (Last 14 Days)</div>
          <canvas id="overviewUpdates"></canvas>
        </div>
      </div>
    </div>

    <!-- ─── DEMOGRAPHICS ─── -->
    <div class="report-section" id="tab-demographics">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
        <h2 style="margin:0;font-size:1.15rem;font-weight:600;">Demographics</h2>
        <button onclick="window.print()" class="btn btn-sm btn-secondary no-print">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
          Print
        </button>
      </div>
      <p class="text-muted" style="font-size:0.82rem;margin-bottom:24px;">Age, gender, and civil status breakdown</p>

      <div class="chart-row">
        <div class="chart-box">
          <div class="chart-hd">Age Distribution</div>
          <canvas id="demoAge"></canvas>
        </div>
        <div class="chart-box">
          <div class="chart-hd">Gender Split</div>
          <canvas id="demoGender"></canvas>
        </div>
      </div>

      <div class="chart-row">
        <div class="chart-box">
          <div class="chart-hd">Civil Status</div>
          <canvas id="demoCivil"></canvas>
        </div>
        <div class="chart-box">
          <div class="chart-hd">Occupation</div>
          <canvas id="demoOccupation"></canvas>
        </div>
      </div>

      <div class="chart-box" style="margin-bottom:24px;">
        <div class="chart-hd">Occupation Breakdown</div>
        <div class="table-wrap">
        <table>
          <thead><tr><th>Occupation</th><th>Count</th></tr></thead>
          <tbody>
            <?php foreach ($byOccupation as $r): ?>
              <tr><td><?= e($r['occupation']) ?></td><td><strong><?= (int)$r['cnt'] ?></strong></td></tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        </div>
      </div>
    </div>

    <!-- ─── HOUSEHOLD ─── -->
    <div class="report-section" id="tab-household">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
        <h2 style="margin:0;font-size:1.15rem;font-weight:600;">Household Report</h2>
        <button onclick="window.print()" class="btn btn-sm btn-secondary no-print">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
          Print
        </button>
      </div>
      <p class="text-muted" style="font-size:0.82rem;margin-bottom:24px;">Family composition and geographic distribution</p>

      <div class="report-grid">
        <div class="report-kpi">
          <div class="kpi-value"><span data-count="<?= (int)$marriedMembers ?>">0</span></div>
          <div class="kpi-label">Married Residents</div>
          <div class="kpi-sub"><?= $totalResidents > 0 ? round(($marriedMembers / $totalResidents) * 100) : 0 ?>% of total</div>
        </div>
        <div class="report-kpi">
          <div class="kpi-value"><span data-count="<?= (int)$totalSpouses ?>">0</span></div>
          <div class="kpi-label">Spouses Recorded</div>
          <div class="kpi-sub"><?= $marriedMembers > 0 ? round(($totalSpouses / $marriedMembers) * 100) : 0 ?>% of married have spouse info</div>
        </div>
        <div class="report-kpi">
          <div class="kpi-value"><span data-count="<?= (int)$withChildren ?>">0</span></div>
          <div class="kpi-label">Residents w/ Children</div>
          <div class="kpi-sub"><?= $totalResidents > 0 ? round(($withChildren / $totalResidents) * 100) : 0 ?>% of residents</div>
        </div>
        <div class="report-kpi">
          <div class="kpi-value"><span data-count="<?= (int)$uniquePuroks ?>">0</span></div>
          <div class="kpi-label">Puroks Covered</div>
          <div class="kpi-sub"><?= (int)$totalChildren ?> total children recorded</div>
        </div>
      </div>

      <div class="chart-row">
        <div class="chart-box">
          <div class="chart-hd">Residents by Purok</div>
          <canvas id="hhPurok"></canvas>
        </div>
        <div class="chart-box">
          <div class="chart-hd">Children Distribution</div>
          <canvas id="hhChildren"></canvas>
        </div>
      </div>

      <div class="chart-box" style="margin-bottom:24px;">
        <div class="chart-hd">Purok Breakdown</div>
        <div class="table-wrap">
        <table>
          <thead><tr><th>Purok</th><th>Residents</th></tr></thead>
          <tbody>
            <?php foreach ($byPurok as $r): ?>
              <tr><td><?= e($r['purok']) ?></td><td><strong><?= (int)$r['cnt'] ?></strong></td></tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        </div>
      </div>
    </div>

    <!-- ─── ACTIVITY ─── -->
    <div class="report-section" id="tab-activity">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
        <h2 style="margin:0;font-size:1.15rem;font-weight:600;">Activity Report</h2>
        <button onclick="window.print()" class="btn btn-sm btn-secondary no-print">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
          Print
        </button>
      </div>
      <p class="text-muted" style="font-size:0.82rem;margin-bottom:24px;">Registration trends and update activity</p>

      <div class="report-grid">
        <div class="report-kpi">
          <div class="kpi-value"><?= (int)$totalLogs ?></div>
          <div class="kpi-label">Total Updates</div>
          <div class="kpi-sub"><?= $totalResidents > 0 ? round($totalLogs / $totalResidents, 1) : 0 ?> avg per resident</div>
        </div>
        <div class="report-kpi">
          <div class="kpi-value"><?= (int)$activeUpdates ?></div>
          <div class="kpi-label">Updated Last 30 Days</div>
          <div class="kpi-sub"><?= $totalResidents > 0 ? round(($activeUpdates / $totalResidents) * 100) : 0 ?>% engagement rate</div>
        </div>
      </div>

      <div class="chart-row">
        <div class="chart-box">
          <div class="chart-hd">Monthly Registration (<?= date('Y') ?>)</div>
          <canvas id="actMonthly"></canvas>
        </div>
        <div class="chart-box">
          <div class="chart-hd">Updates by Section</div>
          <canvas id="actSection"></canvas>
        </div>
      </div>

      <?php if (count($byStaff) > 0): ?>
      <div class="chart-box" style="margin-bottom:24px;">
        <div class="chart-hd">Staff Activity</div>
        <div class="table-wrap">
        <table>
          <thead><tr><th>Staff</th><th>Updates Made</th></tr></thead>
          <tbody>
            <?php foreach ($byStaff as $r): ?>
              <tr><td><?= e($r['updated_by_name']) ?></td><td><strong><?= (int)$r['cnt'] ?></strong></td></tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        </div>
      </div>
      <?php endif; ?>
    </div>

    <!-- ─── DIRECTORY ─── -->
    <div class="report-section" id="tab-directory">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
        <h2 style="margin:0;font-size:1.15rem;font-weight:600;">Resident Directory</h2>
        <div class="export-bar no-print">
          <button onclick="exportCSV()" class="btn btn-sm btn-primary">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Export CSV
          </button>
          <button onclick="window.print()" class="btn btn-sm btn-secondary">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            Print
          </button>
        </div>
      </div>
      <p class="text-muted" style="font-size:0.82rem;margin-bottom:24px;">Recently added residents</p>
      <div class="table-wrap">
      <table id="directoryTable">
        <thead><tr><th>Resident #</th><th>Name</th><th>Gender</th><th>Purok</th><th>Date Added</th></tr></thead>
        <tbody>
          <?php foreach ($recentMembers as $r): ?>
            <tr>
              <td><strong><?= e($r['account_number']) ?></strong></td>
              <td><?= e($r['first_name'] . ' ' . $r['last_name']) ?></td>
              <td><?= e($r['gender'] ?: '—') ?></td>
              <td><?= e($r['purok'] ?: '—') ?></td>
              <td><?= e(date('M d, Y', strtotime($r['created_at']))) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      </div>
    </div>

    <!-- ─── PROFILES ─── -->
    <div class="report-section" id="tab-profiles">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
        <h2 style="margin:0;font-size:1.15rem;font-weight:600;">Profile Reports</h2>
        <div class="export-bar no-print">
          <button onclick="window.print()" class="btn btn-sm btn-secondary">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            Print
          </button>
        </div>
      </div>

      <p class="text-muted" style="font-size:0.82rem;margin-bottom:24px;">Employment, character references, and profile completeness</p>

      <div class="report-grid">
        <div class="report-kpi">
          <div class="kpi-value"><?= (int)$empEmployed ?></div>
          <div class="kpi-label">Employed</div>
          <div class="kpi-sub">Has occupation on file</div>
        </div>
        <div class="report-kpi">
          <div class="kpi-value"><?= (int)$empUnemployed ?></div>
          <div class="kpi-label">Unemployed</div>
          <div class="kpi-sub">No occupation recorded</div>
        </div>
        <div class="report-kpi">
          <div class="kpi-value"><?= (int)$empStudents ?></div>
          <div class="kpi-label">Students</div>
          <div class="kpi-sub">Occupation listed as Student</div>
        </div>
        <div class="report-kpi">
          <div class="kpi-value"><?= (int)$refComplete ?></div>
          <div class="kpi-label">Complete References</div>
          <div class="kpi-sub">Both references on file</div>
        </div>
        <div class="report-kpi">
          <div class="kpi-value" style="color:var(--danger);"><?= (int)$refMissing ?></div>
          <div class="kpi-label">Missing References</div>
          <div class="kpi-sub">One or both lacking</div>
        </div>
      </div>

      <div class="chart-row">
        <div class="chart-box">
          <div class="chart-hd">Employment Distribution</div>
          <canvas id="empChart" style="max-height:260px;"></canvas>
        </div>
      </div>

      <?php if (count($incompleteProfiles) > 0): ?>
      <div class="chart-box">
        <h4 style="margin:0 0 12px;font-size:0.85rem;font-weight:600;">Incomplete Profiles (missing address/contact/birthday/gender)</h4>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Resident #</th><th>Name</th></tr></thead>
            <tbody>
              <?php foreach ($incompleteProfiles as $p): ?>
                <tr>
                  <td><strong><?= e($p['account_number']) ?></strong></td>
                  <td><?= e($p['first_name'] . ' ' . $p['last_name']) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php endif; ?>
    </div>

  </div>
</div>
<script src="../assets/js/chart.umd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  const blue  = isDark ? '#4A76B8' : '#2E5A9C';
  const blueL = isDark ? '#5F8AC9' : '#8FADD9';
  const blueP = isDark ? '#274064' : '#D8E4F5';
  const grid  = isDark ? 'rgba(232,228,247,0.06)' : '#EFE8FA';
  const tick  = isDark ? 'rgba(232,228,247,0.4)' : 'rgba(33,26,56,0.4)';
  const w     = isDark ? 'rgba(229,234,242,0.06)' : '#F5F8FC';

  function barChart(id, labels, data, bg) {
    const ctx = document.getElementById(id);
    if (!ctx) return;
    new Chart(ctx, {
      type: 'bar',
      data: { labels, datasets: [{ data, backgroundColor: bg || blue, borderRadius: 6, barPercentage: 0.6 }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: { beginAtZero: true, ticks: { stepSize: 1, font: { size: 10, color: tick } }, grid: { color: grid } },
          x: { ticks: { font: { size: 10, color: tick } }, grid: { display: false } }
        }
      }
    });
  }

  function donutChart(id, labels, data, colors) {
    const ctx = document.getElementById(id);
    if (!ctx) return;
    new Chart(ctx, {
      type: 'doughnut',
      data: { labels, datasets: [{ data, backgroundColor: colors, borderWidth: 0 }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, padding: 12, font: { size: 10, color: tick } } } },
        cutout: '65%'
      }
    });
  }

  // Overview
  barChart('overviewMonthly', <?= json_encode($monthlyLabels) ?>, <?= json_encode($monthlyData) ?>);
  barChart('overviewUpdates', <?= json_encode($updateLabels) ?>, <?= json_encode($updateActivity) ?>, blueL);

  // Demographics
  donutChart('demoAge', <?= json_encode(array_keys($ageData)) ?>, <?= json_encode(array_values($ageData)) ?>, [blue, blueL, blueP, w, '#ccc']);
  donutChart('demoGender', <?= json_encode(array_column($byGender, 'gender')) ?>, <?= json_encode(array_column($byGender, 'cnt')) ?>, [blue, blueP]);
  donutChart('demoCivil', <?= json_encode(array_column($byCivil, 'civil_status')) ?>, <?= json_encode(array_column($byCivil, 'cnt')) ?>, [blue, blueL, blueP, w]);
  donutChart('demoOccupation', <?= json_encode(array_column($byOccupation, 'occupation')) ?>, <?= json_encode(array_column($byOccupation, 'cnt')) ?>, [blue, blueL, blueP, w, '#ccc', '#999']);

  // Household
  barChart('hhPurok', <?= json_encode(array_column($byPurok, 'purok')) ?>, <?= json_encode(array_column($byPurok, 'cnt')) ?>);
  donutChart('hhChildren', ['With Children', 'No Children'], [<?= (int)$withChildren ?>, <?= (int)$withoutChildren ?>], [blue, blueP]);

  // Activity
  barChart('actMonthly', <?= json_encode($monthlyLabels) ?>, <?= json_encode($monthlyData) ?>);
  barChart('actSection', <?= json_encode(array_column($bySection, 'section')) ?>, <?= json_encode(array_column($bySection, 'cnt')) ?>, blueL);

  // Profiles
  donutChart('empChart', ['Employed','Unemployed','Student'], [<?= (int)$empEmployed ?>, <?= (int)$empUnemployed ?>, <?= (int)$empStudents ?>], [blue, '#ccc', blueL]);

  // Tab switching
  document.querySelectorAll('.report-tab').forEach(function(tab) {
    tab.addEventListener('click', function() {
      document.querySelectorAll('.report-tab').forEach(function(t) { t.classList.remove('active'); });
      document.querySelectorAll('.report-section').forEach(function(s) { s.classList.remove('active'); });
      this.classList.add('active');
      document.getElementById('tab-' + this.getAttribute('data-tab')).classList.add('active');
    });
  });

  // Re-render charts when switching to a tab (fix sizing)
  document.querySelectorAll('.report-tab').forEach(function(tab) {
    tab.addEventListener('click', function() {
      setTimeout(function() {
        window.dispatchEvent(new Event('resize'));
      }, 100);
    });
  });
});
</script>
<script>
function exportCSV() {
  var rows = [['Resident #','Name','Gender','Purok','Date Added']];
  document.querySelectorAll('#directoryTable tbody tr').forEach(function(tr) {
    var cols = [];
    tr.querySelectorAll('td').forEach(function(td) { cols.push(td.textContent.trim()); });
    if (cols.length) rows.push(cols);
  });
  var csv = rows.map(function(r) { return r.map(function(c) { return '"' + c.replace(/"/g,'""') + '"'; }).join(','); }).join('\n');
  var blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
  var a = document.createElement('a'); a.href = URL.createObjectURL(blob);
  a.download = 'resident_directory_' + new Date().toISOString().slice(0,10) + '.csv';
  a.click(); URL.revokeObjectURL(a.href);
}
</script>
<?php require_once '../includes/footer.php'; ?>
