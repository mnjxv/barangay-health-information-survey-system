<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireStaffLogin();

$tab = $_GET['tab'] ?? 'staff';
if (!in_array($tab, ['staff', 'residents'])) $tab = 'staff';
$search = trim($_GET['search'] ?? '');
$filterStatus = $_GET['status'] ?? '';

if ($tab === 'staff') {
    $where = [];
    $bindings = [];
    if ($search !== '') {
        $where[] = '(username LIKE :s1 OR full_name LIKE :s2 OR email LIKE :s3)';
        $bindings = [':s1' => "%$search%", ':s2' => "%$search%", ':s3' => "%$search%"];
    }
    if ($filterStatus === 'active') $where[] = "is_active = 1";
    elseif ($filterStatus === 'inactive') $where[] = "is_active = 0";

    $sql = "SELECT * FROM staff";
    if (count($where)) $sql .= ' WHERE ' . implode(' AND ', $where);
    $sql .= ' ORDER BY is_active DESC, full_name ASC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($bindings);
    $staffList = $stmt->fetchAll();
    $totalStaff = (int)$pdo->query("SELECT COUNT(*) FROM staff")->fetchColumn();
} else {
    $where = [];
    $bindings = [];
    if ($search !== '') {
        $where[] = '(account_number LIKE :s1 OR last_name LIKE :s2 OR first_name LIKE :s3 OR email LIKE :s4 OR contact_number LIKE :s5)';
        $bindings = [':s1' => "%$search%", ':s2' => "%$search%", ':s3' => "%$search%", ':s4' => "%$search%", ':s5' => "%$search%"];
    }
    if ($filterStatus === 'active') $where[] = "is_active = 1";
    elseif ($filterStatus === 'inactive') $where[] = "is_active = 0";

    $sql = "SELECT member_id, account_number, first_name, last_name, middle_name, extension_name, email, contact_number, must_change_password, is_active FROM members";
    if (count($where)) $sql .= ' WHERE ' . implode(' AND ', $where);
    $sql .= ' ORDER BY is_active DESC, account_number ASC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($bindings);
    $memberList = $stmt->fetchAll();
    $totalMembers = (int)$pdo->query("SELECT COUNT(*) FROM members")->fetchColumn();
}

$pageTitle = 'User Management';
$userLabel = $_SESSION['staff_name'];
$userRole = 'Staff';
$logoutUrl = 'logout.php';
$assetsPath = '../';
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'User Management']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content">

    <div style="display:flex;gap:8px;margin-bottom:20px;">
      <a href="?tab=staff" class="btn <?= $tab === 'staff' ? 'btn-primary' : 'btn-secondary' ?>">Staff Accounts (<?= $totalStaff ?>)</a>
      <a href="?tab=residents" class="btn <?= $tab === 'residents' ? 'btn-primary' : 'btn-secondary' ?>">Resident Accounts (<?= $totalMembers ?>)</a>
    </div>

    <div class="card">
      <div class="card-header">
        <?php if ($tab === 'staff'): ?>
          <h2>Staff Accounts</h2>
          <a href="add_staff.php" class="btn-primary-action">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Add Staff Account
          </a>
        <?php else: ?>
          <h2>Resident Accounts</h2>
          <a href="add_member.php" class="btn-primary-action">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Add Resident Account
          </a>
        <?php endif; ?>
      </div>

      <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;padding:14px 16px;background:var(--bg-secondary);border-radius:var(--radius-sm);border:1px solid var(--border);">
        <input type="hidden" name="tab" value="<?= e($tab) ?>">
        <div style="display:flex;flex-direction:column;gap:4px;">
          <label style="font-size:0.75rem;font-weight:500;color:var(--text-muted);">Search</label>
          <div style="display:flex;gap:6px;">
            <input type="text" name="search" value="<?= e($search) ?>" placeholder="<?= $tab === 'staff' ? 'Search username, name, or email...' : 'Search resident #, name, email, or contact...' ?>" style="width:250px;padding:7px 12px;font-size:0.85rem;border:1px solid var(--border);border-radius:6px;background:var(--panel);color:var(--text);font-family:inherit;">
            <button type="submit" class="btn-primary-action" style="padding:7px 14px;">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:14px;height:14px;"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              Search
            </button>
          </div>
        </div>
        <div style="display:flex;flex-direction:column;gap:4px;">
          <label style="font-size:0.75rem;font-weight:500;color:var(--text-muted);">Status</label>
          <select name="status" onchange="this.form.submit()" style="padding:7px 10px;font-size:0.82rem;border:1px solid var(--border);border-radius:6px;background:var(--panel);color:var(--text);font-family:inherit;">
            <option value="">All</option>
            <option value="active" <?= $filterStatus === 'active' ? 'selected' : '' ?>>Active</option>
            <option value="inactive" <?= $filterStatus === 'inactive' ? 'selected' : '' ?>>Deactivated</option>
          </select>
        </div>
        <?php if ($search !== '' || $filterStatus !== ''): ?>
          <a href="user_management.php?tab=<?= e($tab) ?>" style="padding:7px 12px;font-size:0.82rem;border-radius:6px;background:var(--panel);border:1px solid var(--border);color:var(--text-muted);text-decoration:none;display:inline-flex;align-items:center;">Clear</a>
        <?php endif; ?>
      </form>

      <?php if ($tab === 'staff'): ?>

        <?php if (count($staffList) === 0): ?>
          <div class="empty-state with-icon">
            <div class="empty-state-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            </div>
            <div class="empty-state-title">No staff accounts found</div>
            <div class="empty-state-desc">Try adjusting your search or add a new staff account.</div>
          </div>
        <?php else: ?>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Username</th><th>Full Name</th><th>Email</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead>
            <tbody>
              <?php foreach ($staffList as $u): $isSelf = (int)$u['staff_id'] === (int)$_SESSION['staff_id']; ?>
                <tr>
                  <td><strong><?= e($u['username']) ?></strong><?php if ($isSelf): ?> <span class="badge badge-active" style="margin-left:4px;">You</span><?php endif; ?></td>
                  <td><?= e($u['full_name']) ?></td>
                  <td><?= e(na($u['email'])) ?></td>
                  <td><span class="badge <?= (int)$u['is_active'] === 1 ? 'badge-active' : 'badge-inactive' ?>"><?= (int)$u['is_active'] === 1 ? 'Active' : 'Deactivated' ?></span></td>
                  <td style="font-size:0.8rem;white-space:nowrap;"><?= date('M d, Y', strtotime($u['created_at'])) ?></td>
                  <td>
                    <div class="actions-cell">
                      <a href="edit_staff.php?id=<?= (int)$u['staff_id'] ?>" class="action-btn edit" title="Edit Staff">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"/><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"/></svg>
                        <span class="lbl">Edit</span>
                      </a>
                      <form method="POST" action="staff_status.php" style="display:inline;margin:0;" onsubmit="return confirm('<?= (int)$u['is_active'] === 1 ? 'Deactivate this staff account?' : 'Activate this staff account?' ?>')">
                        <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
                        <input type="hidden" name="id" value="<?= (int)$u['staff_id'] ?>">
                        <button type="submit" class="action-btn <?= (int)$u['is_active'] === 1 ? 'danger' : 'chart' ?>" title="<?= (int)$u['is_active'] === 1 ? 'Deactivate' : 'Activate' ?>" <?= $isSelf ? 'disabled style="opacity:.5;cursor:not-allowed;"' : '' ?>>
                          <?php if ((int)$u['is_active'] === 1): ?>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
                            <span class="lbl">Deactivate</span>
                          <?php else: ?>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                            <span class="lbl">Activate</span>
                          <?php endif; ?>
                        </button>
                      </form>
                      <a href="reset_staff_password.php?id=<?= (int)$u['staff_id'] ?>" class="action-btn lock" title="Reset Password">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                        <span class="lbl">Reset PW</span>
                      </a>
                      <form method="POST" action="staff_delete.php" style="display:inline;margin:0;" onsubmit="return confirm('Delete this staff account? This cannot be undone.')">
                        <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
                        <input type="hidden" name="id" value="<?= (int)$u['staff_id'] ?>">
                        <button type="submit" class="action-btn danger" title="Delete" <?= $isSelf ? 'disabled style="opacity:.5;cursor:not-allowed;"' : '' ?>>
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                          <span class="lbl">Delete</span>
                        </button>
                      </form>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php endif; ?>

      <?php else: ?>

        <?php if (count($memberList) === 0): ?>
          <div class="empty-state with-icon">
            <div class="empty-state-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            </div>
            <div class="empty-state-title">No resident accounts found</div>
            <div class="empty-state-desc">Try adjusting your search or add a new resident account.</div>
          </div>
        <?php else: ?>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Resident #</th><th>Name</th><th>Contact / Email</th><th>Password</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              <?php foreach ($memberList as $m): $fullName = trim($m['last_name'] . ', ' . $m['first_name'] . ($m['middle_name'] ? ' ' . $m['middle_name'] : '') . ($m['extension_name'] ? ' ' . $m['extension_name'] : '')); ?>
                <tr>
                  <td><strong><?= e($m['account_number']) ?></strong></td>
                  <td><?= e($fullName) ?></td>
                  <td style="font-size:0.8rem;"><?= e(na($m['contact_number'])) ?><br><span class="text-muted"><?= e(na($m['email'])) ?></span></td>
                  <td><span class="badge <?= (int)$m['must_change_password'] === 1 ? 'badge-pending' : 'badge-active' ?>"><?= (int)$m['must_change_password'] === 1 ? 'Default' : 'Changed' ?></span></td>
                  <td><span class="badge <?= (int)$m['is_active'] === 1 ? 'badge-active' : 'badge-inactive' ?>"><?= (int)$m['is_active'] === 1 ? 'Active' : 'Deactivated' ?></span></td>
                  <td>
                    <div class="actions-cell">
                      <a href="edit_member.php?id=<?= (int)$m['member_id'] ?>" class="action-btn edit" title="Edit Profile">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"/><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"/></svg>
                        <span class="lbl">Edit</span>
                      </a>
                      <form method="POST" action="member_status.php" style="display:inline;margin:0;" onsubmit="return confirm('<?= (int)$m['is_active'] === 1 ? 'Deactivate this resident account?' : 'Activate this resident account?' ?>')">
                        <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
                        <input type="hidden" name="id" value="<?= (int)$m['member_id'] ?>">
                        <button type="submit" class="action-btn <?= (int)$m['is_active'] === 1 ? 'danger' : 'chart' ?>" title="<?= (int)$m['is_active'] === 1 ? 'Deactivate' : 'Activate' ?>">
                          <?php if ((int)$m['is_active'] === 1): ?>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
                            <span class="lbl">Deactivate</span>
                          <?php else: ?>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                            <span class="lbl">Activate</span>
                          <?php endif; ?>
                        </button>
                      </form>
                      <a href="reset_password.php?id=<?= (int)$m['member_id'] ?>" class="action-btn lock" title="Reset Password">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                        <span class="lbl">Reset PW</span>
                      </a>
                      <a href="delete_member.php?id=<?= (int)$m['member_id'] ?>" class="action-btn danger" title="Delete">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                        <span class="lbl">Delete</span>
                      </a>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php endif; ?>

      <?php endif; ?>
    </div>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>