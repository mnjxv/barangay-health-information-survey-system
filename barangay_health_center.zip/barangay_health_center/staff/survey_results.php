<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
require_once '../includes/survey_functions.php';
requireStaffLogin();
autoCloseExpiredSurveys($pdo);

$surveyId = (int)($_GET['id'] ?? 0);

if ($surveyId) {
    $survey = getSurvey($pdo, $surveyId);
    if (!$survey) redirect('survey_results.php');

    $questions = getSurveyQuestions($pdo, $surveyId);
    $results = getSurveyResults($pdo, $surveyId);
    $shortAnswers = getSurveyShortAnswers($pdo, $surveyId);
    $responseCount = surveyResponseCount($pdo, $surveyId);
    $questionCount = surveyQuestionCount($pdo, $surveyId);

    // For charts: per-question datasets
    $chartData = []; // [{id,type,labels,data}]
    $detailRows = []; // [{question, rows:[{label,count,pct}], short_answers:[]}]
    foreach ($questions as $q) {
        $qid = (int)$q['question_id'];
        $rows = [];
        if (in_array($q['question_type'], ['multiple_choice', 'yes_no'])) {
            foreach ($q['choices'] as $c) {
                $count = $results[$qid][(int)$c['choice_id']] ?? 0;
                $rows[] = ['label' => $c['choice_text'], 'count' => $count];
            }
            $chartData[] = ['type' => 'bar', 'labels' => array_column($rows, 'label'), 'data' => array_column($rows, 'count')];
        } elseif ($q['question_type'] === 'rating') {
            for ($r = 1; $r <= 5; $r++) {
                $count = $results[$qid]['rating'][$r] ?? 0;
                $rows[] = ['label' => (string)$r, 'count' => $count];
            }
            $chartData[] = ['type' => 'bar', 'labels' => array_column($rows, 'label'), 'data' => array_column($rows, 'count')];
        }
        $detailRows[] = [
            'question' => $q,
            'rows' => $rows,
            'short_answers' => $shortAnswers[$qid] ?? [],
        ];
    }

    // Analytics: response rate by purok
    $purokTotal = $pdo->query(
        "SELECT purok, COUNT(*) AS total FROM members
         WHERE purok IS NOT NULL AND purok != '' GROUP BY purok ORDER BY purok"
    )->fetchAll(PDO::FETCH_KEY_PAIR);
    $purokStmt = $pdo->prepare(
        "SELECT m.purok, COUNT(DISTINCT r.member_id) AS responded
         FROM survey_responses r JOIN members m ON m.member_id = r.member_id
         WHERE r.survey_id = ? AND m.purok IS NOT NULL AND m.purok != ''
         GROUP BY m.purok ORDER BY m.purok"
    );
    $purokStmt->execute([$surveyId]);
    $purokResponded = $purokStmt->fetchAll(PDO::FETCH_KEY_PAIR);
    $purokStats = [];
    foreach ($purokTotal as $purok => $total) {
        $total = (int)$total;
        $responded = (int)($purokResponded[$purok] ?? 0);
        $purokStats[] = [
            'purok' => $purok,
            'total' => $total,
            'responded' => $responded,
            'rate' => $total > 0 ? round(($responded / $total) * 100) : 0,
        ];
    }

    // Analytics: average rating by age bracket
    $ageBrackets = ['<18', '18-30', '31-45', '46-60', '60+'];
    $ageStmt = $pdo->prepare(
        "SELECT
            CASE
                WHEN m.age < 18 THEN '<18'
                WHEN m.age <= 30 THEN '18-30'
                WHEN m.age <= 45 THEN '31-45'
                WHEN m.age <= 60 THEN '46-60'
                ELSE '60+'
            END AS bracket,
            a.question_id,
            ROUND(AVG(a.rating_value), 2) AS avg_rating,
            COUNT(*) AS n
         FROM survey_responses r
         JOIN survey_answers a ON a.response_id = r.response_id
         JOIN members m ON m.member_id = r.member_id
         WHERE r.survey_id = ? AND a.rating_value IS NOT NULL AND m.age IS NOT NULL
         GROUP BY bracket, a.question_id
         ORDER BY FIELD(bracket, '<18', '18-30', '31-45', '46-60', '60+')"
    );
    $ageStmt->execute([$surveyId]);
    $ratingByAge = [];
    foreach ($ageStmt->fetchAll() as $row) {
        $ratingByAge[(int)$row['question_id']][$row['bracket']] = [
            'avg' => $row['avg_rating'],
            'n' => (int)$row['n'],
        ];
    }
    $ratingQuestions = array_values(array_filter($questions, function ($q) {
        return $q['question_type'] === 'rating';
    }));

    // Analytics: responses by civil status
    $civStmt = $pdo->prepare(
        "SELECT m.civil_status, COUNT(*) AS n
         FROM survey_responses r JOIN members m ON m.member_id = r.member_id
         WHERE r.survey_id = ? AND m.civil_status IS NOT NULL AND m.civil_status != ''
         GROUP BY m.civil_status ORDER BY n DESC"
    );
    $civStmt->execute([$surveyId]);
    $civStatusRows = $civStmt->fetchAll();

    $pageTitle = 'Survey Results & Analytics';
    $userLabel = $_SESSION['staff_name'];
    $userRole = 'Staff';
    $logoutUrl = 'logout.php';
    $assetsPath = '../';
    $breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Surveys','url'=>'surveys.php'], ['label'=> e($survey['title'])]];
    require_once '../includes/header.php';
?>
<style>
.rate-star { color:#B7791F; }
</style>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content">
    <div class="card" style="margin-bottom:24px;">
      <div class="card-header">
        <h2><?= e($survey['title']) ?></h2>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <a href="survey_respondents.php?id=<?= (int)$survey['survey_id'] ?>" class="btn btn-sm btn-secondary">Respondents (<?= (int)$responseCount ?>)</a>
          <a href="survey_report.php?id=<?= (int)$survey['survey_id'] ?>" class="btn btn-sm btn-primary">Print Report</a>
          <a href="survey_builder.php?id=<?= (int)$survey['survey_id'] ?>" class="btn btn-sm btn-secondary">Edit Survey</a>
        </div>
      </div>
      <?php if (!empty($survey['description'])): ?><p style="color:var(--text-muted);font-size:0.85rem;margin-bottom:12px;"><?= e($survey['description']) ?></p><?php endif; ?>
      <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:0.8rem;color:var(--text-muted);">
        <span><strong><?= (int)$responseCount ?></strong> responses</span>
        <span><strong><?= (int)$questionCount ?></strong> questions</span>
        <span>Period: <?= $survey['starts_at'] ? date('M d, Y', strtotime($survey['starts_at'])) : '—' ?> to <?= $survey['ends_at'] ? date('M d, Y', strtotime($survey['ends_at'])) : '—' ?></span>
      </div>
    </div>

    <?php if ($responseCount === 0): ?>
      <div class="empty-state with-icon">
        <div class="empty-state-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
        </div>
        <div class="empty-state-title">No responses yet</div>
        <div class="empty-state-desc">Once residents start answering, results and charts will appear here.</div>
      </div>
    <?php else: foreach ($detailRows as $di => $item): $q = $item['question']; $qid = (int)$q['question_id']; $chartH = max(44, min(96, count($item['rows']) * 14)); ?>
      <div class="card" style="margin-bottom:20px;">
        <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:16px;flex-wrap:wrap;">
          <div>
            <div style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.08em;margin-bottom:4px;">Question <?= $di + 1 ?></div>
            <div style="font-weight:600;"><?= e($q['question_text']) ?></div>
          </div>
          <span class="badge badge-pending" style="text-transform:none;"><?= ucwords(str_replace('_', ' ', $q['question_type'])) ?></span>
        </div>

        <?php if ($q['question_type'] === 'short_answer'): ?>
          <?php if (count($item['short_answers']) === 0): ?>
            <p class="text-muted" style="font-size:0.85rem;">No text answers yet.</p>
          <?php else: ?>
            <div class="table-wrap">
              <table>
                <thead><tr><th>Resident</th><th>Answer</th></tr></thead>
                <tbody>
                  <?php foreach ($item['short_answers'] as $sa): ?>
                    <tr>
                      <td style="white-space:nowrap;"><strong><?= e($sa['first_name'] . ' ' . $sa['last_name']) ?></strong><br><span style="font-size:0.75rem;color:var(--text-muted);"><?= e($sa['account_number']) ?></span></td>
                      <td><?= e($sa['answer_text']) ?></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        <?php else: ?>
          <div class="chart-row" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
            <div class="chart-box" style="background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px 12px 8px;align-self:start;">
              <div class="chart-hd" style="font-size:0.78rem;font-weight:600;margin-bottom:8px;">Distribution</div>
              <div class="chart-wrap" style="height:<?= $chartH ?>px;"><canvas id="qChart<?= $qid ?>"></canvas></div>
            </div>
            <div class="table-wrap">
              <table>
                <thead><tr><th>Option</th><th>Responses</th><th>%</th></tr></thead>
                <tbody>
                  <?php foreach ($item['rows'] as $row): $pct = $responseCount > 0 ? round(($row['count'] / $responseCount) * 100) : 0; ?>
                    <tr>
                      <td>
                        <?php if ($q['question_type'] === 'rating'): ?>
                          <span class="rate-star"><?= str_repeat('★', (int)$row['label']) ?></span> <span style="color:var(--text-muted);">(<?= $row['label'] ?>/5)</span>
                        <?php else: ?>
                          <?= e($row['label']) ?>
                        <?php endif; ?>
                      </td>
                      <td><strong><?= (int)$row['count'] ?></strong></td>
                      <td><?= $pct ?>%</td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        <?php endif; ?>
      </div>
    <?php endforeach; endif; ?>

    <!-- Survey Analytics -->
    <div class="card" style="margin-bottom:20px;">
      <div class="card-header"><h3>Survey Analytics</h3></div>
    </div>
    <div class="charts-grid">
      <?php if ($purokStats): ?>
      <div class="chart-card">
        <div class="chart-title">Response Rate by Purok</div>
        <div class="chart-wrap" style="height:<?= max(50, min(120, count($purokStats) * 18)) ?>px;"><canvas id="purokChart"></canvas></div>
        <div class="table-wrap" style="margin-top:16px;">
          <table>
            <thead><tr><th>Purok</th><th>Residents</th><th>Responded</th><th>Rate</th></tr></thead>
            <tbody>
              <?php foreach ($purokStats as $p): ?>
                <tr>
                  <td><strong><?= e($p['purok']) ?></strong></td>
                  <td><?= $p['total'] ?></td>
                  <td><?= $p['responded'] ?></td>
                  <td>
                    <div style="display:flex;align-items:center;gap:8px;">
                      <div style="flex:1;min-width:60px;height:6px;background:var(--surface-2,#efe8fa);border-radius:99px;">
                        <div style="width:<?= $p['rate'] ?>%;height:100%;background:var(--success);border-radius:99px;"></div>
                      </div>
                      <span style="font-size:0.75rem;color:var(--text-muted);min-width:34px;"><?= $p['rate'] ?>%</span>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php endif; ?>
      <?php if ($civStatusRows): ?>
      <div class="chart-card">
        <div class="chart-title">Responses by Civil Status</div>
        <div class="chart-wrap" style="height:140px;"><canvas id="civChart"></canvas></div>
        <div class="table-wrap" style="margin-top:16px;">
          <table>
            <thead><tr><th>Civil Status</th><th>Responses</th></tr></thead>
            <tbody>
              <?php foreach ($civStatusRows as $c): ?>
                <tr><td><?= e($c['civil_status']) ?></td><td><strong><?= (int)$c['n'] ?></strong></td></tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php endif; ?>
    </div>
    <?php if ($ratingQuestions): ?>
    <div class="card" style="margin-bottom:20px;">
      <div class="card-header"><h3>Average Rating by Age Group</h3></div>
      <div style="padding:4px 4px 16px 4px;">
        <div class="chart-wrap" style="height:100px;"><canvas id="ageChart"></canvas></div>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Age Group</th>
              <?php foreach ($ratingQuestions as $rq): ?>
                <th><?= e($rq['question_text']) ?></th>
              <?php endforeach; ?>
              <th>Responses</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($ageBrackets as $bk): ?>
              <tr>
                <td><strong><?= e($bk) ?></strong></td>
                <?php
                $bracketN = 0;
                foreach ($ratingQuestions as $rq):
                    $cell = $ratingByAge[(int)$rq['question_id']][$bk] ?? null;
                    $bracketN = max($bracketN, $cell ? $cell['n'] : 0);
                ?>
                  <td><?= $cell ? number_format((float)$cell['avg'], 2) : '—' ?></td>
                <?php endforeach; ?>
                <td><?= $bracketN ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>

  </div>
</div>
<?php if ($responseCount > 0): ?>
<script src="../assets/js/chart.umd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
  var isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  var blue = isDark ? '#4A76B8' : '#2E5A9C';
  var blueL = isDark ? '#5F8AC9' : '#8FADD9';
  var grid = isDark ? 'rgba(232,228,247,0.06)' : '#EFE8FA';
  var tick = isDark ? 'rgba(232,228,247,0.4)' : 'rgba(33,26,56,0.4)';

  var chartData = <?= json_encode($chartData, JSON_HEX_TAG) ?>;
  Object.keys(chartData).forEach(function(i) {
    var d = chartData[i];
    var qid = <?= json_encode(array_map(function($q){ return (int)$q['question_id']; }, $questions)) ?>[i];
    var ctx = document.getElementById('qChart' + qid);
    if (!ctx) return;
    new Chart(ctx, {
      type: 'bar',
      data: { labels: d.labels, datasets: [{ data: d.data, backgroundColor: blue, borderRadius: 5, barPercentage: 0.65, categoryPercentage: 0.8 }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        indexAxis: 'y',
        plugins: { legend: { display: false } },
        scales: {
          x: { beginAtZero: true, ticks: { stepSize: 1, font: { size: 10, color: tick } }, grid: { color: grid } },
          y: { ticks: { font: { size: 11, color: tick } }, grid: { display: false } }
        }
      }
    });
  });

  var purokCanvas = document.getElementById('purokChart');
  if (purokCanvas) {
    new Chart(purokCanvas, {
      type: 'bar',
      data: {
        labels: <?= json_encode(array_column($purokStats, 'purok'), JSON_HEX_TAG) ?>,
        datasets: [{ data: <?= json_encode(array_map(function ($p) { return $p['rate']; }, $purokStats)) ?>, backgroundColor: blue, borderRadius: 5, barPercentage: 0.6, categoryPercentage: 0.75 }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        indexAxis: 'y',
        plugins: { legend: { display: false } },
        scales: {
          x: { beginAtZero: true, max: 100, ticks: { callback: function (v) { return v + '%'; }, font: { size: 10, color: tick } }, grid: { color: grid } },
          y: { ticks: { font: { size: 11, color: tick } }, grid: { display: false } }
        }
      }
    });
  }

  var civCanvas = document.getElementById('civChart');
  if (civCanvas) {
    var civLabels = <?= json_encode(array_column($civStatusRows, 'civil_status'), JSON_HEX_TAG) ?>;
    var civData = <?= json_encode(array_map(function ($c) { return (int)$c['n']; }, $civStatusRows)) ?>;
    new Chart(civCanvas, {
      type: 'doughnut',
      data: {
        labels: civLabels,
        datasets: [{ data: civData, backgroundColor: [blue, blueL, isDark ? '#274064' : '#D8E4F5', '#6B8FA3', '#C59B6D'], borderWidth: 0 }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, padding: 14, font: { size: 11, color: tick } } } },
        cutout: '65%'
      }
    });
  }

  var ageCanvas = document.getElementById('ageChart');
  if (ageCanvas) {
    var ageLabels = <?= json_encode($ageBrackets, JSON_HEX_TAG) ?>;
    var agePalette = [blue, blueL, isDark ? '#274064' : '#D8E4F5', '#6B8FA3', '#C59B6D', '#B7791F'];
    var ageDatasets = <?= json_encode(array_map(function ($rq) use ($ratingByAge, $ageBrackets) {
        return [
            'label' => mb_strimwidth((string)$rq['question_text'], 0, 26, '…'),
            'data' => array_map(function ($bk) use ($ratingByAge, $rq) {
                return isset($ratingByAge[(int)$rq['question_id']][$bk]) ? (float)$ratingByAge[(int)$rq['question_id']][$bk]['avg'] : null;
            }, $ageBrackets),
        ];
    }, $ratingQuestions), JSON_HEX_TAG) ?>;
    ageDatasets.forEach(function (ds, i) { ds.backgroundColor = agePalette[i % agePalette.length]; });
    new Chart(ageCanvas, {
      type: 'bar',
      data: { labels: ageLabels, datasets: ageDatasets },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, padding: 14, font: { size: 11, color: tick } } } },
        scales: {
          y: { beginAtZero: true, max: 5, ticks: { stepSize: 1, font: { size: 10, color: tick } }, grid: { color: grid } },
          x: { ticks: { font: { size: 11, color: tick } }, grid: { display: false } }
        }
      }
    });
  }
});
</script>
<?php endif; ?>
<?php require_once '../includes/footer.php'; ?>
<?php
} else {
    // Summary index
    $search = trim($_GET['search'] ?? '');
    $statusFilter = $_GET['status'] ?? '';
    $respFilter = $_GET['responses'] ?? '';

    $where = [];
    $bindings = [];
    if ($search !== '') {
        $where[] = '(s.title LIKE :stitle OR s.description LIKE :sdesc)';
        $bindings[':stitle'] = "%$search%";
        $bindings[':sdesc'] = "%$search%";
    }
    if ($statusFilter === 'active')       $where[] = "s.status = 'active'";
    elseif ($statusFilter === 'scheduled') $where[] = "s.status = 'active' AND (s.starts_at > CURDATE() OR (s.ends_at IS NOT NULL AND s.ends_at < CURDATE()))";
    elseif ($statusFilter === 'closed')   $where[] = "s.status = 'closed'";
    elseif ($statusFilter === 'draft')    $where[] = "s.status = 'draft'";
    if ($respFilter === 'with')  $where[] = '(SELECT COUNT(*) FROM survey_responses r WHERE r.survey_id = s.survey_id) > 0';
    elseif ($respFilter === 'none') $where[] = '(SELECT COUNT(*) FROM survey_responses r WHERE r.survey_id = s.survey_id) = 0';

    $sql = "SELECT s.*,
            (SELECT COUNT(*) FROM survey_questions q WHERE q.survey_id = s.survey_id) AS question_count,
            (SELECT COUNT(*) FROM survey_responses r WHERE r.survey_id = s.survey_id) AS response_count
            FROM survey_surveys s";
    if (count($where)) $sql .= ' WHERE ' . implode(' AND ', $where);
    $sql .= ' ORDER BY s.created_at DESC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($bindings);
    $surveys = $stmt->fetchAll();

    $pageTitle = 'Survey Results & Analytics';
    $userLabel = $_SESSION['staff_name'];
    $userRole = 'Staff';
    $logoutUrl = 'logout.php';
    $assetsPath = '../';
    $breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Survey Results']];
    require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/staff_sidebar.php'; ?>
  <div class="main-content">
    <div class="card">
      <div class="card-header"><h2>Survey Results (<?= count($surveys) ?>)</h2></div>

      <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;padding:14px 16px;background:var(--bg-secondary);border-radius:var(--radius-sm);border:1px solid var(--border);">
        <div style="display:flex;flex-direction:column;gap:4px;">
          <label style="font-size:0.75rem;font-weight:500;color:var(--text-muted);">Search Survey</label>
          <div style="display:flex;gap:6px;">
            <input type="text" name="search" placeholder="Search by title or description..." value="<?= e($search) ?>" style="width:250px;padding:7px 12px;font-size:0.85rem;border:1px solid var(--border);border-radius:6px;background:var(--panel);color:var(--text);font-family:inherit;">
            <button type="submit" class="btn-primary-action" style="padding:7px 14px;">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:14px;height:14px;"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              Search
            </button>
          </div>
        </div>
        <div style="display:flex;flex-direction:column;gap:4px;">
          <label style="font-size:0.75rem;font-weight:500;color:var(--text-muted);">Status</label>
          <select name="status" onchange="this.form.submit()" style="padding:7px 10px;font-size:0.82rem;border:1px solid var(--border);border-radius:6px;background:var(--panel);color:var(--text);font-family:inherit;">
            <option value="">All Statuses</option>
            <option value="active" <?= $statusFilter === 'active' ? 'selected' : '' ?>>Active</option>
            <option value="scheduled" <?= $statusFilter === 'scheduled' ? 'selected' : '' ?>>Scheduled</option>
            <option value="closed" <?= $statusFilter === 'closed' ? 'selected' : '' ?>>Closed</option>
            <option value="draft" <?= $statusFilter === 'draft' ? 'selected' : '' ?>>Draft</option>
          </select>
        </div>
        <div style="display:flex;flex-direction:column;gap:4px;">
          <label style="font-size:0.75rem;font-weight:500;color:var(--text-muted);">Responses</label>
          <select name="responses" onchange="this.form.submit()" style="padding:7px 10px;font-size:0.82rem;border:1px solid var(--border);border-radius:6px;background:var(--panel);color:var(--text);font-family:inherit;">
            <option value="">All</option>
            <option value="with" <?= $respFilter === 'with' ? 'selected' : '' ?>>With responses</option>
            <option value="none" <?= $respFilter === 'none' ? 'selected' : '' ?>>No responses yet</option>
          </select>
        </div>
        <?php if ($search !== '' || $statusFilter !== '' || $respFilter !== ''): ?>
          <a href="survey_results.php" style="padding:7px 12px;font-size:0.82rem;border-radius:6px;background:var(--panel);border:1px solid var(--border);color:var(--text-muted);text-decoration:none;display:inline-flex;align-items:center;">Clear</a>
        <?php endif; ?>
      </form>
      <?php if (count($surveys) === 0): ?>
        <div class="empty-state with-icon">
          <div class="empty-state-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 20V10"/><path d="M12 20V4"/><path d="M6 20v-6"/></svg>
          </div>
          <?php if ($search !== '' || $statusFilter !== '' || $respFilter !== ''): ?>
            <div class="empty-state-title">No surveys match your filters</div>
            <div class="empty-state-desc">Try adjusting the search text or clearing the status/responses filters.</div>
          <?php else: ?>
            <div class="empty-state-title">No surveys yet</div>
            <div class="empty-state-desc">Create a survey first to see its results.</div>
          <?php endif; ?>
        </div>
      <?php else: ?>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Survey</th><th>Status</th><th>Questions</th><th>Responses</th><th></th></tr></thead>
          <tbody>
            <?php foreach ($surveys as $s): $live = surveyIsLive($s); ?>
              <tr>
                <td>
                  <div style="font-weight:600;"><?= e($s['title']) ?></div>
                  <div style="font-size:0.78rem;color:var(--text-muted);"><?= $s['ends_at'] ? 'Closes ' . date('M d, Y', strtotime($s['ends_at'])) : 'No closing date' ?></div>
                </td>
                <td>
                  <?php if ($s['status'] === 'active') echo '<span class="badge ' . ($live ? 'badge-active' : 'badge-pending') . '">' . ($live ? 'Active' : 'Scheduled') . '</span>';
                        elseif ($s['status'] === 'closed') echo '<span class="badge badge-inactive">Closed</span>';
                        else echo '<span class="badge badge-pending">Draft</span>'; ?>
                </td>
                <td><?= (int)$s['question_count'] ?></td>
                <td><strong><?= (int)$s['response_count'] ?></strong></td>
                <td style="text-align:right;white-space:nowrap;">
                  <a href="survey_results.php?id=<?= (int)$s['survey_id'] ?>" class="btn btn-sm btn-primary">View Results</a>
                  <a href="survey_report.php?id=<?= (int)$s['survey_id'] ?>" class="btn btn-sm btn-secondary">Report</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
<?php } ?>