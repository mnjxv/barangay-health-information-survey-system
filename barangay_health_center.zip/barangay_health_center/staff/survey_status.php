<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireStaffLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('surveys.php');
}
requireCsrfToken();

$id = (int)($_POST['id'] ?? 0);
$stmt = $pdo->prepare("SELECT status FROM survey_surveys WHERE survey_id = ?");
$stmt->execute([$id]);
$current = $stmt->fetchColumn();

if ($current === false) {
    setFlash('danger', 'Survey not found.');
    redirect('surveys.php');
}

$newStatus = $current === 'active' ? 'closed' : 'active';
$pdo->prepare("UPDATE survey_surveys SET status = ? WHERE survey_id = ?")->execute([$newStatus, $id]);

setFlash('success', $newStatus === 'active' ? 'Survey activated.' : 'Survey deactivated.');
redirect('surveys.php');
