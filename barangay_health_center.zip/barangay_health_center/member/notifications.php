<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireMemberLogin();
requireForcePasswordChange($pdo);

$perPage = 20;
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;

$total = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE member_id = ? AND staff_id IS NULL");
$total->execute([$_SESSION['member_id']]);
$total = $total->fetchColumn();
$totalPages = max(1, ceil($total / $perPage));

$stmt = $pdo->prepare(
    "SELECT * FROM notifications WHERE member_id = ? AND staff_id IS NULL
     ORDER BY created_at DESC LIMIT ? OFFSET ?"
);
$stmt->execute([$_SESSION['member_id'], $perPage, $offset]);
$notifications = $stmt->fetchAll();

$pageTitle = 'Notifications';
$userLabel = $_SESSION['member_name'];
$userRole = 'Member';
$showSearch = false;
$logoutUrl = 'logout.php';
$assetsPath = '../';
$hideTopbar = false;
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Notifications']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/member_sidebar.php'; ?>
  <div class="main-content">
    <div class="card">
      <div class="card-header">
        <h2>Notifications (<?= (int)$total ?>)</h2>
        <?php if ($total > 0): ?>
          <button class="btn btn-secondary btn-sm" onclick="markAllRead()">Mark All as Read</button>
        <?php endif; ?>
      </div>
      <div class="notif-page-list">
        <?php if (count($notifications) === 0): ?>
          <div style="padding:40px;text-align:center;color:var(--text-muted);">No notifications yet.</div>
        <?php endif; ?>
        <?php foreach ($notifications as $n): ?>
          <div class="notif-page-item <?= $n['is_read'] ? 'read' : 'unread' ?>" data-id="<?= (int)$n['notification_id'] ?>">
            <div class="notif-page-icon <?= $n['type'] === 'info' ? 'info' : ($n['type'] === 'success' ? 'success' : 'warning') ?>">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:16px;height:16px;">
                <?php if ($n['type'] === 'info'): ?>
                  <circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>
                <?php elseif ($n['type'] === 'success'): ?>
                  <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>
                <?php else: ?>
                  <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
                <?php endif; ?>
              </svg>
            </div>
            <div class="notif-page-content">
              <div class="notif-page-title"><?= e($n['title']) ?></div>
              <?php if ($n['message']): ?><div class="notif-page-msg"><?= e($n['message']) ?></div><?php endif; ?>
              <div class="notif-page-time"><?= e(date('F d, Y h:i A', strtotime($n['created_at']))) ?></div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      <?php if ($totalPages > 1): ?>
        <div style="display:flex;gap:6px;justify-content:center;margin-top:20px;">
          <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <a href="?page=<?= $p ?>" class="btn btn-sm <?= $p === $page ? 'btn-primary' : 'btn-secondary' ?>"><?= $p ?></a>
          <?php endfor; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<script>
function markAllRead() {
  var xhr = new XMLHttpRequest();
  xhr.open('POST', '../ajax/notifications.php', true);
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  xhr.onload = function() {
    document.querySelectorAll('.notif-page-item.unread').forEach(function(el) {
      el.classList.remove('unread');
      el.classList.add('read');
    });
    location.reload();
  };
  xhr.send('action=read_all');
}
</script>
<?php require_once '../includes/footer.php'; ?>
