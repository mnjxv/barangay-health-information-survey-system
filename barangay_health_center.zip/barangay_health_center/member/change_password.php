<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireMemberLogin();

$stmt = $pdo->prepare("SELECT * FROM members WHERE member_id = ?");
$stmt->execute([$_SESSION['member_id']]);
$member = $stmt->fetch();
if (!$member) { redirect('logout.php'); }

$isFirstLogin = isset($_GET['first_login']);
$errors = [];
$pwUpdated = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrfToken();
    $current = $_POST['current_password'] ?? '';
    $new     = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (!password_verify($current, $member['password'])) {
        $errors[] = 'Current password is incorrect.';
    } elseif (strlen($new) < 6) {
        $errors[] = 'New password must be at least 6 characters.';
    } elseif ($new !== $confirm) {
        $errors[] = 'New password and confirmation do not match.';
    } else {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        $upd = $pdo->prepare("UPDATE members SET password = ?, must_change_password = 0 WHERE member_id = ?");
        $upd->execute([$hash, $_SESSION['member_id']]);
        addNotification($pdo, 'success', 'Password Changed', 'Your password has been changed successfully.', $_SESSION['member_id']);
        $pwUpdated = true;
    }
}

$pageTitle = 'Change Password';
$userLabel = $_SESSION['member_name'];
$userRole = 'Member';
$showSearch = false;
$logoutUrl = 'logout.php';
$assetsPath = '../';
$hideTopbar = false;
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Change Password']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/member_sidebar.php'; ?>
  <div class="main-content">
    <?php if ($pwUpdated): ?>
    <div style="display:flex;align-items:center;justify-content:center;min-height:50vh;">
      <div class="modal-card" style="max-width:400px;width:100%;text-align:center;">
        <div class="modal-icon" style="background:var(--success);color:#fff;margin:0 auto 20px;">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:28px;height:28px;"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
        </div>
        <h2 style="margin:0 0 6px;">Password Updated</h2>
        <p style="color:var(--text-muted);margin:0 0 24px;">Your password has been changed successfully.</p>
        <a href="dashboard.php" class="btn btn-primary btn-block">Go to Dashboard</a>
      </div>
    </div>
    <?php else: ?>
    <div class="card" style="max-width:520px;margin:0 auto;">
      <div class="card-header"><h2>Change Password</h2></div>

      <?php if ($isFirstLogin): ?>
        <div class="alert alert-info">This is your first login. Please set a new password to continue.</div>
      <?php endif; ?>
      <?php if ($isFirstLogin): ?>
      <div class="modal-overlay" id="firstLoginModal">
        <div class="modal-card">
          <div class="modal-icon" style="background:#2563eb;color:#fff;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:28px;height:28px;"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
          </div>
          <h2>First-Time Login</h2>
          <p style="margin-bottom:20px;">Welcome! You must change your password before you can access your account.</p>
          <p class="text-muted" style="font-size:0.82rem;margin-bottom:20px;">Your default password was your account number. For security, please set a new password now.</p>
          <button class="btn btn-primary btn-block" onclick="document.getElementById('firstLoginModal').style.display='none'">OK, Change Password</button>
        </div>
      </div>
      <script>document.getElementById('firstLoginModal').style.display = 'flex';</script>
      <?php endif; ?>

      <?php foreach ($errors as $err): ?>
        <div class="alert alert-danger"><?= e($err) ?></div>
      <?php endforeach; ?>

      <form method="POST" id="pwForm" data-validate novalidate>
        <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
        <div class="form-group">
          <label>Current Password <span class="required">*</span></label>
          <input type="password" name="current_password" data-required placeholder="Enter current password">
        </div>
        <div class="form-group">
          <label>New Password <span class="required">*</span></label>
          <input type="password" id="newPassword" name="new_password" data-required placeholder="Enter new password">
          <div class="password-strength" id="pwStrength">
            <div class="strength-bar" data-index="0"></div>
            <div class="strength-bar" data-index="1"></div>
            <div class="strength-bar" data-index="2"></div>
            <div class="strength-bar" data-index="3"></div>
          </div>
          <div class="strength-text" id="pwStrengthText"></div>
        </div>
        <div class="form-group">
          <label>Confirm New Password <span class="required">*</span></label>
          <input type="password" name="confirm_password" data-required data-type="password-match" data-matches="#newPassword" placeholder="Confirm new password">
        </div>
        <button type="submit" class="btn btn-primary btn-block">Update Password</button>
      </form>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
<script>
document.getElementById('newPassword').addEventListener('input', function() {
  var pw = this.value;
  var score = 0;
  if (pw.length >= 6) score++;
  if (pw.length >= 10) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^a-zA-Z0-9]/.test(pw)) score++;
  var bars = document.querySelectorAll('#pwStrength .strength-bar');
  var text = document.getElementById('pwStrengthText');
  var level = score <= 1 ? 'weak' : score === 2 ? 'medium' : score === 3 ? 'strong' : 'very-strong';
  var labels = { weak: 'Weak', medium: 'Medium', strong: 'Strong', very-strong: 'Very Strong' };
  bars.forEach(function(bar, i) {
    bar.className = 'strength-bar' + (i < score ? ' active ' + level : '');
  });
  text.textContent = pw.length > 0 ? labels[level] : '';
  text.className = 'strength-text ' + (pw.length > 0 ? level : '');
});
</script>
