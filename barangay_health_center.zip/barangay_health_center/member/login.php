<?php
require_once '../includes/functions.php';
redirect('../index.php#login-section');
