<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireMemberLogin();
requireForcePasswordChange($pdo);

$memberId = $_SESSION['member_id'];

$stmt = $pdo->prepare("SELECT * FROM members WHERE member_id = ?");
$stmt->execute([$memberId]);
$member = $stmt->fetch();

$purokDb = $pdo->query("SELECT DISTINCT purok FROM members WHERE purok IS NOT NULL AND purok != ''")->fetchAll(PDO::FETCH_COLUMN);
$purokAll = range(1, 20);
$purokAll = array_map(function($n) { return "Purok $n"; }, $purokAll);
$purokList = array_values(array_unique(array_merge($purokAll, $purokDb)));
natsort($purokList); $purokList = array_values($purokList);
if (!$member) { redirect('logout.php'); }

$occupations = ['Student','Teacher','Nurse','Doctor','Engineer','Accountant','Business Owner','Government Employee','OFW','Farmer','Fisherman','Driver','Vendor','Homemaker','Retired','Unemployed','Self-Employed','None','Other'];

$spouseStmt = $pdo->prepare("SELECT * FROM spouse_info WHERE member_id = ?");
$spouseStmt->execute([$memberId]);
$spouse = $spouseStmt->fetch() ?: [];

$childrenStmt = $pdo->prepare("SELECT * FROM children WHERE member_id = ?");
$childrenStmt->execute([$memberId]);
$children = $childrenStmt->fetchAll();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrfToken();
    $lastName  = trim($_POST['last_name'] ?? '');
    $firstName = trim($_POST['first_name'] ?? '');
    $middleName = trim($_POST['middle_name'] ?? '');
    $extName   = trim($_POST['extension_name'] ?? '');
    $civilStatus = $_POST['civil_status'] ?? 'Single';
    $gender    = $_POST['gender'] ?? null;
    $addressHousehold  = trim($_POST['address_household'] ?? '');
    $addressBarangay   = trim($_POST['address_barangay'] ?? '');
    $addressMunicipality = trim($_POST['address_municipality'] ?? '');
    $addressProvince   = trim($_POST['address_province'] ?? '');
    $addressPostal     = trim($_POST['address_postal'] ?? '');
    $addressCountry    = trim($_POST['address_country'] ?? '');
    $purok     = trim($_POST['purok'] ?? '');
    $address   = buildAddress($addressHousehold, $purok, $addressBarangay, $addressMunicipality, $addressProvince, $addressPostal, $addressCountry);
    $contact   = trim($_POST['contact_number'] ?? '');
    $hotline   = trim($_POST['hotline'] ?? '');
    $birthday  = $_POST['birthday'] ?? null;
    $occupation = $_POST['occupation'] ?? '';
    if ($occupation === 'Other') {
        $occupation = trim($_POST['occupation_other'] ?? '');
    }
    $employer  = trim($_POST['employer'] ?? '');
    $employerAddress = trim($_POST['employer_address'] ?? '');
    $fatherName = trim($_POST['father_name'] ?? '');
    $motherName = trim($_POST['mother_name'] ?? '');

    $ref1Name = trim($_POST['reference1_name'] ?? '');
    $ref1Rel  = trim($_POST['reference1_relationship'] ?? '');
    $ref1Contact = trim($_POST['reference1_contact'] ?? '');
    $ref1Addr = trim($_POST['reference1_address'] ?? '');
    $ref2Name = trim($_POST['reference2_name'] ?? '');
    $ref2Rel  = trim($_POST['reference2_relationship'] ?? '');
    $ref2Contact = trim($_POST['reference2_contact'] ?? '');
    $ref2Addr = trim($_POST['reference2_address'] ?? '');

    $emergencyName   = trim($_POST['emergency_contact_name'] ?? '');
    $emergencyRel    = trim($_POST['emergency_contact_relationship'] ?? '');
    $emergencyNumber = trim($_POST['emergency_contact_number'] ?? '');

    $spouseName = trim($_POST['spouse_name'] ?? '');
    $spouseOccupation = trim($_POST['spouse_occupation'] ?? '');
    $spouseEmployer = trim($_POST['spouse_employer'] ?? '');

    $childNames = $_POST['child_name'] ?? [];
    $childAges  = $_POST['child_age'] ?? [];

    if ($lastName === '') $errors[] = 'Last name is required.';
    if ($firstName === '') $errors[] = 'First name is required.';
    if ($civilStatus === '') $errors[] = 'Civil status is required.';
    if ($address === '') $errors[] = 'Address is required (fill in at least one address field).';
    if ($purok === '') $errors[] = 'Purok is required.';
    if ($birthday === '' || $birthday === null) {
        $errors[] = 'Birthday is required.';
    } elseif (!isValidDateString($birthday)) {
        $errors[] = 'Birthday is not a valid date (e.g. February 31 is impossible).';
    } elseif ($birthday > date('Y-m-d')) {
        $errors[] = 'Birthday cannot be a future date.';
    }
    if ($contact === '') {
        $errors[] = 'Contact number is required.';
    } elseif (!preg_match('/^(09\d{9}|\+639\d{9})$/', $contact)) {
        $errors[] = 'Contact number must be a valid PH mobile number (e.g. 09171234567).';
    }
    if ($hotline !== '' && !preg_match('/^(09\d{9}|\+639\d{9}|[0-9\-\s]{7,15})$/', $hotline)) {
        $errors[] = 'Hotline number must be a valid PH mobile or landline number.';
    }
    if ($occupation === '') $errors[] = 'Occupation is required.';
    if ($employerAddress === '') $errors[] = 'Employer address is required.';

    $relationWords = ['father','mother','brother','sister','son','daughter','husband','wife','spouse','aunt','uncle','cousin','grandmother','grandfather','grandma','grandpa','mother-in-law','father-in-law','sister-in-law','brother-in-law','stepfather','stepmother','stepbrother','stepsister'];

    function isFamilyMember($name, $rel, $familyWords) {
        $relLower = strtolower($rel);
        foreach ($familyWords as $word) {
            if (strpos($relLower, $word) !== false) return true;
        }
        return false;
    }

    if ($ref1Name === '') $errors[] = 'Character Reference 1 name is required.';
    if ($ref1Rel === '') $errors[] = 'Character Reference 1 relationship is required.';
    if (isFamilyMember($ref1Name, $ref1Rel, $relationWords)) $errors[] = 'Reference 1 cannot be a family member.';
    if ($ref1Contact !== '' && !preg_match('/^(09\d{9}|\+639\d{9})$/', $ref1Contact)) $errors[] = 'Reference 1 contact number must be a valid PH mobile number.';

    if ($ref2Name === '') $errors[] = 'Character Reference 2 name is required.';
    if ($ref2Rel === '') $errors[] = 'Character Reference 2 relationship is required.';
    if (isFamilyMember($ref2Name, $ref2Rel, $relationWords)) $errors[] = 'Reference 2 cannot be a family member.';
    if ($ref2Contact !== '' && !preg_match('/^(09\d{9}|\+639\d{9})$/', $ref2Contact)) $errors[] = 'Reference 2 contact number must be a valid PH mobile number.';

    $sigPath = $member['signature_path'];
    $sigData = $_POST['signature_data'] ?? '';
    if ($sigData && strpos($sigData, 'data:image/png;base64,') === 0) {
        $base64 = substr($sigData, strlen('data:image/png;base64,'));
        $data = base64_decode($base64);
        if ($data !== false) {
            $filename = 'sig_' . $memberId . '_' . time() . '.png';
            $dest = __DIR__ . '/../uploads/signatures/' . $filename;
            if (file_put_contents($dest, $data)) {
                if ($member['signature_path'] && file_exists('../' . $member['signature_path'])) {
                    unlink('../' . $member['signature_path']);
                }
                $sigPath = 'uploads/signatures/' . $filename;
            }
        }
    } elseif (!empty($_FILES['signature']['name'])) {
        $file = $_FILES['signature'];
        $uploadErr = '';
        if (validateImageUpload($file, $uploadErr)) {
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $filename = 'sig_' . $memberId . '_' . time() . '.' . $ext;
            $dest = __DIR__ . '/../uploads/signatures/' . $filename;
            if (move_uploaded_file($file['tmp_name'], $dest)) {
                if ($member['signature_path'] && file_exists('../' . $member['signature_path'])) {
                    unlink('../' . $member['signature_path']);
                }
                $sigPath = 'uploads/signatures/' . $filename;
            } else {
                $errors[] = 'Could not save signature.';
            }
        } else {
            $errors[] = $uploadErr;
        }
    }

    $photoPath = $member['photo_path'];
    if (!empty($_FILES['photo']['name'])) {
        $file = $_FILES['photo'];
        $uploadErr = '';
        if (validateImageUpload($file, $uploadErr)) {
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $filename = 'member_' . $memberId . '_' . time() . '.' . $ext;
            $destination = __DIR__ . '/../uploads/photos/' . $filename;
            if (move_uploaded_file($file['tmp_name'], $destination)) {
                if ($member['photo_path'] && file_exists('../' . $member['photo_path'])) {
                    unlink('../' . $member['photo_path']);
                }
                $photoPath = 'uploads/photos/' . $filename;
            } else {
                $errors[] = 'Could not save the uploaded photo.';
            }
        } else {
            $errors[] = $uploadErr;
        }
    }

    if (empty($errors)) {
        $age = calculateAge($birthday);
        $pdo->beginTransaction();
        try {
            $upd = $pdo->prepare(
                "UPDATE members SET
                    last_name = ?, first_name = ?, middle_name = ?, extension_name = ?,
                    civil_status = ?, gender = ?, address = ?, address_household = ?, address_barangay = ?, address_municipality = ?, address_province = ?, address_postal = ?, address_country = ?, purok = ?, contact_number = ?, hotline = ?, birthday = ?, age = ?,
                    occupation = ?, employer = ?, employer_address = ?,
                    father_name = ?, mother_name = ?,
                    reference1_name = ?, reference1_relationship = ?, reference1_contact = ?, reference1_address = ?,
                    reference2_name = ?, reference2_relationship = ?, reference2_contact = ?, reference2_address = ?,
                    emergency_contact_name = ?, emergency_contact_relationship = ?, emergency_contact_number = ?,
                    photo_path = ?, signature_path = ?
                 WHERE member_id = ?"
            );
            $upd->execute([
                $lastName, $firstName, $middleName ?: null, $extName ?: null,
                $civilStatus, $gender, $address ?: null,
                $addressHousehold ?: null, $addressBarangay ?: null, $addressMunicipality ?: null, $addressProvince ?: null, $addressPostal ?: null, $addressCountry ?: null,
                $purok ?: null, $contact, $hotline ?: null, $birthday ?: null, $age,
                $occupation ?: null, $employer ?: null, $employerAddress ?: null,
                $fatherName ?: null, $motherName ?: null,
                $ref1Name ?: null, $ref1Rel ?: null, $ref1Contact ?: null, $ref1Addr ?: null,
                $ref2Name ?: null, $ref2Rel ?: null, $ref2Contact ?: null, $ref2Addr ?: null,
                $emergencyName ?: null, $emergencyRel ?: null, $emergencyNumber ?: null,
                $photoPath, $sigPath, $memberId
            ]);

            if ($spouseName !== '') {
                $checkSpouse = $pdo->prepare("SELECT spouse_id FROM spouse_info WHERE member_id = ?");
                $checkSpouse->execute([$memberId]);
                if ($checkSpouse->fetch()) {
                    $updSpouse = $pdo->prepare("UPDATE spouse_info SET spouse_name = ?, occupation = ?, employer = ? WHERE member_id = ?");
                    $updSpouse->execute([$spouseName, $spouseOccupation ?: null, $spouseEmployer ?: null, $memberId]);
                } else {
                    $insSpouse = $pdo->prepare("INSERT INTO spouse_info (member_id, spouse_name, occupation, employer) VALUES (?, ?, ?, ?)");
                    $insSpouse->execute([$memberId, $spouseName, $spouseOccupation ?: null, $spouseEmployer ?: null]);
                }
            } else {
                $delSpouse = $pdo->prepare("DELETE FROM spouse_info WHERE member_id = ?");
                $delSpouse->execute([$memberId]);
            }

            $delChildren = $pdo->prepare("DELETE FROM children WHERE member_id = ?");
            $delChildren->execute([$memberId]);
            $insChild = $pdo->prepare("INSERT INTO children (member_id, child_name, age) VALUES (?, ?, ?)");
            foreach ($childNames as $i => $name) {
                $name = trim($name);
                if ($name === '') continue;
                $childAge = isset($childAges[$i]) && $childAges[$i] !== '' ? (int)$childAges[$i] : null;
                $insChild->execute([$memberId, $name, $childAge]);
            }

            logUpdate($pdo, $memberId, 'Member', $firstName . ' ' . $lastName, 'Personal/Contact/References/Emergency Info', 'Member updated own profile.');
            addNotification($pdo, 'info', 'Profile Updated', "$firstName $lastName updated their profile information.", null, null);
            addNotification($pdo, 'success', 'Profile Updated', 'Your profile information has been updated successfully.', $memberId);

            $pdo->commit();
            $_SESSION['member_name'] = $firstName . ' ' . $lastName;
            $updated = true;
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = 'An error occurred while saving. Please try again.';
        }
    }
}

$pageTitle = 'Update Information';
$userLabel = $_SESSION['member_name'];
$userRole = 'Resident';
$showSearch = false;
$logoutUrl = 'logout.php';
$assetsPath = '../';
$hideTopbar = false;
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Update Info']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/member_sidebar.php'; ?>
  <div class="main-content">

    <?php if (!empty($errors)): ?>
      <div class="alert alert-danger">
        <strong>Please fix the following:</strong>
        <ul style="margin:6px 0 0 18px;">
          <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" id="updateForm" data-validate novalidate>
      <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
      <div class="profile-layout">
        <div>
          <div class="profile-card">
            <img id="photoPreview" class="profile-photo"
                 src="<?= !empty($member['photo_path']) ? e('../' . $member['photo_path']) : '' ?>"
                 alt="Photo">
            <h3 class="profile-name"><?= e($member['first_name'] . ' ' . $member['last_name']) ?></h3>
            <div class="profile-account">Resident #<?= e($member['account_number']) ?></div>
            <div style="margin-top:12px;">
              <div class="drop-zone" style="padding:12px 8px;">
                <div class="drop-zone-icon" style="width:28px;height:28px;margin-bottom:4px;">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:14px;height:14px;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                </div>
                <div class="drop-zone-text" style="font-size:0.72rem;">Tap to upload photo</div>
                <div class="drop-zone-hint" style="font-size:0.65rem;">JPG/PNG, max 2MB</div>
                <input type="file" id="photoInput" name="photo" accept="image/png, image/jpeg">
                <div class="drop-zone-preview">
                  <img class="dz-img" style="display:none;">
                  <div class="dz-meta"><div class="dz-name"></div><div class="dz-size"></div></div>
                  <span class="dz-remove" onclick="var p=this.closest('.drop-zone-preview');p.classList.remove('show');this.closest('.drop-zone').querySelector('input[type=file]').value='';event.stopPropagation();">Remove</span>
                </div>
              </div>
              <button type="button" class="btn btn-primary btn-block profile-save-photo" id="savePhotoBtn" style="display:none;margin-top:12px;">Save</button>
            </div>
          </div>
        </div>

        <div class="form-stack">
          <div class="form-section">
            <h3 class="section-title">Personal Information</h3>
            <div class="card">
              <div class="form-grid cols-3">
                <div class="form-group"><label>Last Name <span class="required">*</span></label><input type="text" name="last_name" data-required placeholder="Enter last name" value="<?= e($member['last_name']) ?>"></div>
                <div class="form-group"><label>First Name <span class="required">*</span></label><input type="text" name="first_name" data-required placeholder="Enter first name" value="<?= e($member['first_name']) ?>"></div>
                <div class="form-group"><label>Middle Name</label><input type="text" name="middle_name" placeholder="Enter middle name (optional)" value="<?= e($member['middle_name']) ?>"></div>
                <div class="form-group"><label>Extension Name</label><input type="text" name="extension_name" placeholder="Jr., Sr., III" value="<?= e($member['extension_name']) ?>"></div>
                <div class="form-group">
                  <label>Civil Status <span class="required">*</span></label>
                  <select name="civil_status" data-required id="civilStatus">
                    <option value="" disabled <?= empty($member['civil_status']) ? 'selected' : '' ?>>Select civil status</option>
                    <?php foreach (['Single','Married','Widowed','Separated','Divorced'] as $cs): ?>
                      <option value="<?= $cs ?>" <?= $member['civil_status'] === $cs ? 'selected' : '' ?>><?= $cs ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="form-group">
                  <label>Gender</label>
                  <select name="gender">
                    <option value="" disabled <?= empty($member['gender']) ? 'selected' : '' ?>>Select gender</option>
                    <option value="Male" <?= $member['gender'] === 'Male' ? 'selected' : '' ?>>Male</option>
                    <option value="Female" <?= $member['gender'] === 'Female' ? 'selected' : '' ?>>Female</option>
                  </select>
                </div>
                <div class="form-group"><label>Birthday <span class="required">*</span></label><input type="date" id="birthday" name="birthday" data-required placeholder="Select birthday" value="<?= e($member['birthday']) ?>"></div>
                <div class="form-group"><label>Age <span style="color:var(--text-dim);font-weight:400;">(auto)</span></label><input type="number" id="age" name="age" data-type="age" readonly placeholder="Auto-calculated" value="<?= e($member['age']) ?>"></div>
                <div class="form-group">
                  <label>Occupation <span class="required">*</span></label>
                  <select name="occupation" id="occupationSelect" data-required>
                    <option value="" disabled <?= empty($member['occupation']) ? 'selected' : '' ?>>Select occupation</option>
                    <?php foreach ($occupations as $oc): ?>
                      <option value="<?= e($oc) ?>" <?= ($member['occupation'] ?? '') === $oc ? 'selected' : '' ?>><?= e($oc) ?></option>
                    <?php endforeach; ?>
                    <option value="Other" <?= $member['occupation'] && !in_array($member['occupation'], $occupations) ? 'selected' : '' ?>>Other</option>
                  </select>
                  <input type="text" name="occupation_other" id="occupationOther" placeholder="Type your occupation" value="<?= $member['occupation'] && !in_array($member['occupation'], $occupations) ? e($member['occupation']) : '' ?>" style="display:none;margin-top:8px;">
                </div>
                <div class="form-group"><label>Employer</label><input type="text" name="employer" placeholder="Enter employer" value="<?= e($member['employer']) ?>"></div>
                <div class="form-group" style="grid-column:span 2;"><label>Employer Address <span class="required">*</span></label><input type="text" name="employer_address" data-required placeholder="Enter employer address" value="<?= e($member['employer_address']) ?>"></div>
              </div>
            </div>
          </div>

          <div class="form-section">
            <h3 class="section-title">Contact Information</h3>
            <div class="card">
              <div class="form-grid">
                <div class="form-group"><label>Household No. <span class="required">*</span></label><input type="text" name="address_household" data-required placeholder="e.g. Blk 12 Lot 5" value="<?= e($member['address_household']) ?>"></div>
                <div class="form-group"><label>Purok / Subdivision <span class="required">*</span></label>
                  <select name="purok" data-required style="font-family:inherit;">
                    <option value="" disabled <?= empty($member['purok']) ? 'selected' : '' ?>>Select purok</option>
                    <?php foreach ($purokList as $p): ?>
                      <option value="<?= e($p) ?>" <?= ($member['purok'] ?? '') === $p ? 'selected' : '' ?>><?= e($p) ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="form-group"><label>Barangay <span class="required">*</span></label><input type="text" name="address_barangay" data-required placeholder="Enter barangay" value="<?= e($member['address_barangay']) ?>"></div>
                <div class="form-group"><label>Municipality / City <span class="required">*</span></label><input type="text" name="address_municipality" data-required placeholder="Enter municipality / city" value="<?= e($member['address_municipality']) ?>"></div>
                <div class="form-group"><label>Province <span class="required">*</span></label><input type="text" name="address_province" data-required placeholder="Enter province" value="<?= e($member['address_province']) ?>"></div>
                <div class="form-group"><label>Postal Code</label><input type="text" name="address_postal" placeholder="e.g. 3020" value="<?= e($member['address_postal']) ?>"></div>
                <div class="form-group"><label>Country</label><input type="text" name="address_country" placeholder="e.g. Philippines" value="<?= e($member['address_country']) ?>"></div>
                <div class="form-group"><label>Contact Number <span class="required">*</span></label><input type="text" name="contact_number" data-required data-type="contact" placeholder="09171234567" value="<?= e($member['contact_number']) ?>"></div>
                <div class="form-group"><label>Hotline / Alternate Number</label><input type="text" name="hotline" data-type="contact" placeholder="Optional" value="<?= e($member['hotline']) ?>"></div>
              </div>
            </div>
          </div>

          <div class="form-section">
            <h3 class="section-title">Spouse Information</h3>
            <div class="card">
              <div class="form-grid cols-3">
                <div class="form-group"><label>Spouse Name</label><input type="text" name="spouse_name" placeholder="Enter spouse name" value="<?= e($spouse['spouse_name'] ?? '') ?>"></div>
                <div class="form-group"><label>Occupation</label><input type="text" name="spouse_occupation" placeholder="Enter spouse occupation" value="<?= e($spouse['occupation'] ?? '') ?>"></div>
                <div class="form-group"><label>Employer</label><input type="text" name="spouse_employer" placeholder="Enter spouse employer" value="<?= e($spouse['employer'] ?? '') ?>"></div>
              </div>
            </div>
          </div>

          <div class="form-section">
            <h3 class="section-title">Children</h3>
            <div class="card">
              <div id="childrenContainer">
                <?php if (count($children) > 0): foreach ($children as $child): ?>
                  <div class="form-grid child-row" style="margin-bottom:10px;">
                    <div class="form-group"><label>Child Name</label><input type="text" name="child_name[]" placeholder="Enter child name" value="<?= e($child['child_name']) ?>"></div>
                    <div class="form-group"><label>Age</label><input type="number" name="child_age[]" data-type="age" placeholder="Enter age" value="<?= e($child['age']) ?>"></div>
                  </div>
                <?php endforeach; else: ?>
                  <div class="form-grid child-row" style="margin-bottom:10px;">
                    <div class="form-group"><label>Child Name</label><input type="text" name="child_name[]" placeholder="Enter child name"></div>
                    <div class="form-group"><label>Age</label><input type="number" name="child_age[]" data-type="age" placeholder="Enter age"></div>
                  </div>
                <?php endif; ?>
              </div>
              <button type="button" class="btn btn-secondary btn-sm" id="addChildBtn">+ Add Child</button>
            </div>
          </div>

          <div class="form-section">
            <h3 class="section-title">Parents</h3>
            <div class="card">
              <div class="form-grid">
                <div class="form-group"><label>Father's Name</label><input type="text" name="father_name" placeholder="Enter father's name" value="<?= e($member['father_name']) ?>"></div>
                <div class="form-group"><label>Mother's Name</label><input type="text" name="mother_name" placeholder="Enter mother's name" value="<?= e($member['mother_name']) ?>"></div>
              </div>
            </div>
          </div>

          <div class="form-section">
            <h3 class="section-title">Character References & Signature</h3>
            <div class="card">
              <p style="font-size:0.82rem;color:var(--text-muted);margin-bottom:16px;">You must provide 2 character references who are <strong>not family members</strong> and who personally know you.</p>
              <div style="border:1px solid var(--border);border-radius:var(--radius-sm);padding:16px;margin-bottom:16px;">
                <h4 style="font-size:0.85rem;font-weight:600;margin-bottom:12px;">Character Reference 1 <span class="required">*</span></h4>
                <div class="form-grid cols-2">
                  <div class="form-group"><label>Full Name <span class="required">*</span></label><input type="text" name="reference1_name" data-required placeholder="Enter full name" value="<?= e($member['reference1_name']) ?>"></div>
                  <div class="form-group"><label>Relationship <span class="required">*</span></label><input type="text" name="reference1_relationship" data-required placeholder="Friend, Neighbor, Coworker, etc." value="<?= e($member['reference1_relationship']) ?>"></div>
                  <div class="form-group"><label>Contact Number</label><input type="text" name="reference1_contact" data-type="contact" placeholder="09171234567" value="<?= e($member['reference1_contact']) ?>"></div>
                  <div class="form-group"><label>Address</label><input type="text" name="reference1_address" placeholder="Enter address" value="<?= e($member['reference1_address']) ?>"></div>
                </div>
              </div>
              <div style="border:1px solid var(--border);border-radius:var(--radius-sm);padding:16px;margin-bottom:16px;">
                <h4 style="font-size:0.85rem;font-weight:600;margin-bottom:12px;">Character Reference 2 <span class="required">*</span></h4>
                <div class="form-grid cols-2">
                  <div class="form-group"><label>Full Name <span class="required">*</span></label><input type="text" name="reference2_name" data-required placeholder="Enter full name" value="<?= e($member['reference2_name']) ?>"></div>
                  <div class="form-group"><label>Relationship <span class="required">*</span></label><input type="text" name="reference2_relationship" data-required placeholder="Friend, Neighbor, Coworker, etc." value="<?= e($member['reference2_relationship']) ?>"></div>
                  <div class="form-group"><label>Contact Number</label><input type="text" name="reference2_contact" data-type="contact" placeholder="09171234567" value="<?= e($member['reference2_contact']) ?>"></div>
                  <div class="form-group"><label>Address</label><input type="text" name="reference2_address" placeholder="Enter address" value="<?= e($member['reference2_address']) ?>"></div>
                </div>
              </div>
              <div class="form-group" style="grid-column:span 2;">
                <label>Signature (Optional)</label>
                <?php if (!empty($member['signature_path'])): ?>
                  <img id="sigPreview" src="../<?= e($member['signature_path']) ?>" style="max-height:50px;border:1px solid var(--border);border-radius:var(--radius-sm);margin-bottom:8px;display:block;">
                <?php else: ?>
                  <img id="sigPreview" style="max-height:50px;border:1px solid var(--border);border-radius:var(--radius-sm);margin-bottom:8px;display:none;">
                <?php endif; ?>
                <canvas id="sigCanvas" width="400" height="120" style="width:100%;max-width:400px;height:120px;border:1px solid var(--border);border-radius:var(--radius-sm);background:#fff;cursor:crosshair;touch-action:none;"></canvas>
                <input type="hidden" name="signature_data" id="sigHidden">
                <div style="display:flex;gap:8px;margin-top:8px;">
                  <button type="button" class="btn btn-secondary btn-sm" onclick="clearSignature()">Clear</button>
                  <button type="button" class="btn btn-primary btn-sm" onclick="saveSignature()">Save Signature</button>
                </div>
              </div>
            </div>
          </div>

          <div class="form-section">
            <h3 class="section-title">Emergency Contact</h3>
            <div class="card">
              <div class="form-grid cols-2">
                <div class="form-group"><label>Emergency Contact Name</label><input type="text" name="emergency_contact_name" placeholder="Enter full name" value="<?= e($member['emergency_contact_name']) ?>"></div>
                <div class="form-group"><label>Relationship</label><input type="text" name="emergency_contact_relationship" placeholder="Spouse, Parent, Sibling, etc." value="<?= e($member['emergency_contact_relationship']) ?>"></div>
                <div class="form-group"><label>Contact Number</label><input type="text" name="emergency_contact_number" data-type="contact" placeholder="09171234567" value="<?= e($member['emergency_contact_number']) ?>"></div>
              </div>
            </div>
          </div>

          <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:20px;">
            <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-primary">Save Changes</button>
          </div>
        </div>
      </div>
    </form>
  </div>
</div>

<div class="modal-overlay" id="upConfirmModal">
  <div class="modal-card">
    <div class="modal-icon" style="background:var(--primary);color:#fff;">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:28px;height:28px;"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
    </div>
    <h2 style="margin:0 0 6px;">Save Changes</h2>
    <p style="color:var(--text-muted);margin:0 0 20px;">Are you sure you want to save your updated information?</p>
    <div style="display:flex;gap:10px;justify-content:center;">
      <button type="button" class="btn btn-secondary" onclick="document.getElementById('upConfirmModal').style.display='none'">Cancel</button>
      <button type="button" class="btn btn-primary" id="upConfirmAction">Save</button>
    </div>
  </div>
</div>

<script>
  bindAgeAutoCalc('birthday', 'age');
  bindPhotoPreview('photoInput', 'photoPreview');
  bindSignaturePad('sigCanvas', 'sigHidden', 'sigPreview');

  document.getElementById('addChildBtn').addEventListener('click', function() {
    var container = document.getElementById('childrenContainer');
    var row = document.createElement('div');
    row.className = 'form-grid child-row';
    row.style.marginBottom = '10px';
    row.innerHTML =
      '<div class="form-group"><label>Child Name</label><input type="text" name="child_name[]" placeholder="Enter child name"></div>' +
      '<div class="form-group"><label>Age</label><input type="number" name="child_age[]" data-type="age" placeholder="Enter age">' +
        '<button type="button" class="btn btn-danger btn-sm remove-child" style="margin-top:6px;">Remove</button>' +
      '</div>';
    container.appendChild(row);
    row.querySelector('.remove-child').addEventListener('click', function() { row.remove(); });
  });

  document.querySelectorAll('.remove-child').forEach(function(btn) {
    btn.addEventListener('click', function() { this.closest('.child-row').remove(); });
  });

  var upForm = document.getElementById('updateForm');
  var upBtn = upForm.querySelector('button[type="submit"]');
  var upModal = document.getElementById('upConfirmModal');
  if (upBtn && upModal) {
    upBtn.addEventListener('click', function(e) {
      if (upForm.dataset.confirming !== '1') {
        e.preventDefault();
        document.getElementById('upConfirmAction').setAttribute('data-form', 'updateForm');
        upModal.style.display = 'flex';
      }
    });
  }
  document.getElementById('upConfirmAction').addEventListener('click', function() {
    var fid = this.getAttribute('data-form');
    var f = document.getElementById(fid);
    if (typeof showValidationSummary === 'function' && !showValidationSummary(f)) return;
    f.dataset.confirming = '1';
    f.submit();
  });

  var savePhotoBtn = document.getElementById('savePhotoBtn');
  if (savePhotoBtn && upModal) {
    savePhotoBtn.addEventListener('click', function(e) {
      e.preventDefault();
      if (upForm.dataset.confirming !== '1') {
        document.getElementById('upConfirmAction').setAttribute('data-form', 'updateForm');
        upModal.style.display = 'flex';
      }
    });
  }

  var occSelect = document.getElementById('occupationSelect');
  var occOther = document.getElementById('occupationOther');
  function toggleOccOther() {
    if (occSelect && occOther) {
      if (occSelect.value === 'Other') {
        occOther.style.display = 'block';
        occOther.setAttribute('data-required', '');
      } else {
        occOther.style.display = 'none';
        occOther.removeAttribute('data-required');
      }
    }
  }
  if (occSelect) {
    occSelect.addEventListener('change', toggleOccOther);
    toggleOccOther();
  }
</script>

<?php if (!empty($updated)): ?>
<div class="modal-overlay" id="successModal" style="display:flex;">
  <div class="modal-card">
    <div class="modal-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:28px;height:28px;"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
      </div>
      <h2>Records Updated</h2>
    <p style="margin-bottom:20px;">Your profile information has been updated successfully.</p>
    <a href="dashboard.php" class="btn btn-primary btn-block">Go to Dashboard</a>
  </div>
</div>
<?php endif; ?>
<?php require_once '../includes/footer.php'; ?>
