<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
require_once '../includes/survey_functions.php';
requireMemberLogin();
requireForcePasswordChange($pdo);
autoCloseExpiredSurveys($pdo);

$memberId = $_SESSION['member_id'];
$surveyId = (int)($_GET['id'] ?? 0);
$viewOnly = !empty($_GET['view']);

$survey = getSurvey($pdo, $surveyId);
if (!$survey) { redirect('surveys.php'); }

$myResponse = null;
$stmt = $pdo->prepare("SELECT * FROM survey_responses WHERE survey_id = ? AND member_id = ?");
$stmt->execute([$surveyId, $memberId]);
$myResponse = $stmt->fetch() ?: null;

$myAnswers = [];
if ($myResponse) {
    $stmt = $pdo->prepare("SELECT * FROM survey_answers WHERE response_id = ?");
    $stmt->execute([$myResponse['response_id']]);
    foreach ($stmt->fetchAll() as $a) {
        $myAnswers[(int)$a['question_id']] = $a;
    }
}

$live = surveyIsLive($survey);
$alreadyAnswered = $myResponse !== null;
$canAnswer = $live && !$alreadyAnswered && !$viewOnly;

$errors = [];
$submitted = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrfToken();

    if (!$live) {
        $errors[] = 'This survey is no longer open for responses.';
    } elseif ($alreadyAnswered) {
        $errors[] = 'You have already answered this survey. Each resident may answer only once.';
    } else {
        $questions = getSurveyQuestions($pdo, $surveyId);
        $answers = $_POST['answer'] ?? [];

        $valid = true;
        $answerRows = [];
        foreach ($questions as $q) {
            $qid = (int)$q['question_id'];
            $val = trim($answers[$qid] ?? '');
            $required = (int)$q['is_required'] === 1;

            if ($val === '') {
                if ($required) { $valid = false; }
                continue;
            }

            if ($q['question_type'] === 'short_answer') {
                if (mb_strlen($val) > 2000) { $errors[] = 'Answer to "' . $q['question_text'] . '" is too long (max 2000 characters).'; $valid = false; continue; }
                $answerRows[$qid] = ['choice_id' => null, 'rating_value' => null, 'answer_text' => $val];
            } elseif ($q['question_type'] === 'rating') {
                $r = (int)$val;
                if ($r < 1 || $r > 5) { $errors[] = 'Invalid rating for "' . $q['question_text'] . '".'; $valid = false; continue; }
                $answerRows[$qid] = ['choice_id' => null, 'rating_value' => $r, 'answer_text' => null];
            } else {
                // multiple_choice / yes_no -> must be a valid choice id belonging to this question
                $choiceIds = array_column($q['choices'], 'choice_id');
                $choiceVal = (int)$val;
                if (!in_array($choiceVal, $choiceIds, true)) { $errors[] = 'Invalid choice for "' . $q['question_text'] . '".'; $valid = false; continue; }
                $answerRows[$qid] = ['choice_id' => $choiceVal, 'rating_value' => null, 'answer_text' => null];
            }
        }

        if ($valid && count($answerRows) === 0) {
            $errors[] = 'Please answer the survey before submitting.';
        }

        if ($valid && empty($errors)) {
            $pdo->beginTransaction();
            try {
                $ins = $pdo->prepare("INSERT INTO survey_responses (survey_id, member_id) VALUES (?, ?)");
                $ins->execute([$surveyId, $memberId]);
                $responseId = $pdo->lastInsertId();

                $insA = $pdo->prepare(
                    "INSERT INTO survey_answers (response_id, question_id, choice_id, rating_value, answer_text) VALUES (?, ?, ?, ?, ?)"
                );
                foreach ($answerRows as $qid => $row) {
                    $insA->execute([$responseId, $qid, $row['choice_id'], $row['rating_value'], $row['answer_text']]);
                }

                rebuildSurveyResults($pdo, $surveyId);

                addNotification($pdo, 'success', 'Survey Submitted', 'Thank you for answering "' . $survey['title'] . '".', $memberId);

                $pdo->commit();
                $submitted = true;
            } catch (Exception $e) {
                $pdo->rollBack();
                $errors[] = 'An error occurred while saving your response. Please try again.';
            }
        }
    }

    if ($submitted) {
        $stmt = $pdo->prepare("SELECT * FROM survey_responses WHERE survey_id = ? AND member_id = ?");
        $stmt->execute([$surveyId, $memberId]);
        $myResponse = $stmt->fetch() ?: null;
        $alreadyAnswered = $myResponse !== null;
        $viewOnly = true;
    }
}

$questions = getSurveyQuestions($pdo, $surveyId);

$pageTitle = 'Survey';
$userLabel = $_SESSION['member_name'];
$userRole = 'Resident';
$showSearch = false;
$logoutUrl = 'logout.php';
$assetsPath = '../';
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Surveys','url'=>'surveys.php'], ['label'=> e($survey['title'])]];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/member_sidebar.php'; ?>
  <div class="main-content">

    <?php if (!empty($errors)): ?>
      <div class="alert alert-danger">
        <ul style="margin:0 0 0 18px;"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
      </div>
    <?php endif; ?>

    <?php if ($submitted): ?>
      <div class="card" style="max-width:560px;margin:40px auto;text-align:center;padding:40px;">
        <div class="modal-icon" style="background:var(--success);color:#fff;margin:0 auto 20px;">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:28px;height:28px;"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
        </div>
        <h2 style="margin:0 0 8px;">Response Submitted</h2>
        <p style="color:var(--text-muted);margin:0 0 6px;">Thank you! Your response to <strong><?= e($survey['title']) ?></strong> has been recorded.</p>
        <p style="color:var(--text-muted);font-size:0.85rem;margin:0 0 24px;">Submitted on <?= date('F d, Y h:i A', strtotime($myResponse['submitted_at'])) ?>.</p>
        <div style="display:flex;gap:10px;justify-content:center;">
          <a href="surveys.php" class="btn btn-primary">Back to Surveys</a>
          <a href="dashboard.php" class="btn btn-secondary">Go to Dashboard</a>
        </div>
      </div>
    <?php elseif ($viewOnly && $alreadyAnswered): ?>
      <div class="card" style="margin-bottom:20px;">
        <div class="card-header">
          <h2><?= e($survey['title']) ?></h2>
        </div>
        <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:8px;">
          <span class="badge badge-active">Answered</span>
          <span style="font-size:0.8rem;color:var(--text-muted);">Submitted on <?= date('M d, Y h:i A', strtotime($myResponse['submitted_at'])) ?></span>
        </div>
        <?php if (!empty($survey['description'])): ?><p style="color:var(--text-muted);font-size:0.85rem;"><?= e($survey['description']) ?></p><?php endif; ?>
      </div>

      <?php foreach ($questions as $i => $q): $ans = $myAnswers[(int)$q['question_id']] ?? null; ?>
        <div class="card" style="margin-bottom:16px;padding:22px;">
          <div style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.08em;margin-bottom:6px;">Question <?= $i + 1 ?></div>
          <div style="font-weight:600;margin-bottom:12px;"><?= e($q['question_text']) ?></div>
          <div style="background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px 16px;font-size:0.88rem;">
            <?php
              if ($q['question_type'] === 'short_answer') {
                echo e($ans['answer_text'] ?? '—');
              } elseif ($q['question_type'] === 'rating') {
                echo 'Rating: ' . str_repeat('★', (int)($ans['rating_value'] ?? 0)) . ' (' . (int)($ans['rating_value'] ?? 0) . '/5)';
              } else {
                $chosen = null;
                foreach ($q['choices'] as $c) {
                    if ((int)$c['choice_id'] === (int)($ans['choice_id'] ?? 0)) { $chosen = $c['choice_text']; break; }
                }
                echo e($chosen ?: '—');
              }
            ?>
          </div>
        </div>
      <?php endforeach; ?>

      <div style="display:flex;gap:10px;margin-top:20px;">
        <a href="surveys.php" class="btn btn-secondary">Back to Surveys</a>
      </div>

    <?php elseif (!$live): ?>
      <div class="alert alert-info">This survey is currently not accepting responses<?= $alreadyAnswered ? ' (you have already answered it).' : '.' ?> Please check the available surveys page.</div>
      <a href="surveys.php" class="btn btn-secondary">Back to Surveys</a>
    <?php else: ?>
      <div class="card" style="margin-bottom:20px;">
        <div class="card-header">
          <h2><?= e($survey['title']) ?></h2>
        </div>
        <?php if (!empty($survey['description'])): ?><p style="color:var(--text-muted);font-size:0.85rem;margin-bottom:8px;"><?= e($survey['description']) ?></p><?php endif; ?>
        <div style="font-size:0.8rem;color:var(--text-muted);">
          <?= count($questions) ?> questions
          <?php if (!empty($survey['ends_at'])): ?> · Closes on <?= date('M d, Y', strtotime($survey['ends_at'])) ?><?php endif; ?>
          · You can only submit once.
        </div>
      </div>

      <form method="POST" id="surveyForm" novalidate>
        <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
        <?php foreach ($questions as $i => $q): $qid = (int)$q['question_id']; ?>
          <div class="card q-block" data-required="<?= (int)$q['is_required'] ?>" style="margin-bottom:16px;padding:22px;">
            <div style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.08em;margin-bottom:6px;">
              Question <?= $i + 1 ?>
              <?php if ((int)$q['is_required'] === 1): ?><span class="required" style="text-transform:none;">*</span><?php endif; ?>
            </div>
            <div class="q-text-label" style="font-weight:600;margin-bottom:14px;"><?= e($q['question_text']) ?></div>

            <?php if (in_array($q['question_type'], ['multiple_choice', 'yes_no'])): ?>
              <div style="display:flex;flex-direction:column;gap:10px;">
                <?php foreach ($q['choices'] as $c): ?>
                  <label style="display:flex;align-items:center;gap:10px;cursor:pointer;font-size:0.9rem;padding:10px 14px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--bg-secondary);">
                    <input type="radio" name="answer[<?= $qid ?>]" value="<?= (int)$c['choice_id'] ?>">
                    <?= e($c['choice_text']) ?>
                  </label>
                <?php endforeach; ?>
              </div>
            <?php elseif ($q['question_type'] === 'rating'): ?>
              <div style="display:flex;flex-wrap:wrap;gap:10px;">
                <?php for ($r = 1; $r <= 5; $r++): ?>
                  <label style="flex:1;min-width:64px;text-align:center;cursor:pointer;padding:12px 8px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--bg-secondary);font-size:0.9rem;">
                    <input type="radio" name="answer[<?= $qid ?>]" value="<?= $r ?>" style="margin:0 4px 0 0;">
                    <?= $r ?>
                  </label>
                <?php endfor; ?>
              </div>
            <?php else: ?>
              <textarea name="answer[<?= $qid ?>]" rows="3" placeholder="Type your answer here..." style="font-family:inherit;"></textarea>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>

        <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:20px;">
          <a href="surveys.php" class="btn btn-secondary">Cancel</a>
          <button type="submit" class="btn btn-primary">Submit Survey</button>
        </div>
      </form>
    <?php endif; ?>

  </div>
</div>

<?php if (!$viewOnly && !$submitted && $live && !$alreadyAnswered): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
  var form = document.getElementById('surveyForm');
  if (!form) return;

  form.addEventListener('submit', function(e) {
    var valid = true;
    form.querySelectorAll('.q-block').forEach(function(blk) {
      blk.querySelectorAll('.error-text').forEach(function(err) { err.remove(); });
      blk.querySelectorAll('input, textarea').forEach(function(inp) { inp.classList.remove('invalid'); });

      if (blk.getAttribute('data-required') !== '1') return;
      var inputs = blk.querySelectorAll('input[type="radio"], textarea');
      var filled = false;
      inputs.forEach(function(inp) {
        if (inp.type === 'radio') { if (inp.checked) filled = true; }
        else if (inp.value.trim() !== '') filled = true;
      });
      if (!filled) {
        valid = false;
        var err = document.createElement('span');
        err.className = 'error-text';
        err.textContent = 'This question is required.';
        blk.appendChild(err);
      }
    });
    if (!valid) e.preventDefault();
  });
});
</script>
<?php endif; ?>
<?php require_once '../includes/footer.php'; ?>
