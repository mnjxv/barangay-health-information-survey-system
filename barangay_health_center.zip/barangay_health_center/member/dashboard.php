<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireMemberLogin();
requireForcePasswordChange($pdo);

$memberId = $_SESSION['member_id'];
$stmt = $pdo->prepare("SELECT * FROM members WHERE member_id = ?");
$stmt->execute([$memberId]);
$member = $stmt->fetch();
if (!$member) { redirect('logout.php'); }

$pageTitle = 'Dashboard';
$userLabel = $_SESSION['member_name'];
$userRole = 'Resident';
$showSearch = false;
$logoutUrl = 'logout.php';
$assetsPath = '../';
$hideTopbar = false;
$breadcrumbs = [['label'=>'Dashboard']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/member_sidebar.php'; ?>
  <div class="main-content">

    <?php if ((int)$member['must_change_password'] === 1): ?>
      <div class="alert alert-warning" style="margin-bottom:20px;">
        <strong>Password Change Required.</strong> You are still using your default password.
        <a href="change_password.php" style="margin-left:8px;font-weight:600;">Change Password Now</a>
      </div>
    <?php endif; ?>

    <div class="card" style="margin-bottom:24px;">
      <div style="display:flex;align-items:center;gap:20px;padding:20px;">
        <div>
          <?php if (!empty($member['photo_path'])): ?>
            <img src="../<?= e($member['photo_path']) ?>" alt="<?= e($member['first_name'] . ' ' . $member['last_name']) ?>" style="width:80px;height:80px;border-radius:50%;object-fit:cover;border:3px solid var(--border);">
          <?php else: ?>
            <div style="width:80px;height:80px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-size:2rem;font-weight:700;"><?= e(strtoupper(substr($member['first_name'], 0, 1) . substr($member['last_name'], 0, 1))) ?></div>
          <?php endif; ?>
        </div>
        <div style="flex:1;">
          <div style="font-size:0.82rem;color:var(--text-muted);margin-bottom:2px;">Welcome back,</div>
          <div style="font-size:1.5rem;font-weight:700;"><?= e($member['first_name'] . ' ' . $member['last_name']) ?></div>
        </div>
        <div>
          <a href="update_info.php" class="btn btn-primary">View Profile</a>
        </div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:24px;">
      <div class="stat-card" style="padding:16px 20px;">
        <div class="stat-top" style="margin-bottom:6px;">
          <div style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;">Resident Number</div>
          <div class="stat-icon primary" style="width:32px;height:32px;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:16px;height:16px;"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/></svg>
          </div>
        </div>
        <div style="font-size:1.1rem;font-weight:700;"><?= e($member['account_number']) ?></div>
      </div>
      <div class="stat-card" style="padding:16px 20px;">
        <div class="stat-top" style="margin-bottom:6px;">
          <div style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;">Gender</div>
          <div class="stat-icon info" style="width:32px;height:32px;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:16px;height:16px;"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          </div>
        </div>
        <div style="font-size:1.1rem;font-weight:700;"><?= e(na($member['gender'])) ?></div>
      </div>
      <div class="stat-card" style="padding:16px 20px;">
        <div class="stat-top" style="margin-bottom:6px;">
          <div style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;">Purok</div>
          <div class="stat-icon warning" style="width:32px;height:32px;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:16px;height:16px;"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
          </div>
        </div>
        <div style="font-size:1.1rem;font-weight:700;"><?= e(na($member['purok'])) ?></div>
      </div>
      <div class="stat-card" style="padding:16px 20px;">
        <div class="stat-top" style="margin-bottom:6px;">
          <div style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;">Civil Status</div>
          <div class="stat-icon success" style="width:32px;height:32px;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:16px;height:16px;"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
          </div>
        </div>
        <div style="font-size:1.1rem;font-weight:700;"><?= e(na($member['civil_status'])) ?></div>
      </div>
    </div>

    <div class="card" style="margin-bottom:24px;">
      <div class="card-header"><h3>Profile Completion</h3></div>
      <?php
        $totalFields = 20;
        $filled = 0;
        foreach (['first_name','last_name','middle_name','gender','civil_status','address','purok','contact_number','birthday','age','occupation','father_name','mother_name','reference1_name','reference1_relationship','reference2_name','reference2_relationship','emergency_contact_name','emergency_contact_number','photo_path'] as $f) {
          if (!empty($member[$f])) $filled++;
        }
        $pct = min(100, round(($filled / $totalFields) * 100));
      ?>
      <div class="progress">
        <div class="progress-bar">
          <div class="progress-fill <?= $pct >= 80 ? 'success' : ($pct >= 50 ? 'warning' : 'danger') ?>" data-value="<?= $pct ?>" style="width:0%"></div>
        </div>
        <span class="progress-label"><?= $pct ?>%</span>
      </div>
      <div style="font-size:0.78rem;color:var(--text-muted);margin-top:6px;"><?= $filled ?> of <?= $totalFields ?> fields completed</div>
    </div>

    <div class="card" style="margin-bottom:24px;">
      <div class="card-header"><h3>Quick Actions</h3></div>
      <div class="quick-actions-grid" style="grid-template-columns:repeat(3,1fr);">
        <a href="update_info.php" class="qa-item" data-color="primary">
          <div class="qa-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>
          </div>
          <div class="qa-title">Update Information</div>
          <div class="qa-desc">Edit your personal details</div>
        </a>
        <a href="print_profile.php" class="qa-item" data-color="success">
          <div class="qa-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          </div>
          <div class="qa-title">View Profile</div>
          <div class="qa-desc">View and print your resident record</div>
        </a>
        <a href="surveys.php" class="qa-item" data-color="success">
          <div class="qa-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
          </div>
          <div class="qa-title">Surveys</div>
          <div class="qa-desc">Answer barangay health surveys</div>
        </a>
        <a href="update_info.php#upload-docs" class="qa-item" data-color="info">
          <div class="qa-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
          </div>
          <div class="qa-title">Upload Documents</div>
          <div class="qa-desc">Upload passport-size photo</div>
        </a>
        <a href="notifications.php" class="qa-item" data-color="warning">
          <div class="qa-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
          </div>
          <div class="qa-title">Notifications</div>
          <div class="qa-desc">View system alerts and updates</div>
        </a>
        <a href="update_info.php#references" class="qa-item" data-color="accent">
          <div class="qa-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
          </div>
          <div class="qa-title">Character References</div>
          <div class="qa-desc">Manage your two references</div>
        </a>
        <a href="change_password.php" class="qa-item" data-color="primary">
          <div class="qa-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
          </div>
          <div class="qa-title">Account Settings</div>
          <div class="qa-desc">Change your password</div>
        </a>
      </div>
    </div>

  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
