<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
require_once '../includes/survey_functions.php';
requireMemberLogin();
requireForcePasswordChange($pdo);
autoCloseExpiredSurveys($pdo);

$memberId = $_SESSION['member_id'];

$surveys = $pdo->query("SELECT s.*, (SELECT COUNT(*) FROM survey_responses r WHERE r.survey_id = s.survey_id) AS response_count FROM survey_surveys s ORDER BY s.created_at DESC")->fetchAll();

$myResponses = [];
$stmt = $pdo->prepare("SELECT survey_id FROM survey_responses WHERE member_id = ?");
$stmt->execute([$memberId]);
foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $sid) {
    $myResponses[(int)$sid] = true;
}

$pageTitle = 'Surveys';
$userLabel = $_SESSION['member_name'];
$userRole = 'Resident';
$showSearch = false;
$logoutUrl = 'logout.php';
$assetsPath = '../';
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Surveys']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/member_sidebar.php'; ?>
  <div class="main-content">

    <div class="card" style="margin-bottom:24px;">
      <div class="card-header">
        <h2>Health Center Surveys</h2>
      </div>
      <p style="font-size:0.85rem;color:var(--text-muted);margin:0;">Answer the barangay's health center surveys. Each resident may submit a response to a survey only once.</p>
    </div>

    <?php if (count($surveys) === 0): ?>
      <div class="empty-state with-icon">
        <div class="empty-state-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
        </div>
        <div class="empty-state-title">No surveys available</div>
        <div class="empty-state-desc">There are no surveys to display right now. Check back later.</div>
      </div>
    <?php else: ?>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:16px;">
        <?php foreach ($surveys as $s):
            $live = surveyIsLive($s);
            $answered = isset($myResponses[(int)$s['survey_id']]);
            if ($s['status'] === 'draft') continue;
            if ($s['status'] === 'closed') $badge = ['badge-inactive', 'Closed'];
            elseif ($answered) $badge = ['badge-active', 'Answered'];
            elseif ($live) $badge = ['badge-pending', 'Open'];
            else $badge = ['badge-inactive', $s['starts_at'] > date('Y-m-d') ? 'Not yet open' : 'Ended'];
        ?>
          <div class="card" style="display:flex;flex-direction:column;padding:22px;">
            <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:10px;">
              <div style="font-size:1.02rem;font-weight:700;color:var(--text);line-height:1.35;"><?= e($s['title']) ?></div>
              <span class="badge <?= $badge[0] ?>" style="white-space:nowrap;"><?= $badge[1] ?></span>
            </div>
            <?php if (!empty($s['description'])): ?>
              <p style="font-size:0.82rem;color:var(--text-muted);margin:0 0 14px;flex:1;"><?= e($s['description']) ?></p>
            <?php else: ?>
              <div style="flex:1;"></div>
            <?php endif; ?>
            <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:14px;font-size:0.78rem;color:var(--text-muted);">
              <span>
                <?php
                  if (!empty($s['starts_at']) || !empty($s['ends_at'])):
                    echo ($s['starts_at'] ? 'Open: ' . date('M d, Y', strtotime($s['starts_at'])) : 'No open date')
                      . ' — ' . ($s['ends_at'] ? date('M d, Y', strtotime($s['ends_at'])) : 'No close date');
                  else:
                    echo 'No time limit';
                  endif;
                ?>
              </span>
              <span>(<?= (int)$s['response_count'] ?> <?= (int)$s['response_count'] === 1 ? 'response' : 'responses' ?>)</span>
            </div>
            <div>
              <?php if ($answered): ?>
                <a href="survey_take.php?id=<?= (int)$s['survey_id'] ?>&view=1" class="btn btn-secondary btn-block">View My Submission</a>
              <?php elseif ($live): ?>
                <a href="survey_take.php?id=<?= (int)$s['survey_id'] ?>" class="btn btn-primary btn-block">Take Survey</a>
              <?php else: ?>
                <button type="button" class="btn btn-secondary btn-block" disabled>Not Available</button>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
