<?php
require_once '../includes/functions.php';
require_once '../config/db.php';
requireMemberLogin();
requireForcePasswordChange($pdo);

$stmt = $pdo->prepare("SELECT * FROM members WHERE member_id = ?");
$stmt->execute([$_SESSION['member_id']]);
$member = $stmt->fetch();
if (!$member) { redirect('logout.php'); }

$spouseStmt = $pdo->prepare("SELECT * FROM spouse_info WHERE member_id = ?");
$spouseStmt->execute([$member['member_id']]);
$spouse = $spouseStmt->fetch();

$childrenStmt = $pdo->prepare("SELECT * FROM children WHERE member_id = ?");
$childrenStmt->execute([$member['member_id']]);
$children = $childrenStmt->fetchAll();

$pageTitle = 'Print Profile';
$userLabel = $member['first_name'] . ' ' . $member['last_name'];
$userRole = 'Member';
$showSearch = false;
$logoutUrl = 'logout.php';
$assetsPath = '../';
$hideTopbar = false;
$breadcrumbs = [['label'=>'Dashboard','url'=>'dashboard.php'], ['label'=>'Print Profile']];
require_once '../includes/header.php';
?>
<div class="app-shell">
  <?php require_once '../includes/member_sidebar.php'; ?>
  <div class="main-content">
    <div class="card no-print" style="display:flex;gap:10px;justify-content:flex-end;">
      <button onclick="window.print()" class="btn btn-primary">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
        Print
      </button>
    </div>

    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid var(--primary);padding-bottom:12px;margin-bottom:20px;">
        <div>
          <h2 style="margin:0;font-size:1.3rem;">Resify Information Management System</h2>
          <p class="text-muted" style="margin:2px 0;">Resident Information Profile</p>
        </div>
        <?php if (!empty($member['photo_path'])): ?>
          <img src="../<?= e($member['photo_path']) ?>" alt="<?= e($member['first_name'] . ' ' . $member['last_name']) ?>" style="width:80px;height:80px;border-radius:50%;object-fit:cover;">
        <?php endif; ?>
      </div>

      <h3>Personal Information</h3>
      <table>
        <tr><td class="text-muted" width="220">Resident Number</td><td><strong><?= e($member['account_number']) ?></strong></td></tr>
        <tr><td class="text-muted">Full Name</td><td><?= e(trim($member['first_name'].' '.$member['middle_name'].' '.$member['last_name'].' '.$member['extension_name'])) ?></td></tr>
        <tr><td class="text-muted">Gender</td><td><?= e(na($member['gender'])) ?></td></tr>
        <tr><td class="text-muted">Civil Status</td><td><?= e(na($member['civil_status'])) ?></td></tr>
        <tr><td class="text-muted">Purok</td><td><?= e(na($member['purok'])) ?></td></tr>
        <tr><td class="text-muted">Birthday</td><td><?= e(na($member['birthday'])) ?></td></tr>
        <tr><td class="text-muted">Age</td><td><?= e(na($member['age'])) ?></td></tr>
        <tr><td class="text-muted">Address</td><td><?= e(na(formatAddress($member))) ?></td></tr>
        <tr><td class="text-muted">Contact Number</td><td><?= e(na($member['contact_number'])) ?></td></tr>
        <tr><td class="text-muted">Hotline</td><td><?= e(na($member['hotline'])) ?></td></tr>
        <tr><td class="text-muted">Occupation</td><td><?= e(na($member['occupation'])) ?></td></tr>
        <tr><td class="text-muted">Employer</td><td><?= e(na($member['employer'])) ?></td></tr>
        <tr><td class="text-muted">Employer Address</td><td><?= e(na($member['employer_address'])) ?></td></tr>
      </table>

      <h3>Spouse Information</h3>
      <table>
        <tr><td class="text-muted" width="220">Spouse Name</td><td><?= e($spouse['spouse_name'] ?? 'N/A') ?></td></tr>
        <tr><td class="text-muted">Occupation</td><td><?= e($spouse['occupation'] ?? 'N/A') ?></td></tr>
        <tr><td class="text-muted">Employer</td><td><?= e($spouse['employer'] ?? 'N/A') ?></td></tr>
      </table>

      <h3>Children</h3>
      <table>
        <thead><tr><th>Name</th><th>Age</th></tr></thead>
        <tbody>
          <?php if (count($children) > 0): foreach ($children as $c): ?>
            <tr><td><?= e($c['child_name']) ?></td><td><?= e($c['age'] ?: '—') ?></td></tr>
          <?php endforeach; else: ?>
            <tr><td colspan="2" class="text-muted">None on file</td></tr>
          <?php endif; ?>
        </tbody>
      </table>

      <h3>Parents</h3>
      <table>
        <tr><td class="text-muted" width="220">Father's Name</td><td><?= e($member['father_name'] ?? 'N/A') ?></td></tr>
        <tr><td class="text-muted">Mother's Name</td><td><?= e($member['mother_name'] ?? 'N/A') ?></td></tr>
      </table>

      <h3>References</h3>
      <table>
        <tr><td class="text-muted" width="220">Reference 1</td><td><?= e($member['reference1_name'] ?? 'N/A') ?></td></tr>
        <tr><td class="text-muted">Relationship</td><td><?= e($member['reference1_relationship'] ?? 'N/A') ?></td></tr>
        <tr><td class="text-muted">Contact</td><td><?= e($member['reference1_contact'] ?? 'N/A') ?></td></tr>
        <tr><td class="text-muted">Address</td><td><?= e($member['reference1_address'] ?? 'N/A') ?></td></tr>
        <tr><td class="text-muted">Reference 2</td><td><?= e($member['reference2_name'] ?? 'N/A') ?></td></tr>
        <tr><td class="text-muted">Relationship</td><td><?= e($member['reference2_relationship'] ?? 'N/A') ?></td></tr>
        <tr><td class="text-muted">Contact</td><td><?= e($member['reference2_contact'] ?? 'N/A') ?></td></tr>
        <tr><td class="text-muted">Address</td><td><?= e($member['reference2_address'] ?? 'N/A') ?></td></tr>
        <?php if (!empty($member['signature_path'])): ?>
          <tr><td class="text-muted">Signature</td><td><img src="../<?= e($member['signature_path']) ?>" style="max-height:50px;"></td></tr>
        <?php endif; ?>
      </table>

      <h3>Emergency Contact</h3>
      <table>
        <tr><td class="text-muted" width="220">Name</td><td><?= e($member['emergency_contact_name'] ?? 'N/A') ?></td></tr>
        <tr><td class="text-muted">Relationship</td><td><?= e($member['emergency_contact_relationship'] ?? 'N/A') ?></td></tr>
        <tr><td class="text-muted">Contact</td><td><?= e($member['emergency_contact_number'] ?? 'N/A') ?></td></tr>
      </table>

      <p class="text-muted" style="margin-top:24px;font-size:0.78rem;">Generated on <?= date('F d, Y h:i A') ?></p>
    </div>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>