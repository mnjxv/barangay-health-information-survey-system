/**
 * Client-side validation & interactivity
 * Used across login, registration, and member info forms.
 */

function showFieldError(input, message) {
  clearFieldError(input);
  input.classList.add('invalid');
  const err = document.createElement('span');
  err.className = 'error-text';
  err.textContent = message;
  err.dataset.errorFor = input.name;
  input.insertAdjacentElement('afterend', err);
}

function clearFieldError(input) {
  input.classList.remove('invalid');
  const next = input.nextElementSibling;
  if (next && next.classList.contains('error-text')) {
    next.remove();
  }
}

function clearAllErrors(form) {
  form.querySelectorAll('.invalid').forEach(clearFieldError);
}

function isValidContactNumber(value) {
  return /^09\d{9}$/.test(value.trim()) || /^\+639\d{9}$/.test(value.trim());
}

/**
 * Validates a form using declarative data attributes:
 *   data-required, data-type="number|contact|text", data-min, data-max
 */
function validateForm(form) {
  clearAllErrors(form);
  let valid = true;

  form.querySelectorAll('[data-required], [data-type]').forEach((input) => {
    const value = input.value.trim();

    if (input.hasAttribute('data-required') && value === '') {
      showFieldError(input, 'This field is required.');
      valid = false;
      return;
    }

    if (value === '') return; // skip type checks on empty optional fields

    const type = input.dataset.type;
    if (type === 'contact' && !isValidContactNumber(value)) {
      showFieldError(input, 'Enter a valid PH mobile number (e.g. 09171234567).');
      valid = false;
    }
    if (type === 'number' && isNaN(Number(value))) {
      showFieldError(input, 'Must be a number.');
      valid = false;
    }
    if (type === 'age') {
      const num = Number(value);
      if (isNaN(num) || num < 0 || num > 130) {
        showFieldError(input, 'Enter a valid age.');
        valid = false;
      }
    }
    if (type === 'password-match') {
      const other = document.querySelector(input.dataset.matches);
      if (other && other.value !== value) {
        showFieldError(input, 'Passwords do not match.');
        valid = false;
      }
    }
  });

  return valid;
}

function attachValidation(formId) {
  const form = document.getElementById(formId);
  if (!form) return;
  form.addEventListener('submit', (e) => {
    if (!validateForm(form)) {
      e.preventDefault();
    }
  });
}

function showValidationSummary(form) {
  clearAllErrors(form);
  if (validateForm(form)) return true;

  var errors = {};
  form.querySelectorAll('.error-text').forEach(function(el) {
    var input = el.previousElementSibling;
    var section = input.closest('.form-section');
    var sectionName = section ? section.querySelector('.section-title').textContent.trim() : 'Form';
    var label = input.closest('.form-group') ? input.closest('.form-group').querySelector('label') : null;
    var fieldName = label ? label.textContent.replace('*', '').trim() : (input.name || 'Field');
    if (!errors[sectionName]) errors[sectionName] = [];
    errors[sectionName].push({ field: fieldName, msg: el.textContent });
  });

  var html = '<div class="modal-overlay" id="validationSummary" style="display:flex;">';
  html += '<div class="modal-card" style="max-width:500px;">';
  html += '<div class="modal-icon" style="background:var(--danger);color:#fff;font-size:24px;font-weight:700;">!</div>';
  html += '<h2 style="margin:0 0 6px;">Missing Required Fields</h2>';
  html += '<p style="color:var(--text-muted);margin:0 0 16px;">Please fill in the highlighted fields below:</p>';
  html += '<div style="text-align:left;max-height:300px;overflow-y:auto;">';

  for (var sectionName in errors) {
    html += '<div style="margin-bottom:12px;border-bottom:1px solid var(--border);padding-bottom:8px;">';
    html += '<div style="color:var(--primary);font-size:14px;font-weight:600;">' + sectionName + '</div>';
    html += '<ul style="margin:4px 0 0;padding-left:18px;">';
    errors[sectionName].forEach(function(e) {
      html += '<li style="margin-bottom:3px;font-size:13px;line-height:1.4;">' + e.field + ' — ' + e.msg + '</li>';
    });
    html += '</ul></div>';
  }

  html += '</div>';
  html += '<button type="button" class="btn btn-primary" onclick="document.getElementById(\'validationSummary\').remove()">OK</button>';
  html += '</div></div>';

  document.body.insertAdjacentHTML('beforeend', html);
  return false;
}

/** Auto-calculate age from birthday input */
function bindAgeAutoCalc(birthdayId, ageId) {
  const bday = document.getElementById(birthdayId);
  const age = document.getElementById(ageId);
  if (!bday || !age) return;
  bday.addEventListener('change', () => {
    if (!bday.value) return;
    const today = new Date();
    const birth = new Date(bday.value);
    let years = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) years--;
    age.value = years >= 0 ? years : '';
  });
}

/** Preview an uploaded photo before submit */
function bindPhotoPreview(inputId, previewId) {
  const input = document.getElementById(inputId);
  const preview = document.getElementById(previewId);
  if (!input || !preview) return;
  input.addEventListener('change', () => {
    const file = input.files[0];
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/jpg'].includes(file.type)) {
      showFieldError(input, 'Only JPG or PNG images are allowed.');
      input.value = '';
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      showFieldError(input, 'Image must be smaller than 2MB.');
      input.value = '';
      return;
    }
    clearFieldError(input);
    const reader = new FileReader();
    reader.onload = (e) => { preview.src = e.target.result; };
    reader.readAsDataURL(file);
  });
}

/** Add / remove dynamic child rows on the update-info form */
function addChildRow(containerId, template) {
  const container = document.getElementById(containerId);
  const wrapper = document.createElement('div');
  wrapper.className = 'form-grid child-row';
  wrapper.style.marginBottom = '10px';
  wrapper.innerHTML = template;
  container.appendChild(wrapper);
  wrapper.querySelector('.remove-child').addEventListener('click', () => wrapper.remove());
}

/** Signature pad — draw with mouse/touch, save as base64 PNG */
function bindSignaturePad(canvasId, hiddenId, previewId) {
  const canvas = document.getElementById(canvasId);
  const hidden = document.getElementById(hiddenId);
  const preview = document.getElementById(previewId);
  if (!canvas || !hidden) return;

  const ctx = canvas.getContext('2d');
  let drawing = false;

  function getPos(e) {
    const rect = canvas.getBoundingClientRect();
    const t = e.touches ? e.touches[0] : e;
    return { x: (t.clientX - rect.left) * (canvas.width / rect.width), y: (t.clientY - rect.top) * (canvas.height / rect.height) };
  }

  function start(e) { e.preventDefault(); drawing = true; ctx.beginPath(); ctx.moveTo(getPos(e).x, getPos(e).y); }
  function move(e) { if (!drawing) return; e.preventDefault(); const p = getPos(e); ctx.lineTo(p.x, p.y); ctx.stroke(); }
  function stop(e) { drawing = false; ctx.beginPath(); }

  ctx.lineWidth = 2; ctx.lineCap = 'round'; ctx.strokeStyle = '#1F1F1F';
  canvas.addEventListener('mousedown', start); canvas.addEventListener('mousemove', move); canvas.addEventListener('mouseup', stop); canvas.addEventListener('mouseleave', stop);
  canvas.addEventListener('touchstart', start, { passive: false }); canvas.addEventListener('touchmove', move, { passive: false }); canvas.addEventListener('touchend', stop);

  function save() {
    const data = canvas.toDataURL('image/png');
    if (data === 'data:,') return;
    hidden.value = data;
    if (preview) { preview.src = data; preview.style.display = 'block'; }
  }

  const form = canvas.closest('form');
  if (form) {
    form.addEventListener('submit', function() {
      if (hidden.value === '' && !canvas.toDataURL('image/png').startsWith('data:,')) {
        hidden.value = canvas.toDataURL('image/png');
      }
    });
  }

  window.clearSignature = function() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    hidden.value = '';
    if (preview) { preview.style.display = 'none'; }
  };

  window.saveSignature = save;
}

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('form[data-validate]').forEach((form) => {
    attachValidation(form.id);
  });
});
