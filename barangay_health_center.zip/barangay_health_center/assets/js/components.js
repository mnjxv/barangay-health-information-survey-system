(function() {
  'use strict';

  function createToastContainer() {
    let container = document.getElementById('toastContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toastContainer';
      container.className = 'toast-container';
      document.body.appendChild(container);
    }
    return container;
  }

  window.showToast = function(type, title, message, duration) {
    duration = duration || 4000;
    var icons = {
      success: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
      danger: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
      warning: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
      info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
    };

    var toast = document.createElement('div');
    toast.className = 'toast toast-' + type;
    toast.innerHTML =
      '<div class="toast-icon">' + (icons[type] || icons.info) + '</div>' +
      '<div class="toast-body">' +
        (title ? '<div class="toast-title">' + title + '</div>' : '') +
        (message ? '<div class="toast-msg">' + message + '</div>' : '') +
      '</div>' +
      '<button class="toast-close" onclick="this.closest(\'.toast\').classList.add(\'removing\');setTimeout(function(){this.closest(\'.toast\').remove()}.bind(this),300)">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>' +
      '</button>';

    var container = createToastContainer();
    container.appendChild(toast);

    if (duration > 0) {
      setTimeout(function() {
        toast.classList.add('removing');
        setTimeout(function() { if (toast.parentNode) toast.remove(); }, 300);
      }, duration);
    }
  };
})();

(function() {
  'use strict';

  function animateCountUp(el, target, duration) {
    var start = 0;
    var startTime = null;
    var isFloat = target % 1 !== 0;

    function step(timestamp) {
      if (!startTime) startTime = timestamp;
      var progress = Math.min((timestamp - startTime) / duration, 1);
      var eased = 1 - Math.pow(1 - progress, 3);
      var current = start + (target - start) * eased;
      el.textContent = isFloat ? current.toFixed(1) : Math.floor(current);
      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        el.textContent = isFloat ? target.toFixed(1) : target;
      }
    }
    requestAnimationFrame(step);
  }

  function initCountUps() {
    document.querySelectorAll('[data-count]').forEach(function(el) {
      var target = parseFloat(el.getAttribute('data-count'));
      var duration = parseInt(el.getAttribute('data-duration')) || 1200;
      var observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
          if (entry.isIntersecting) {
            animateCountUp(el, target, duration);
            observer.unobserve(el);
          }
        });
      }, { threshold: 0.3 });
      observer.observe(el);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCountUps);
  } else {
    initCountUps();
  }
})();

(function() {
  'use strict';

  function initScrollToTop() {
    var btn = document.getElementById('scrollTopBtn');
    if (!btn) {
      btn = document.createElement('button');
      btn.id = 'scrollTopBtn';
      btn.className = 'scroll-top-btn';
      btn.setAttribute('title', 'Scroll to top');
      btn.setAttribute('aria-label', 'Scroll to top');
      btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"/></svg>';
      document.body.appendChild(btn);

      btn.addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    }

    var ticking = false;
    window.addEventListener('scroll', function() {
      if (!ticking) {
        requestAnimationFrame(function() {
          if (window.scrollY > 400) {
            btn.classList.add('visible');
          } else {
            btn.classList.remove('visible');
          }
          ticking = false;
        });
        ticking = true;
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initScrollToTop);
  } else {
    initScrollToTop();
  }
})();

(function() {
  'use strict';

  function initFormShake() {
    document.querySelectorAll('form').forEach(function(form) {
      form.addEventListener('submit', function(e) {
        if (e.defaultPrevented) return;
        var invalid = form.querySelectorAll('.is-invalid, .invalid');
        invalid.forEach(function(el) {
          el.classList.remove('shake');
          void el.offsetWidth;
          el.classList.add('shake');
        });
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initFormShake);
  } else {
    initFormShake();
  }
})();

(function() {
  'use strict';

  function initButtonLoading() {
    document.querySelectorAll('form').forEach(function(form) {
      form.addEventListener('submit', function(e) {
        if (e.defaultPrevented) return;
        var btn = form.querySelector('button[type="submit"]');
        if (btn && !btn.classList.contains('no-loading')) {
          btn.classList.add('is-loading');
          setTimeout(function() { btn.classList.remove('is-loading'); }, 8000);
        }
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initButtonLoading);
  } else {
    initButtonLoading();
  }
})();

(function() {
  'use strict';

  var progressBars = [];
  function initProgressBars() {
    document.querySelectorAll('.progress-fill:not(.animated)').forEach(function(el) {
      el.classList.add('animated');
      var target = parseInt(el.getAttribute('data-value')) || 0;
      progressBars.push({ el: el, target: target });
    });

    if (progressBars.length === 0) return;

    var observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          var item = progressBars.find(function(p) { return p.el === entry.target; });
          if (item) {
            setTimeout(function() {
              item.el.style.width = item.target + '%';
            }, 200);
            observer.unobserve(item.el);
          }
        }
      });
    }, { threshold: 0.3 });

    progressBars.forEach(function(item) {
      observer.observe(item.el);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initProgressBars);
  } else {
    initProgressBars();
  }
})();

(function() {
  'use strict';

  function initDropZones() {
    document.querySelectorAll('.drop-zone').forEach(function(zone) {
      var input = zone.querySelector('input[type="file"]');
      if (!input) return;

      zone.addEventListener('click', function(e) {
        if (e.target.closest('.dz-remove')) return;
        input.click();
      });

      zone.addEventListener('dragover', function(e) {
        e.preventDefault();
        zone.classList.add('drag-over');
      });

      zone.addEventListener('dragleave', function() {
        zone.classList.remove('drag-over');
      });

      zone.addEventListener('drop', function(e) {
        e.preventDefault();
        zone.classList.remove('drag-over');
        if (e.dataTransfer.files.length) {
          input.files = e.dataTransfer.files;
          var evt = new Event('change', { bubbles: true });
          input.dispatchEvent(evt);
        }
      });

      input.addEventListener('change', function() {
        var saveBtn = zone.parentElement.querySelector('.profile-save-photo');
        if (input.files.length) {
          showDropZonePreview(zone, input.files[0]);
          zone.classList.add('has-file');
          if (saveBtn) saveBtn.style.display = 'block';
        } else {
          zone.classList.remove('has-file');
          if (saveBtn) saveBtn.style.display = 'none';
        }
      });

      var removeBtn = zone.querySelector('.dz-remove');
      if (removeBtn) {
        removeBtn.addEventListener('click', function() {
          var saveBtn = zone.parentElement.querySelector('.profile-save-photo');
          if (saveBtn) saveBtn.style.display = 'none';
        });
      }
    });
  }

  function showDropZonePreview(zone, file) {
    var preview = zone.querySelector('.drop-zone-preview');
    if (!preview) return;

    var nameEl = preview.querySelector('.dz-name');
    var sizeEl = preview.querySelector('.dz-size');
    var imgEl = preview.querySelector('.dz-img');

    if (nameEl) nameEl.textContent = truncateFileName(file.name);
    if (sizeEl) sizeEl.textContent = (file.size / 1024).toFixed(1) + ' KB';

    if (imgEl && file.type.startsWith('image/')) {
      var reader = new FileReader();
      reader.onload = function(e) { imgEl.src = e.target.result; imgEl.style.display = 'block'; };
      reader.readAsDataURL(file);
    }

    preview.classList.add('show');
  }

  function truncateFileName(name, maxLen) {
    maxLen = maxLen || 24;
    if (name.length <= maxLen) return name;
    var ext = name.lastIndexOf('.');
    var extPart = ext !== -1 ? name.slice(ext) : '';
    var base = ext !== -1 ? name.slice(0, ext) : name;
    if (base.length <= maxLen) return name;
    var keep = Math.max(0, maxLen - extPart.length - 3);
    return base.slice(0, keep) + '...' + extPart;
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initDropZones);
  } else {
    initDropZones();
  }
})();

(function() {
  'use strict';

  function initStepper() {
    var steppers = document.querySelectorAll('.stepper[data-steps]');
    steppers.forEach(function(stepper) {
      var total = parseInt(stepper.getAttribute('data-steps')) || 0;
      var current = parseInt(stepper.getAttribute('data-current')) || 1;

      stepper.querySelectorAll('.step').forEach(function(step, index) {
        var stepNum = index + 1;
        step.classList.remove('active', 'completed');
        if (stepNum < current) step.classList.add('completed');
        else if (stepNum === current) step.classList.add('active');

        var numEl = step.querySelector('.step-number');
        if (numEl && stepNum < current) numEl.innerHTML = '\u2713';

        var connector = step.nextElementSibling;
        if (connector && connector.classList.contains('step-connector') && stepNum < current) {
          connector.classList.add('done');
        }
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initStepper);
  } else {
    initStepper();
  }
})();
