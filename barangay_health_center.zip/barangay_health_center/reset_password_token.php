<?php
require_once 'includes/functions.php';
require_once 'config/db.php';

$token = $_GET['token'] ?? '';
$tokenHash = hash('sha256', $token);

$member = null;
if ($token !== '') {
    $stmt = $pdo->prepare(
        "SELECT pr.*, m.*, m.member_id AS reset_member_id
         FROM password_resets pr
         JOIN members m ON m.member_id = pr.member_id
         WHERE pr.token_hash = ? AND pr.used = 0 AND pr.expires_at > NOW()
         ORDER BY pr.id DESC LIMIT 1"
    );
    $stmt->execute([$tokenHash]);
    $member = $stmt->fetch();
}

$errors = [];
$resetDone = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['token'] ?? '';
    $tokenHash = hash('sha256', $token);

    $stmt = $pdo->prepare(
        "SELECT pr.*, m.*, m.member_id AS reset_member_id
         FROM password_resets pr
         JOIN members m ON m.member_id = pr.member_id
         WHERE pr.token_hash = ? AND pr.used = 0 AND pr.expires_at > NOW()
         ORDER BY pr.id DESC LIMIT 1"
    );
    $stmt->execute([$tokenHash]);
    $member = $stmt->fetch();

    if (!$member) {
        $errors[] = 'This reset link is invalid, already used, or has expired. Please request a new one.';
    } else {
        $new = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if (strlen($new) < 6) {
            $errors[] = 'New password must be at least 6 characters.';
        } elseif (strlen($new) > 72) {
            $errors[] = 'New password is too long (max 72 characters).';
        } elseif ($new !== $confirm) {
            $errors[] = 'New password and confirmation do not match.';
        } elseif (password_verify($new, $member['password'])) {
            $errors[] = 'New password must be different from your current password.';
        } else {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $pdo->beginTransaction();
            try {
                $upd = $pdo->prepare("UPDATE members SET password = ?, must_change_password = 0 WHERE member_id = ?");
                $upd->execute([$hash, $member['reset_member_id']]);
                $pdo->prepare("UPDATE password_resets SET used = 1 WHERE id = ?")->execute([$member['id']]);
                $pdo->commit();
                addNotification($pdo, 'success', 'Password Reset', 'Your password was reset successfully. Please sign in with your new password.', $member['reset_member_id']);
                $resetDone = true;
            } catch (Exception $e) {
                $pdo->rollBack();
                $errors[] = 'An error occurred while resetting your password. Please try again.';
            }
        }
    }
}

$pageTitle = 'Reset Password';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> — Resify</title>
<link rel="stylesheet" href="assets/css/style.css">
<style>
.password-strength { display:flex; gap:4px; margin-top:8px; }
.password-strength .strength-bar {
  flex:1; height:5px; border-radius:3px; background:var(--border);
  transition:background .3s;
}
.password-strength .strength-bar.active.weak { background:#E53E3E; }
.password-strength .strength-bar.active.medium { background:#DD6B20; }
.password-strength .strength-bar.active.strong { background:#D69E2E; }
.password-strength .strength-bar.active.very-strong { background:#38A169; }
.strength-text { font-size:0.75rem; margin-top:4px; color:var(--text-muted); }
.strength-text.weak { color:#E53E3E; }
.strength-text.medium { color:#DD6B20; }
.strength-text.strong { color:#D69E2E; }
.strength-text.very-strong { color:#38A169; }
.pw-hint { font-size:0.72rem; color:var(--text-muted); margin-top:4px; }
</style>
</head>
<body>
<div class="page-center">
  <div class="auth-card" style="max-width:440px;width:100%;padding:36px 32px;">
    <div class="logo-area">
      <div class="login-icon"><img src="resify.png" alt="Resify logo"></div>
      <h1>Resify Information<br>Management System</h1>
    </div>

    <?php if ($resetDone): ?>
      <div class="alert alert-success"><strong>Password reset successful.</strong> You can now sign in with your new password.</div>
      <a href="index.php#login-section" class="btn btn-primary btn-block" style="text-align:center;">Go to Sign In</a>
    <?php elseif (!$member): ?>
      <div class="alert alert-danger">
        <strong>Invalid or expired link.</strong> This password reset link is invalid, already used, or has expired.
      </div>
      <a href="forgot_password.php" class="btn btn-primary btn-block" style="text-align:center;">Request a New Link</a>
    <?php else: ?>
      <?php foreach ($errors as $err): ?>
        <div class="alert alert-danger"><?= e($err) ?></div>
      <?php endforeach; ?>

      <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:20px;">
        Set a new password for <strong><?= e($member['first_name'] . ' ' . $member['last_name']) ?></strong>
        (Resident #<?= e($member['account_number']) ?>).
      </p>

      <form method="POST" id="resetForm" data-validate novalidate>
        <input type="hidden" name="_csrf_token" value="<?= generateCsrfToken() ?>">
        <input type="hidden" name="token" value="<?= e($token) ?>">
        <div class="form-group">
          <label>New Password <span class="required">*</span></label>
          <input type="password" id="newPassword" name="new_password" data-required data-min="6" placeholder="At least 6 characters">
          <div class="password-strength" id="pwStrength">
            <div class="strength-bar" data-index="0"></div>
            <div class="strength-bar" data-index="1"></div>
            <div class="strength-bar" data-index="2"></div>
            <div class="strength-bar" data-index="3"></div>
          </div>
          <div class="strength-text" id="pwStrengthText"></div>
          <div class="pw-hint">Minimum of 6 characters required.</div>
        </div>
        <div class="form-group">
          <label>Confirm New Password <span class="required">*</span></label>
          <input type="password" name="confirm_password" data-required data-type="password-match" data-matches="#newPassword" placeholder="Re-enter new password">
        </div>
        <button type="submit" class="btn btn-primary btn-block">Reset Password</button>
        <div style="text-align:center;margin-top:14px;">
          <a href="index.php#login-section" style="font-size:0.82rem;color:#2E5A9C;font-weight:500;text-decoration:none;">Back to Sign In</a>
        </div>
      </form>
    <?php endif; ?>
  </div>
</div>
<script src="assets/js/validation.js"></script>
<script>
document.getElementById('newPassword').addEventListener('input', function() {
  var pw = this.value;
  var score = 0;
  if (pw.length >= 6) score++;
  if (pw.length >= 10) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^a-zA-Z0-9]/.test(pw)) score++;
  var bars = document.querySelectorAll('#pwStrength .strength-bar');
  var text = document.getElementById('pwStrengthText');
  var level = score <= 1 ? 'weak' : score === 2 ? 'medium' : score === 3 ? 'strong' : 'very-strong';
  var labels = { weak: 'Weak', medium: 'Medium', strong: 'Strong', very-strong: 'Very Strong' };
  bars.forEach(function(bar, i) {
    bar.className = 'strength-bar' + (i < score ? ' active ' + level : '');
  });
  text.textContent = pw.length > 0 ? labels[level] : '';
  text.className = 'strength-text ' + (pw.length > 0 ? level : '');
});
</script>
</body>
</html>